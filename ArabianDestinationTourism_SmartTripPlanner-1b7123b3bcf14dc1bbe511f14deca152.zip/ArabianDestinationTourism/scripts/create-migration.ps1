$ErrorActionPreference = "Stop"
dotnet tool restore
dotnet ef migrations add InitialCreate --project src/ArabianDestinationTourism --startup-project src/ArabianDestinationTourism --output-dir Data/Migrations
dotnet ef database update --project src/ArabianDestinationTourism --startup-project src/ArabianDestinationTourism
