using ArabianDestinationTourism.Models.ViewModels;
using Xunit;
namespace ArabianDestinationTourism.Tests;
public class RecommendationTests
{
    [Fact] public void WeightedScore_MatchesRequiredFormula()
    {
        var s=new ScoreBreakdown(.9,.8,.9,.95,.7,.8);
        var expected=.30*.9+.25*.8+.15*.9+.15*.95+.10*.7+.05*.8;
        Assert.Equal(expected,s.Final,8);
    }
    [Fact] public void Score_IsNormalized()
    {
        var s=new ScoreBreakdown(2,2,2,2,2,2);
        Assert.InRange(s.Final,0,1);
    }
    [Fact] public void ExcludedPlaces_IsOptional_ForMvcFormValidation()
    {
        var property = typeof(PlannerVm).GetProperty(nameof(PlannerVm.ExcludedPlaces));
        Assert.NotNull(property);
        var nullability = new System.Reflection.NullabilityInfoContext().Create(property!);
        Assert.Equal(System.Reflection.NullabilityState.Nullable, nullability.WriteState);
    }
}
