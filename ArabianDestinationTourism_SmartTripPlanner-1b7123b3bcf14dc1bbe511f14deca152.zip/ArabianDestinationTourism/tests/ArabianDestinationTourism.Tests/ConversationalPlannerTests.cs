using ArabianDestinationTourism.Data;
using ArabianDestinationTourism.Models.Entities;
using ArabianDestinationTourism.Models.ViewModels;
using ArabianDestinationTourism.Services.Itinerary;
using ArabianDestinationTourism.Services.Recommendation;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace ArabianDestinationTourism.Tests;

public class ConversationalPlannerTests
{
    [Fact]
    public void ElderlyBriefSetsWalkingConstraint()
    {
        var request = new PlannerVm();
        Assert.True(TripBrief.Apply(request,
            "Plan four days for my family of five with AED 6000. My parents are elderly and we avoid long walks.",
            [], out var issue), issue);
        Assert.Equal(5, request.PartySize);
        Assert.Equal(4, request.Days);
        Assert.True(request.LimitedWalking);
    }

    [Fact]
    public async Task ReserveIsParsedAndProtectedFromTripSpending()
    {
        var request = new PlannerVm { StartDate = DateTime.Today.AddDays(7) };
        Assert.True(TripBrief.Apply(request,
            "Plan one day for two people with AED 600. Keep AED 300 as emergency money.",
            [], out var issue), issue);
        Assert.Equal(600m, request.TotalBudget);
        Assert.Equal(300m, request.EmergencyReserve);
        await using var db = Db();
        var result = await new ItineraryPlannerService(db, new RecommendationService(db)).GenerateAsync(request);
        Assert.True(result.TotalEstimatedCost + result.EmergencyReserve <= request.TotalBudget);
    }
    [Fact]
    public void ReadsFamilyBriefAndSeparatesRequiredAndExcludedPlaces()
    {
        var p = new PlannerVm();
        const string brief = "Plan two days for my family of four under AED 1,500 starting 2027-12-12. " +
            "We like history, and afternoons should be indoors. Include the Abra Ride but avoid the Dubai Frame.";
        bool parsed = TripBrief.Apply(p, brief, ["Dubai Frame", "Abra Ride"], out var issue);

        Assert.True(parsed, issue);
        Assert.Null(issue);
        Assert.Equal(2, p.Days);
        Assert.Equal(4, p.PartySize);
        Assert.Equal(1500, p.TotalBudget);
        Assert.Equal(new DateTime(2027, 12, 12), p.StartDate);
        Assert.True(p.IndoorAfternoons);
        Assert.True(p.ChildFriendly);
        Assert.Contains("history", p.Interests);
        Assert.Equal("Abra Ride", p.MustIncludePlaces);
        Assert.Equal("Dubai Frame", p.ExcludedPlaces);
    }

    [Theory]
    [InlineData("For 2 adults under AED 500. I like heritage.", 500)]
    [InlineData("For 2 adults under AED 1,500. I like heritage.", 1500)]
    [InlineData("My budget is 2,500 AED, and I like nature.", 2500)]
    public void ReadsBudgetsNextToSentencePunctuation(string brief, int expected)
    {
        var p = new PlannerVm();

        Assert.True(TripBrief.Apply(p, brief, [], out var issue), issue);
        Assert.Equal(expected, p.TotalBudget);
    }

    [Theory]
    [InlineData("We are two, budget is 3k, days are 4.", 2, 4, 3000)]
    [InlineData("A family of six staying for two nights with a budget of two thousand five hundred dirhams.", 6, 3, 2500)]
    public void ReadsWrittenPartyLengthsAndBudgets(string brief, int travellers, int days, int budget)
    {
        var preferences = new PlannerVm();
        Assert.True(TripBrief.Apply(preferences, brief, [], out var issue), issue);
        Assert.Equal(travellers, preferences.PartySize);
        Assert.Equal(days, preferences.Days);
        Assert.Equal(budget, preferences.TotalBudget);
    }

    [Theory]
    [InlineData("Our group of six includes two adults and three children.")]
    [InlineData("Two or three days with a budget of AED 2000.")]
    [InlineData("I have a budget of AED 200 per person.")]
    public void AsksForClarificationForInconsistentInputs(string brief)
    {
        Assert.False(TripBrief.Apply(new PlannerVm(), brief, [], out var issue));
        Assert.NotNull(issue);
    }

    [Fact]
    public void SixGuestsUseThreeStandardRoomsWithItemizedNightAndStayTotals()
    {
        var hotel = new Hotel { Name = "Rove Downtown", Price = 240 };
        var quote = ArabianDestinationTourism.Services.Pricing.HotelRoomRates.Quote(hotel, 6, 2);
        Assert.NotNull(quote);
        Assert.Equal(3, quote.RoomCount);
        Assert.Equal(720, quote.NightlyTotal);
        Assert.Equal(1440, quote.Total);
        Assert.Equal(240, Assert.Single(quote.Allocation).NightlyRate);
    }

    [Fact]
    public async Task CheaperEditKeepsPinAndOtherDayWhileUpdatingEstimatedCost()
    {
        await using var db = Db();
        var area = new Destination { Name = "Dubai", Slug = "dubai" };
        db.Destinations.Add(area);
        await db.SaveChangesAsync();
        var replacement = new Attraction
        {
            Name = "Gallery", Slug = "gallery", Price = 15, AverageVisitMinutes = 60,
            Latitude = 25.2, Longitude = 55.27, DestinationId = area.Id
        };
        db.Attractions.Add(replacement);
        await db.SaveChangesAsync();
        var p = new PlannerVm { Days = 2, PartySize = 2, TotalBudget = 1500 };
        var pinnedStop = Item(101, "Abra Ride", TimeSpan.FromHours(9), 4, pinned: true);
        var firstDay = new PlannedDayVm
        {
            DayNumber = 1, Date = new DateTime(2027, 2, 15),
            Items = [pinnedStop, Item(102, "Expensive tour", TimeSpan.FromHours(11), 200)]
        };
        var secondDay = new PlannedDayVm
        {
            DayNumber = 2, Date = firstDay.Date.AddDays(1),
            Items = [Item(103, "Beach", TimeSpan.FromHours(9), 0)]
        };
        var result = new ItineraryResultVm
        {
            Days = [firstDay, secondDay], HotelId = 15, AccommodationNights = 1,
            HotelCost = 200, MealCost = 140, TransportCost = 80, AttractionCost = 204,
            TotalEstimatedCost = 624, BudgetRemaining = 876
        };
        var planner = new ItineraryPlannerService(db, new RecommendationService(db));

        var edited = await planner.EditAsync(p, result, "ask", 0, null, 0, "Can you make day 1 cheaper?");

        Assert.True(edited.Changed);
        Assert.Same(pinnedStop, firstDay.Items[0]);
        Assert.Equal(TimeSpan.FromHours(9), pinnedStop.StartTime);
        Assert.True(pinnedStop.IsPinned);
        Assert.Equal(replacement.Id, firstDay.Items[1].ItemId);
        Assert.Same(secondDay, result.Days[1]);
        Assert.Equal("Beach", secondDay.Items.Single().Name);
        Assert.Equal(454, result.TotalEstimatedCost);
        Assert.True(result.IsFeasible);

        var rejected = await planner.EditAsync(p, result, "ask", 0, null, 0, "Remove the Abra Ride.");
        Assert.False(rejected.Changed);
        Assert.Same(pinnedStop, firstDay.Items[0]);
    }

    [Fact]
    public async Task CompletedStopCannotBeRemovedOrUnpinned()
    {
        await using var db = Db();
        var planner = new ItineraryPlannerService(db, new RecommendationService(db));
        var stop = Item(1, "Gallery", TimeSpan.FromHours(9), 20);
        var result = new ItineraryResultVm
        {
            Days = [new PlannedDayVm { DayNumber = 1, Date = DateTime.Today, Items = [stop,
                Item(2, "Beach", TimeSpan.FromHours(11), 0)] }],
            TotalEstimatedCost = 20, BudgetRemaining = 980
        };
        var preferences = new PlannerVm { TotalBudget = 1000 };

        Assert.True((await planner.EditAsync(preferences, result, "complete", 1, "Attraction", 1, null)).Changed);
        Assert.True(stop.IsCompleted);
        Assert.True(stop.IsPinned);
        Assert.False((await planner.EditAsync(preferences, result, "remove", 1, "Attraction", 1, null)).Changed);
        Assert.False((await planner.EditAsync(preferences, result, "unpin", 1, "Attraction", 1, null)).Changed);
        Assert.Contains(stop, result.Days[0].Items);
    }

    [Fact]
    public async Task RequiredStopOutsideOpeningWindowProducesAnExplicitConflict()
    {
        await using var db = Db();
        var area = new Destination { Name = "Dubai", Slug = "dubai" };
        db.Destinations.Add(area);
        await db.SaveChangesAsync();
        db.Attractions.Add(new Attraction
        {
            Name = "Late Gallery", Slug = "late-gallery", Price = 15, AverageVisitMinutes = 60,
            Latitude = 25.2, Longitude = 55.27, DestinationId = area.Id,
            OpeningTime = TimeSpan.FromHours(14), ClosingTime = TimeSpan.FromHours(17)
        });
        await db.SaveChangesAsync();
        var p = new PlannerVm { Days = 1, DailyAvailableHours = 4, MustIncludePlaces = "Late Gallery" };
        var planner = new ItineraryPlannerService(db, new RecommendationService(db));

        var result = await planner.GenerateAsync(p);

        Assert.False(result.IsFeasible);
        Assert.Empty(result.Days.Single().Items);
        Assert.Contains(result.Conflicts, x => x.Contains("Late Gallery", StringComparison.OrdinalIgnoreCase));
    }

    private static ApplicationDbContext Db() => new(new DbContextOptionsBuilder<ApplicationDbContext>()
        .UseInMemoryDatabase(Guid.NewGuid().ToString()).Options);

    private static PlannedItemVm Item(int id, string name, TimeSpan starts, decimal cost, bool pinned = false) => new()
    {
        ItemType = "Attraction", ItemId = id, Name = name, StartTime = starts, Cost = cost,
        IsPinned = pinned, DurationMinutes = 60, Latitude = 25.2, Longitude = 55.27
    };
}
