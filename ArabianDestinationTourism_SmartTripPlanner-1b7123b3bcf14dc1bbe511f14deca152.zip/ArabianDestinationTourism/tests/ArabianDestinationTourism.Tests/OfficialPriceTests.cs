using System.Net;
using System.Text;
using ArabianDestinationTourism.Models.Entities;
using ArabianDestinationTourism.Services.Pricing;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging.Abstractions;
using Xunit;

namespace ArabianDestinationTourism.Tests;

public sealed class OfficialPriceTests
{
    private const string AdultDubaiFramePrice =
        """
        <h2>Admission Fees</h2>
        <ul class="list-prices">
          <li>Adults <span data-adults="">AED 50</span></li>
          <li>Children (3-12 years) <span data-adults="">AED 20</span></li>
        </ul>
        """;

    [Fact]
    public async Task PublishedPriceIdentifiesAdultVariantAndKeepsEstimate()
    {
        using var http = new FakeClientFactory(AdultDubaiFramePrice);
        using var cache = new MemoryCache(new MemoryCacheOptions());
        using var service = NewService(http, cache);
        var attraction = new Attraction { Name = "Dubai Frame", Price = 45 };
        var results = await Task.WhenAll(Enumerable.Range(0, 3)
            .Select(_ => service.CheckAsync("Attraction", 1, attraction, CancellationToken.None)));

        Assert.All(results, result =>
        {
            Assert.Equal("published", result.Status);
            Assert.Equal(45m, result.CatalogueEstimate);
            Assert.Equal(50m, result.OfficialPrice);
            Assert.Equal("per adult", result.Unit);
            Assert.NotNull(result.CheckedAt);
            Assert.Equal("https://www.dubaiframe.ae/en/plan-your-visit", result.SourceUrl);
        });
        Assert.Equal(1, http.RequestCount);
    }

    [Theory]
    [InlineData("""
        <h2>Admission Fees</h2>
        <ul class="list-prices"><li>Adults <span>USD 50</span></li></ul>
        """)]
    [InlineData("""
        <h2>Admission Fees</h2>
        <ul class="list-prices"><li>Children <span>AED 20</span></li></ul>
        """)]
    [InlineData("""
        <h2>Admission Fees</h2>
        <ul class="list-prices"><li>Adults <span>AED 50</span></li></ul>
        <h2>Admission Fees</h2>
        <ul class="list-prices"><li>Adults <span>AED 75</span></li></ul>
        """)]
    [InlineData("""
        <script type="text/html">
        <h2>Admission Fees</h2>
        <ul class="list-prices"><li>Adults <span>AED 50</span></li></ul>
        </script>
        """)]
    public async Task AmbiguousOrUnrelatedPricesStayUnconfirmed(string html)
    {
        using var http = new FakeClientFactory(html);
        using var cache = new MemoryCache(new MemoryCacheOptions());
        using var service = NewService(http, cache);
        var attraction = new Attraction { Name = "Dubai Frame", Price = 45 };

        var result = await service.CheckAsync("Attraction", 1, attraction, CancellationToken.None);

        Assert.Equal("unconfirmed", result.Status);
        Assert.Equal(45m, result.CatalogueEstimate);
        Assert.Null(result.OfficialPrice);
        Assert.NotNull(result.CheckedAt);
    }

    [Fact]
    public async Task HotelRequiresDateSpecificQuoteAndDoesNotUseGenericWebPrices()
    {
        using var http = new FakeClientFactory(AdultDubaiFramePrice);
        using var cache = new MemoryCache(new MemoryCacheOptions());
        using var service = NewService(http, cache);
        var hotel = new Hotel { Name = "Rove Downtown", Price = 300 };

        var result = await service.CheckAsync("Hotel", 4, hotel, CancellationToken.None);

        Assert.Equal("unavailable", result.Status);
        Assert.Equal("per room per night", result.Unit);
        Assert.Equal(300m, result.CatalogueEstimate);
        Assert.Null(result.OfficialPrice);
        Assert.Null(result.CheckedAt);
        Assert.Equal("https://reservations.rovehotels.com/106961", result.SourceUrl);
        Assert.Equal(0, http.RequestCount);
    }

    private static OfficialPriceService NewService(IHttpClientFactory client, IMemoryCache cache) =>
        new(client, cache, NullLogger<OfficialPriceService>.Instance);

    private sealed class FakeClientFactory(string html) : HttpMessageHandler, IHttpClientFactory
    {
        private int _requests;
        public int RequestCount => _requests;
        public HttpClient CreateClient(string name) => new(this, disposeHandler: false);

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,
            CancellationToken cancellationToken)
        {
            Interlocked.Increment(ref _requests);
            await Task.Yield();
            return new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(html, Encoding.UTF8, "text/html")
            };
        }
    }
}
