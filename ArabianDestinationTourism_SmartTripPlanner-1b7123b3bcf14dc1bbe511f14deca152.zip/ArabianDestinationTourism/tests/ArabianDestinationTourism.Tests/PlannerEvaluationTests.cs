using System.Diagnostics;
using ArabianDestinationTourism.Data;
using ArabianDestinationTourism.Models.Entities;
using ArabianDestinationTourism.Models.ViewModels;
using ArabianDestinationTourism.Services.Itinerary;
using ArabianDestinationTourism.Services.Recommendation;
using Microsoft.EntityFrameworkCore;
using Xunit;
using Xunit.Abstractions;

namespace ArabianDestinationTourism.Tests;

public sealed class PlannerEvaluationTests(ITestOutputHelper output)
{
    [Fact]
    public async Task GreedyBaselineAndBeamSearchUseSameScenario()
    {
        var options = new DbContextOptionsBuilder<ApplicationDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString()).Options;
        await using var db = new ApplicationDbContext(options);
        var area = new Destination { Name = "Downtown Dubai", Slug = "downtown-dubai" };
        db.Destinations.Add(area);
        await db.SaveChangesAsync();
        var samples = new[]
        {
            ("Dubai Mall", 0m, 25.1985, 55.2796),
            ("Burj Khalifa", 169m, 25.1972, 55.2744),
            ("Dubai Frame", 50m, 25.2355, 55.3003),
            ("Etihad Museum", 25m, 25.2350, 55.2670),
            ("The Green Planet", 155m, 25.2075, 55.2625),
            ("Dubai Creek", 5m, 25.2684, 55.3072),
            ("Kite Beach", 0m, 25.1621, 55.2084)
        };
        foreach (var (name, price, latitude, longitude) in samples)
            db.Attractions.Add(new Attraction { Name = name, Slug = name.ToLowerInvariant().Replace(' ', '-'),
                DestinationId = area.Id, Price = price, Rating = 4.7, PopularityScore = .9,
                TagsCsv = "culture,family,landmarks", Latitude = latitude, Longitude = longitude,
                AverageVisitMinutes = 90, OpeningTime = TimeSpan.FromHours(9), ClosingTime = TimeSpan.FromHours(21) });
        db.Hotels.Add(new Hotel { Name = "Budget Hotel", Slug = "budget-hotel", DestinationId = area.Id,
            Price = 200m, Rating = 4.5, StarRating = 3, TagsCsv = "budget,family",
            Latitude = 25.2, Longitude = 55.27, FamilyFriendly = true });
        await db.SaveChangesAsync();
        var request = new PlannerVm { Days = 2, PartySize = 2, TotalBudget = 1800,
            EmergencyReserve = 200, StartDate = DateTime.Today.AddDays(7), Interests = "culture,landmarks" };
        var planner = new ItineraryPlannerService(db, new RecommendationService(db));
        var baselineTimer = Stopwatch.StartNew();
        var baseline = await planner.GenerateGreedyBaselineAsync(request);
        baselineTimer.Stop();
        var optimizedTimer = Stopwatch.StartNew();
        var optimized = await planner.GenerateAsync(request);
        optimizedTimer.Stop();
        output.WriteLine($"baseline: {Summary(baseline, request)}, elapsedMs={baselineTimer.Elapsed.TotalMilliseconds:F2}");
        output.WriteLine($"beam search: {Summary(optimized, request)}, elapsedMs={optimizedTimer.Elapsed.TotalMilliseconds:F2}");
        Assert.True(optimized.IsFeasible);
        Assert.Equal(2, optimized.Days.Count);
        Assert.True(optimized.TotalEstimatedCost + optimized.EmergencyReserve <= request.TotalBudget);
    }

    private static string Summary(ItineraryResultVm result, PlannerVm request)
    {
        var stops = result.Days.SelectMany(day => day.Items).ToArray();
        var overlap = result.Days.Sum(day => day.Items.Zip(day.Items.Skip(1), (a, b) =>
            b.StartTime < a.StartTime + TimeSpan.FromMinutes(a.DurationMinutes + b.TravelBufferMinutes) ? 1 : 0).Sum());
        return $"feasible={result.IsFeasible}, days={result.Days.Count}, stops={stops.Length}, " +
            $"estimatedAED={result.TotalEstimatedCost}, budgetViolationAED={Math.Max(0, result.TotalEstimatedCost + result.EmergencyReserve - request.TotalBudget)}, " +
            $"scheduleConflicts={overlap}, travelMinutes={stops.Sum(stop => stop.TravelBufferMinutes)}, " +
            $"averageCatalogueFit={(stops.Length == 0 ? 0 : stops.Average(stop => stop.MatchScore) * 100):F1}%";
    }
}
