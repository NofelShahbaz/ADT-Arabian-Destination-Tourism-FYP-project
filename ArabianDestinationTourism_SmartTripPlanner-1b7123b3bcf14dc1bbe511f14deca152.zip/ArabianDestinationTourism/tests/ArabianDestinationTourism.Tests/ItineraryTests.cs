using ArabianDestinationTourism.Data;
using ArabianDestinationTourism.Models.Entities;
using ArabianDestinationTourism.Models.ViewModels;
using ArabianDestinationTourism.Services.Itinerary;
using ArabianDestinationTourism.Services.Recommendation;
using Microsoft.EntityFrameworkCore;
using Xunit;
namespace ArabianDestinationTourism.Tests;
public class ItineraryTests
{
    static ApplicationDbContext Db()
    {
        var o=new DbContextOptionsBuilder<ApplicationDbContext>().UseInMemoryDatabase(Guid.NewGuid().ToString()).Options;
        return new ApplicationDbContext(o);
    }
    [Fact] public async Task Planner_DoesNotExceed_Budget()
    {
        await using var db=Db();var d=new Destination{Name="Downtown Dubai",Slug="downtown",Latitude=25.2,Longitude=55.27};db.Destinations.Add(d);await db.SaveChangesAsync();
        db.Attractions.AddRange(new Attraction{Name="A",Slug="a",DestinationId=d.Id,Price=100,Rating=5,PopularityScore=1,TagsCsv="culture",Latitude=25.2,Longitude=55.27},new Attraction{Name="B",Slug="b",DestinationId=d.Id,Price=900,Rating=5,PopularityScore=1,TagsCsv="culture",Latitude=25.21,Longitude=55.27});
        db.Hotels.Add(new Hotel{Name="H",Slug="h",DestinationId=d.Id,Price=100,Rating=4.5,PopularityScore=.8,TagsCsv="budget",StarRating=4,Latitude=25.2,Longitude=55.27});
        await db.SaveChangesAsync();
        var rec=new RecommendationService(db);var svc=new ItineraryPlannerService(db,rec);
        var p=new PlannerVm{Days=1,TotalBudget=500,Interests="culture",PreferredHotelStars=4,StartDate=DateTime.Today};
        var r=await svc.GenerateAsync(p);
        Assert.True(r.TotalEstimatedCost<=p.TotalBudget);
    }
    [Fact] public async Task Planner_RespectsDailyTimeLimit()
    {
        await using var db=Db();var d=new Destination{Name="D",Slug="d"};db.Destinations.Add(d);await db.SaveChangesAsync();
        for(int i=0;i<8;i++)db.Attractions.Add(new Attraction{Name="A"+i,Slug="a"+i,DestinationId=d.Id,Price=1,Rating=5,PopularityScore=1,TagsCsv="culture"});
        await db.SaveChangesAsync();
        var svc=new ItineraryPlannerService(db,new RecommendationService(db));var r=await svc.GenerateAsync(new PlannerVm{Days=1,TotalBudget=1000,Interests="culture",DailyAvailableHours=4,PreferredHotelStars=4});
        Assert.True(r.Days.Single().Items.Sum(x=>x.DurationMinutes+x.TravelBufferMinutes)<=240);
    }

    [Fact] public async Task ThreeObjectives_ProduceFeasibleAndDifferentSchedules()
    {
        await using var db = Db();
        var area = new Destination { Name = "Downtown Dubai", Slug = "downtown-dubai", Latitude = 25.2, Longitude = 55.27 };
        db.Destinations.Add(area);
        await db.SaveChangesAsync();
        var places = new[]
        {
            ("Dubai Mall", 0m, 25.1985, 55.2796),
            ("Dubai Frame", 50m, 25.2355, 55.3003),
            ("Burj Khalifa", 169m, 25.1972, 55.2744),
            ("Etihad Museum", 25m, 25.2350, 55.2670),
            ("The Green Planet", 155m, 25.2075, 55.2625)
        };
        foreach (var (name, price, lat, lon) in places)
            db.Attractions.Add(new Attraction { Name = name, Slug = name.ToLowerInvariant().Replace(' ', '-'),
                DestinationId = area.Id, Price = price, Rating = 4.8, PopularityScore = .9,
                TagsCsv = "culture,family,landmarks", Latitude = lat, Longitude = lon,
                AverageVisitMinutes = 90, OpeningTime = TimeSpan.FromHours(9), ClosingTime = TimeSpan.FromHours(21) });
        await db.SaveChangesAsync();
        var planner = new ItineraryPlannerService(db, new RecommendationService(db));
        var request = new PlannerVm { Days = 1, PartySize = 2, TotalBudget = 1500m,
            Interests = "culture,landmarks", StartDate = DateTime.Today.AddDays(7) };
        var alternatives = await planner.GenerateVariantsAsync(request);
        Assert.Equal(3, alternatives.Count);
        Assert.All(alternatives, option =>
        {
            Assert.True(option.Result.IsFeasible);
            Assert.True(option.Result.TotalEstimatedCost <= request.TotalBudget);
            var visits = option.Result.Days.Single().Items.OrderBy(item => item.StartTime).ToArray();
            Assert.Equal(visits.Length, visits.Select(item => item.ItemId).Distinct().Count());
            for (int index = 1; index < visits.Length; index++)
                Assert.True(visits[index].StartTime >= visits[index - 1].StartTime +
                    TimeSpan.FromMinutes(visits[index - 1].DurationMinutes + visits[index].TravelBufferMinutes));
        });
        Assert.True(alternatives.Select(option =>
            string.Join(',', option.Result.Days.Single().Items.Select(item => item.Name))).Distinct().Count() > 1);
    }
    [Fact] public async Task LongTripReservesAtLeastOneDistinctStopPerDay()
    {
        await using var db = Db();
        var area = new Destination { Name = "Dubai", Slug = "dubai" };
        db.Destinations.Add(area);
        await db.SaveChangesAsync();
        for (var index = 0; index < 14; index++)
            db.Attractions.Add(new Attraction { Name = $"Stop {index}", Slug = $"stop-{index}",
                DestinationId = area.Id, Price = 0, Rating = 4.5, PopularityScore = .8,
                TagsCsv = "culture", Latitude = 25.2, Longitude = 55.27,
                AverageVisitMinutes = 60, OpeningTime = TimeSpan.FromHours(9),
                ClosingTime = TimeSpan.FromHours(20) });
        db.Hotels.Add(new Hotel { Name = "Stay", Slug = "stay", DestinationId = area.Id,
            Price = 100, Rating = 4, StarRating = 3, Latitude = 25.2, Longitude = 55.27 });
        await db.SaveChangesAsync();
        var planner = new ItineraryPlannerService(db, new RecommendationService(db));
        var result = await planner.GenerateAsync(new PlannerVm { Days = 14, PartySize = 1,
            TotalBudget = 5000, Interests = "culture", StartDate = DateTime.Today.AddDays(7) });
        Assert.True(result.IsFeasible);
        Assert.Equal(14, result.Days.Count);
        Assert.All(result.Days, day => Assert.Single(day.Items));
    }

    [Fact] public async Task PlannerProtectsLunchIntervalAndExcludesUnconfirmedVenue()
    {
        await using var db = Db();
        var area = new Destination { Name = "Dubai", Slug = "dubai" };
        db.Destinations.Add(area);
        await db.SaveChangesAsync();
        db.Attractions.AddRange(
            new Attraction { Name = "Dubai Mall", Slug = "dubai-mall", DestinationId = area.Id,
                Price = 0, Rating = 4.8, TagsCsv = "shopping", Latitude = 25.2, Longitude = 55.27,
                AverageVisitMinutes = 120, OpeningTime = TimeSpan.FromHours(9), ClosingTime = TimeSpan.FromHours(20) },
            new Attraction { Name = "Museum of the Future", Slug = "museum-future", DestinationId = area.Id,
                Price = 100, Rating = 4.8, TagsCsv = "technology", Latitude = 25.21, Longitude = 55.28,
                AverageVisitMinutes = 120, OpeningTime = TimeSpan.FromHours(9), ClosingTime = TimeSpan.FromHours(20) });
        await db.SaveChangesAsync();
        var planner = new ItineraryPlannerService(db, new RecommendationService(db));
        var result = await planner.GenerateAsync(new PlannerVm { Days = 1, PartySize = 1,
            TotalBudget = 1000, Interests = "shopping,technology", StartDate = DateTime.Today.AddDays(7) });
        Assert.DoesNotContain(result.Days.SelectMany(day => day.Items), item => item.Name == "Museum of the Future");
        Assert.All(result.Days.SelectMany(day => day.Items), item =>
            Assert.False(item.StartTime < new TimeSpan(13, 15, 0) &&
                item.StartTime + TimeSpan.FromMinutes(item.DurationMinutes) > new TimeSpan(12, 30, 0)));
    }

    [Fact] public void VenuePolicySupportsWeeklyAndExceptionDates()
    {
        var policy = new VenueSchedulePolicy
        {
            WeeklyHours = new Dictionary<string, VenueDailyHours>
            { ["Monday"] = new(TimeSpan.FromHours(10), TimeSpan.FromHours(18)) },
            ClosedDates = ["2027-01-04"],
            ClosedPeriods = [new("2027-02-01", "2027-02-03")]
        };
        Assert.True(policy.TryHours(new DateTime(2027, 1, 4), out var open, out var close));
        Assert.Equal(TimeSpan.FromHours(10), open);
        Assert.Equal(TimeSpan.FromHours(18), close);
        Assert.True(policy.IsUnavailableOn(new DateTime(2027, 1, 4)));
        Assert.True(policy.IsUnavailableOn(new DateTime(2027, 2, 2)));
        Assert.False(policy.IsUnavailableOn(new DateTime(2027, 2, 4)));
    }

    [Fact] public void TransportChoiceAffectsGroupCostAndLimitedWalking()
    {
        var walking = EstimatedTravel.Between(25.2, 55.27, 25.204, 55.27, 2,
            TransportPreference.Cheapest, PlanObjective.BudgetSaver, false);
        var taxi = EstimatedTravel.Between(25.2, 55.27, 25.204, 55.27, 6,
            TransportPreference.MinimalWalking, PlanObjective.BestExperience, true);
        Assert.Equal(EstimatedTransportMode.Walking, walking.Mode);
        Assert.Equal(0, walking.GroupCost);
        Assert.Equal(EstimatedTransportMode.Taxi, taxi.Mode);
        Assert.True(taxi.GroupCost > 24m); // Six travellers need two estimated taxis.
        Assert.True(taxi.WalkingKm < walking.WalkingKm);
    }

}
