using ArabianDestinationTourism.Data;
using Xunit;

namespace ArabianDestinationTourism.Tests;

public class EditorialCatalogueTests
{
    [Theory]
    [InlineData("Attraction", "Burj Khalifa")]
    [InlineData("Attraction", "Dubai Opera")]
    [InlineData("Activity", "Desert Safari")]
    [InlineData("Activity", "Tandem Skydiving")]
    [InlineData("Hotel", "Atlantis The Palm")]
    [InlineData("Hotel", "Al Maha Desert Resort")]
    public void PublishedSeedItem_HasRichEditorialContent(string type, string name)
    {
        var profile = PlaceEditorial.For(type, name);
        Assert.True(PlaceEditorial.IsKnown(type, name));
        Assert.True(profile.Intro.Length >= 50);
        Assert.True(profile.Story.Length >= 70);
        Assert.True(profile.WhatToDo.Length >= 70);
        Assert.True(profile.VisitTips.Length >= 65);
        Assert.False(string.IsNullOrWhiteSpace(profile.Hours));
        Assert.True(profile.Photos.Count >= 2);
        Assert.Equal(profile.Photos.Count, profile.Photos.Select(photo => photo.Url).Distinct().Count());
        Assert.All(profile.Photos, photo => Assert.StartsWith("https://", photo.SourceUrl));
    }

    [Fact]
    public void MuseumOfTheFuture_ExplainsCurrentClosure()
    {
        var info = PlaceEditorial.For("Attraction", "Museum of the Future");
        Assert.Contains("closed", info.Alert, StringComparison.OrdinalIgnoreCase);
        Assert.Contains("2027", info.Hours);
    }

    [Fact]
    public void HotelRoomGuide_SpecifiesBeddingAndChildAgeForFamilyRoom()
    {
        var hotel = PlaceEditorial.For("Hotel", "Premier Inn Dubai Al Jaddaf");
        Assert.NotNull(hotel.Rooms);
        Assert.StartsWith("https://mena.premierinn.com/", hotel.Rooms.SourceUrl);
        var family = Assert.Single(hotel.Rooms.Options.Where(room => room.Name == "Family Room"));
        Assert.Contains("trundle", family.Beds);
        Assert.Contains("2 adults and 2 children aged 15 or under", family.Occupancy);
    }
}
