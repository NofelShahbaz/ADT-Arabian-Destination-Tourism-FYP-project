using System.Net;
using System.Text;
using ArabianDestinationTourism.Models.ViewModels;
using ArabianDestinationTourism.Services.Itinerary;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging.Abstractions;
using Xunit;

namespace ArabianDestinationTourism.Tests;

public sealed class TripInterpretationTests
{
    [Fact]
    public void TypedPreferencesAreConstrainedAndUnknownPlacesAreIgnored()
    {
        var extracted = new TripInterpretation
        {
            Days = 4, PartySize = 5, TotalBudgetAed = 6000,
            LimitedWalking = true, PreferredHotelStars = 3,
            RequiredPlaces = ["Dubai Frame", "Invented attraction"],
            Interests = ["culture", "shopping"], Confidence = .91
        };
        var preferences = new PlannerVm();
        extracted.ApplyTo(preferences, ["Dubai Frame"]);
        Assert.Equal(4, preferences.Days);
        Assert.Equal(5, preferences.PartySize);
        Assert.True(preferences.LimitedWalking);
        Assert.Equal("Dubai Frame", preferences.MustIncludePlaces);
        Assert.False(new TripInterpretation { TotalBudgetAed = 200, Confidence = .8 }.IsValid());
    }

    [Theory]
    [InlineData("{}")]
    [InlineData("{\"days\":0,\"confidence\":0.9}")]
    public async Task InvalidOrIncompleteModelOutputFallsBack(string json)
    {
        var envelope = System.Text.Json.JsonSerializer.Serialize(new
        {
            output = new[] { new { content = new[] { new { type = "output_text", text = json } } } }
        });
        var client = new HttpClient(new StaticHandler(envelope)) { BaseAddress = new Uri("https://api.openai.com/v1/") };
        var configuration = new ConfigurationBuilder().AddInMemoryCollection(new Dictionary<string, string?>()).Build();
        var service = new OpenAiTripBriefInterpreter(client, configuration,
            NullLogger<OpenAiTripBriefInterpreter>.Instance);
        Assert.Null(await service.InterpretAsync("Plan a Dubai trip for my family", CancellationToken.None));
    }

    private sealed class StaticHandler(string payload) : HttpMessageHandler
    {
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,
            CancellationToken cancellationToken) => Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK)
        {
            Content = new StringContent(payload, Encoding.UTF8, "application/json")
        });
    }
}
