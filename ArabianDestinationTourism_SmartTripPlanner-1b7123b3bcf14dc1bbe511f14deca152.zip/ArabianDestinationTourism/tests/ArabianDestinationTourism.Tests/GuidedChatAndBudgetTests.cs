using ArabianDestinationTourism.Data;
using ArabianDestinationTourism.Models.Entities;
using ArabianDestinationTourism.Models.ViewModels;
using ArabianDestinationTourism.Services.Itinerary;
using ArabianDestinationTourism.Services.Recommendation;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace ArabianDestinationTourism.Tests;

public class GuidedChatAndBudgetTests
{
    private static ApplicationDbContext EmptyDatabase()
    {
        var options = new DbContextOptionsBuilder<ApplicationDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString()).Options;
        return new ApplicationDbContext(options);
    }

    [Fact]
    public async Task Planner_Rejects_Below500Aed()
    {
        await using var db = EmptyDatabase();
        var service = new ItineraryPlannerService(db, new RecommendationService(db));
        var result = await service.GenerateAsync(new PlannerVm { Days = 1, TotalBudget = 499m });
        Assert.False(result.IsFeasible);
        Assert.Empty(result.Days);
        Assert.NotEmpty(result.Conflicts);
    }

    [Fact]
    public async Task Planner_UsesGroupCost_ForEntryTickets()
    {
        await using var db = EmptyDatabase();
        var area = new Destination { Name = "Downtown Dubai", Slug = "downtown" };
        db.Destinations.Add(area);
        await db.SaveChangesAsync();
        db.Attractions.Add(new Attraction { Name = "Museum", Slug = "museum", DestinationId = area.Id,
            Price = 100m, Rating = 4.8, PopularityScore = 1, TagsCsv = "culture",
            AverageVisitMinutes = 120, Latitude = 25.2, Longitude = 55.3 });
        await db.SaveChangesAsync();
        var service = new ItineraryPlannerService(db, new RecommendationService(db));
        var result = await service.GenerateAsync(new PlannerVm {
            TotalBudget = 500m, Days = 1, PartySize = 2, Interests = "culture"
        });
        Assert.True(result.IsFeasible);
        Assert.Equal(200m, result.AttractionCost); // AED 100 x two travellers
        Assert.Equal(70m, result.MealCost); // AED 35 x two
        Assert.Equal(40m, result.TransportCost); // AED 20 x two
        Assert.Equal(310m, result.TotalEstimatedCost);
        Assert.True(result.TotalEstimatedCost <= 500m);
    }

    [Fact]
    public async Task Planner_DoesNotInvent_AffordableHotel()
    {
        await using var db = EmptyDatabase();
        var area = new Destination { Name = "Dubai Marina", Slug = "marina" };
        db.Destinations.Add(area);
        await db.SaveChangesAsync();
        db.Hotels.Add(new Hotel { Name = "Luxury Only", Slug = "luxury", DestinationId = area.Id,
            Price = 1500m, Rating = 5, StarRating = 5 });
        await db.SaveChangesAsync();
        var service = new ItineraryPlannerService(db, new RecommendationService(db));
        var result = await service.GenerateAsync(new PlannerVm {
            TotalBudget = 500m, Days = 3, PartySize = 2
        });
        Assert.False(result.IsFeasible);
        Assert.Contains(result.Conflicts, x => x.Contains("No hotel"));
    }
}
