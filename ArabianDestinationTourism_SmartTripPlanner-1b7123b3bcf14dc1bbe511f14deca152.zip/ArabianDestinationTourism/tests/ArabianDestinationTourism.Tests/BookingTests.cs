using ArabianDestinationTourism.Data;
using ArabianDestinationTourism.Models.Entities;
using ArabianDestinationTourism.Models.ViewModels;
using ArabianDestinationTourism.Services;
using ArabianDestinationTourism.Services.BookingServices;
using Microsoft.EntityFrameworkCore;
using Xunit;
namespace ArabianDestinationTourism.Tests;
public class BookingTests
{
    [Theory]
    [InlineData("Hotel", 1, 220)]
    [InlineData("Hotel", 3, 440)]
    [InlineData("Activity", 3, 660)]
    public async Task BookingEstimate_UsesTheCataloguedPricingUnit(string category, int travellers, int expectedAmount)
    {
        var options = new DbContextOptionsBuilder<ApplicationDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString()).Options;
        await using var db = new ApplicationDbContext(options);
        var destination = new Destination { Name = "Dubai", Slug = "dubai" };
        TourismItem listing = category == "Hotel"
            ? new Hotel { Name = "Hotel", Slug = "hotel", Price = 220, Destination = destination }
            : new Activity { Name = "Activity", Slug = "activity", Price = 220, Destination = destination };
        db.Add(listing);
        await db.SaveChangesAsync();

        var service = new BookingService(db, new CatalogueService(db));
        var booking = await service.CreateAsync("traveller", new BookingCreateVm
        {
            ServiceType = category,
            ServiceId = listing.Id,
            BookingDate = DateTime.UtcNow.AddDays(3),
            Guests = travellers
        });

        Assert.Equal((decimal)expectedAmount, booking.Amount);
    }

 [Fact] public async Task User_CannotCancel_AnotherUsersBooking()
 {
   var o=new DbContextOptionsBuilder<ApplicationDbContext>().UseInMemoryDatabase(Guid.NewGuid().ToString()).Options;await using var db=new ApplicationDbContext(o);
   db.Bookings.Add(new Booking{UserId="owner",ServiceType="Activity",ServiceId=1,BookingDate=DateTime.Today,Guests=1,Amount=100});await db.SaveChangesAsync();
   var svc=new BookingService(db,new CatalogueService(db));
   await Assert.ThrowsAsync<KeyNotFoundException>(()=>svc.CancelAsync("other",1));
 }
}
