// Run from the solution root: node tests/map-focus-smoke.js
// No browser or third-party test packages are required.
// Exercises the actual Map/Index.cshtml script with a stubbed Leaflet API.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');

const root = path.resolve(__dirname, '..');
const razor = fs.readFileSync(
    path.join(root, 'src/ArabianDestinationTourism/Views/Map/Index.cshtml'),
    'utf8'
);
const scriptMatch = razor.match(/<script>\s*(\(\(\) => \{[\s\S]*?\}\)\(\);)\s*<\/script>/);
assert(scriptMatch, 'Map view must include its focus handler script');

const samplePoints = [
    { type: 'Attraction', Id: 1, Name: 'Burj Khalifa', Latitude: 25.1972, Longitude: 55.2744 },
    { type: 'Hotel', Id: 1, Name: 'Hotel with same ID', Latitude: 25.15, Longitude: 55.17 },
    { type: 'Activity', Id: 2, Name: 'Desert Safari', Latitude: 24.9857, Longitude: 55.6156 }
];
const script = scriptMatch[1].replace(
    /const points = @Html\.Raw\(JsonSerializer\.Serialize\(mapPoints\)\);/,
    `const points = ${JSON.stringify(samplePoints)};`
);

function runCase(query) {
    const elements = new Map();
    const events = {};
    const state = { markers: [], zoom: null, center: null, focusedPopup: null, scrolled: false };
    function el(id = '') {
        if (!elements.has(id)) elements.set(id, {
            textContent: '', className: '',
            classList: { remove: () => {} },
            append: () => {},
            scrollIntoView: () => { state.scrolled = true; }
        });
        return elements.get(id);
    }
    const map = {
        setView(coords, zoom) { state.center = Array.from(coords); state.zoom = zoom; return this; },
        invalidateSize() {}
    };
    const L = {
        map: () => map,
        tileLayer: () => ({ addTo: () => {} }),
        divIcon: options => options,
        marker: (coords, options) => {
            const marker = {
                coords, options,
                addTo() { state.markers.push(this); return this; },
                bindPopup(popup) { this.popup = popup; return this; },
                openPopup() { state.focusedPopup = this; return this; }
            };
            return marker;
        }
    };
    const window = {
        location: { search: query },
        addEventListener: (event, handler) => { events[event] = handler; },
        matchMedia: () => ({ matches: true }),
        setTimeout: () => {}
    };
    const document = {
        readyState: 'loading',
        getElementById: id => el(id),
        createElement: () => ({ textContent: '', className: '', href: '', append: () => {} })
    };

    vm.runInNewContext(script, { document, window, L, URLSearchParams, Number, Math, setTimeout: () => {} });
    events.load?.();
    return { state, elements };
}

const burj = runCase('?focusType=Attraction&focusId=1');
assert.equal(burj.state.zoom, 16);
assert.deepEqual(burj.state.center, [25.1972, 55.2744]);
assert.equal(burj.state.focusedPopup?.coords[0], 25.1972);
assert.equal(burj.elements.get('map-focus-name').textContent, 'Burj Khalifa');
assert(burj.state.scrolled);

const hotel = runCase('?focusType=Hotel&focusId=1');
assert.deepEqual(hotel.state.center, [25.15, 55.17]); // ID alone must not match the attraction.
assert.equal(hotel.elements.get('map-focus-name').textContent, 'Hotel with same ID');

const activity = runCase('?focusType=Activity&focusId=2');
assert.deepEqual(activity.state.center, [24.9857, 55.6156]);
assert.equal(activity.elements.get('map-focus-name').textContent, 'Desert Safari');

const defaultMap = runCase('');
assert.equal(defaultMap.state.zoom, 10);
assert.equal(defaultMap.state.focusedPopup, null);
assert.equal(defaultMap.state.markers.length, 3);

const broken = runCase('?focusType=Attraction&focusId=99999');
assert.equal(broken.state.zoom, 10);
assert.equal(broken.state.focusedPopup, null);

const sharedDetails = fs.readFileSync(
    path.join(root, 'src/ArabianDestinationTourism/Views/Shared/_PlaceDetails.cshtml'),
    'utf8'
);
assert.match(sharedDetails, /Url\.Action\("Index", "Map", new \{ focusType = kind, focusId = Model\.Id \}\)/);
for (const [section, type] of [['Attractions','Attraction'],['Hotels','Hotel'],['Activities','Activity']]) {
    const view = fs.readFileSync(path.join(root, `src/ArabianDestinationTourism/Views/${section}/Details.cshtml`), 'utf8');
    assert(view.includes(`@model ${type}`), `${section} must pass the expected type`);
    assert.match(view, /<partial name="_PlaceDetails" model="Model"\s*\/>/);
}
console.log('Map deep-link checks passed: attraction, hotel, activity, default, unavailable ID, and all 3 detail links.');
