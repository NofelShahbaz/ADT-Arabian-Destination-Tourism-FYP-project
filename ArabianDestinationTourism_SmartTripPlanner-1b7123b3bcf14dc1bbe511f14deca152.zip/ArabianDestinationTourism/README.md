# Arabian Destination Tourism

A Dubai trip planner with an editable day-by-day itinerary, map, and shared group budget. Visitors can start from a written brief or the manual form, keep stops in place, request a cheaper replacement, and save the revised trip to their account.

## Run locally

This option uses Docker Engine and Compose v2.24.4 or later. The bundled SQL Server container requires an x64 Linux host or compatible x64 emulation.

1. Copy `.env.example` to `.env` and set a long, unique `MSSQL_SA_PASSWORD`. Include uppercase and lowercase letters, digits, and a symbol.
2. Set `ADMIN_EMAIL` and a separate `ADMIN_PASSWORD` to enable the admin account and venue review queue.
3. Run `docker compose up --build -d`.
4. Open [http://localhost:8080](http://localhost:8080). The first startup creates the database and seeds the Dubai catalogue.

The database and application key volumes survive a normal `docker compose down`. Back up the SQL Server database and key volume before replacing or migrating them.

### Existing SQL Server or LocalDB

Install the .NET 10 SDK and use the same SQL Server instance **and database name** on every run. The development default is `localhost\SQLEXPRESS02` with database `ArabianDestinationTourism`, matching the earlier Windows setup. Set `ConnectionStrings__DefaultConnection` if your existing accounts live in another database. Never change this value between runs unless you intend to switch accounts and saved trips. Back up the database before upgrading.

```sh
dotnet restore ArabianDestinationTourism.sln
dotnet build ArabianDestinationTourism.sln -c Release
dotnet test ArabianDestinationTourism.sln -c Release --no-build
dotnet run --project src/ArabianDestinationTourism
```

For VS Code on Windows with an existing SQL Express instance, open the extracted project folder and choose **Terminal → New Terminal**. Run these PowerShell commands. Replace `SQLEXPRESS02` if you use a different instance, and use your existing database name if you want to keep its accounts and saved trips.

```powershell
$env:ConnectionStrings__DefaultConnection = 'Server=localhost\SQLEXPRESS02;Database=ArabianDestinationTourism;Trusted_Connection=True;TrustServerCertificate=True'
dotnet restore ArabianDestinationTourism.sln
dotnet run --project .\src\ArabianDestinationTourism --launch-profile https
```

Open the HTTPS address displayed in the terminal. If your browser does not trust the development certificate, run `dotnet dev-certs https --trust` first.

The app preserves the existing database schema. For managed SQL Server, give the application a dedicated database and account. Use encrypted connections and a trusted server certificate.

## Deploy with HTTPS

On an x64 Docker host, point a domain's DNS record to the host and allow inbound TCP 80 and 443. Set `ADT_DOMAIN` in `.env`, then run:

```sh
docker compose -f compose.yaml -f compose.production.yaml up --build -d
```

Caddy provisions HTTPS. The bundled database stays on the Docker network. The app runs as a non-root user. `/health/live` checks the process and `/health/ready` checks the database. For a different reverse proxy, configure `Deployment__TrustedProxy` with that proxy's IP and persist `Deployment__DataProtectionKeys`. The short sign-in handoff for guest drafts uses server memory, so use a single app replica or sticky routing for that flow.

## Trip planner and prices

- The trip planner accepts written requests and produces an editable day-by-day itinerary. With an OpenAI API key, the model returns typed preferences and selects relevant catalogue stops; the traveller can review and correct the extracted fields before generation. The planner checks the proposed stops against available catalogue schedules, route estimates, room count, and group budget. Nearby restaurant suggestions appear by day. Try **“Two days for four people under AED 1,500. We like history and want to visit the Abra Ride.”**
- The bounded beam search explores multiple feasible schedules with different priorities for cost, between-stop travel, and catalogue fit. The result page compares three plans and lets the traveller select one. The what-if panel recalculates the plan for budget, days, group size, hotel category, walking, indoor afternoons, transport preference, interests, and emergency reserve. Guests can keep an emergency amount unspent. Edits show a proposed change before the traveller accepts it. Completed stops are protected within the active draft. `PlannerEvaluationTests` measures this search against the retained greedy baseline on the same scenario; its output is a repeatable sample, not a general performance claim.
- Set `TRIP_ASSISTANT_API_KEY` and optionally `TRIP_ASSISTANT_MODEL` in Compose. Outside Compose, set `TripAssistant__ApiKey` and `TripAssistant__Model`. The key enables OpenAI interpretation and place selection in the trip planner. The app keeps its API key on the server. Configure an OpenAI account with billing before using these features. Without a key, the local planner still accepts supported phrases.
- Prices throughout the catalogue and itinerary budget are estimates. Confirm current rates and availability on each venue's official booking website before paying.
- Allow outbound HTTPS to the official provider pages for live checks. Deployments with a trusted egress proxy can enable `OfficialPrices__UseSystemProxy=true` or set `ADT_PRICES_USE_SYSTEM_PROXY=true` in Compose. Provider requests use curated venue URLs.
- Map lines illustrate stop order. Travel times and mode-specific costs use approximate distance formulas, not live routing or fares. The operator is the source for final availability, prices, and accessibility details. Venue schedule exceptions are held in `Data/venue-schedules.json`; generic catalogue hours are provisional and the itinerary labels them as unverified.
- Booking actions open the provider’s official reservation page when available. Provider websites handle availability, payments and confirmation.

Homepage route imagery is illustrative. The build includes local Bootstrap, Bootstrap Icons, Leaflet, and fonts with their licenses alongside the assets.

## Catalogue photo and room guides

Catalogue galleries identify the specific destination or property. Experience photos can show an example provider. Wikimedia Commons photos include their author, licence and original source, and are resized in this project. Photos sourced from hotel and venue pages are linked to their publishers and load over the internet. Check the rights for those photos before redistributing the website publicly.

Hotel room guides cite the official hotel pages. They include published bedding, occupancy, child age limits and room size where available. Hotel booking forms remain the source for exact guest eligibility and room availability. The planner shows its order of decisions, starting with meals and transport. Accommodation calculations itemize room count, nightly rate and stay total. The calculation uses documented rated room capacities where verified and a clearly labelled standard-room estimate where available. Room variants with dynamic rates link to the hotel’s booking form. Child ages and room allocations need to be confirmed there.

## Weather and dining

The Weather page shows current conditions and the seven-day Open-Meteo forecast when available, plus NOAA 1991–2020 Dubai airport monthly climate averages and a link to the UAE weather authority. To serve forecast data in production, set `WEATHER_API_KEY` in Compose or `Weather__CustomerApiKey` when launching the app directly, using a commercial Open-Meteo customer key. The Dining directory links to restaurant websites, menus, reservations and maps.

## Email password recovery

Set `SMTP_HOST`, `SMTP_PORT`, `SMTP_FROM`, `SMTP_USER` and `SMTP_PASSWORD` in the production Compose environment using your SMTP provider. Outside Compose, use `Mail__Host`, `Mail__Port`, `Mail__From`, `Mail__User`, `Mail__Password` and `Mail__StartTls=true`. Set `Deployment__PublicBaseUrl` to your public HTTPS origin outside the production Compose overlay. Configure the sender address or domain with your mail provider, and verify delivery to your own inbox before inviting users. The recovery link expires after one hour.

## Reference points

[Visit Dubai](https://www.visitdubai.com/en/things-to-do/eat-and-drink) and the [MICHELIN Guide](https://guide.michelin.com/en/ae/dubai-emirate/dubai/restaurants) provide dining discovery. [Emirates Dubai Experience](https://www.emirates.com/uk/english/dubai-experience/how-it-works/) combines travel products. ADT brings room counts, group budgets, itinerary decisions and clear group estimates into one editable plan.
