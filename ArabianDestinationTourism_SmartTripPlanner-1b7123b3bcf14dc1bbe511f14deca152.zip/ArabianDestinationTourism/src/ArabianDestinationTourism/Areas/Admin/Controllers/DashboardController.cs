using ArabianDestinationTourism.Data;
using ArabianDestinationTourism.Models.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace ArabianDestinationTourism.Areas.Admin.Controllers;
[Area("Admin"),Authorize(Roles="Admin")]
public class DashboardController(ApplicationDbContext db):Controller
{
 public async Task<IActionResult> Index(){ViewBag.Users=await db.Users.CountAsync();ViewBag.Attractions=await db.Attractions.CountAsync();ViewBag.Hotels=await db.Hotels.CountAsync();ViewBag.Activities=await db.Activities.CountAsync();ViewBag.Bookings=await db.Bookings.CountAsync();ViewBag.Revenue=await db.Payments.Where(x=>x.Status==PaymentStatus.Successful).SumAsync(x=>(decimal?)x.Amount)??0;ViewBag.PendingReviews=await db.Reviews.CountAsync(x=>!x.IsApproved);ViewBag.Messages=await db.ChatMessages.CountAsync();return View();}
 public async Task<IActionResult> Reviews()=>View(await db.Reviews.OrderByDescending(x=>x.CreatedAt).ToListAsync());
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> ApproveReview(int id){var r=await db.Reviews.FindAsync(id);if(r!=null){r.IsApproved=true;await db.SaveChangesAsync();}return RedirectToAction(nameof(Reviews));}
 public async Task<IActionResult> Bookings()=>View(await db.Bookings.Include(x=>x.Payment).OrderByDescending(x=>x.CreatedAt).ToListAsync());
 public async Task<IActionResult> AuditLogs()=>View(await db.AuditLogs.OrderByDescending(x=>x.CreatedAt).Take(500).ToListAsync());
}
