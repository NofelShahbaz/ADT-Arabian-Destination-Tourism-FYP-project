using ArabianDestinationTourism.Data;
using ArabianDestinationTourism.Models.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ArabianDestinationTourism.Areas.Admin.Controllers;

[Area("Admin"), Authorize(Roles = "Admin")]
public class AttractionsController(ApplicationDbContext db) : Controller
{
    public async Task<IActionResult> Index() => View(await db.Attractions.Include(x => x.Destination).OrderBy(x => x.Name).ToListAsync());

    [HttpGet]
    public async Task<IActionResult> Create()
    {
        ViewBag.Destinations = await db.Destinations.OrderBy(x => x.Name).ToListAsync();
        return View("Edit", new Attraction());
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var attraction = await db.Attractions.FindAsync(id);
        if (attraction is null) return NotFound();
        ViewBag.Destinations = await db.Destinations.OrderBy(x => x.Name).ToListAsync();
        return View(attraction);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit([Bind("Id,Name,Slug,ShortDescription,Description,DestinationId,Price,Rating,OpeningTime,ClosingTime,AverageVisitMinutes,Latitude,Longitude,ImageUrl,TagsCsv,PopularityScore,Status,CategoryName,FamilyFriendly,AccessibilityFriendly")] Attraction input)
    {
        var destinations = await db.Destinations.OrderBy(x => x.Name).ToListAsync();
        if (!destinations.Any(destination => destination.Id == input.DestinationId))
            ModelState.AddModelError(nameof(input.DestinationId), "Choose a destination from the list.");
        if (input.Price < 0 || input.Price > 1_000_000)
            ModelState.AddModelError(nameof(input.Price), "Enter an estimated price from AED 0 to AED 1,000,000.");
        if (!ModelState.IsValid)
        {
            ViewBag.Destinations = destinations;
            return View(input);
        }

        if (input.Id == 0)
        {
            db.Attractions.Add(input);
        }
        else
        {
            var attraction = await db.Attractions.FindAsync(input.Id);
            if (attraction is null) return NotFound();
            var detailsChanged = attraction.Name != input.Name
                || attraction.DestinationId != input.DestinationId
                || attraction.Price != input.Price
                || attraction.OpeningTime != input.OpeningTime
                || attraction.ClosingTime != input.ClosingTime
                || attraction.AverageVisitMinutes != input.AverageVisitMinutes
                || attraction.FamilyFriendly != input.FamilyFriendly
                || attraction.AccessibilityFriendly != input.AccessibilityFriendly;
            input.LastVerifiedDate = detailsChanged ? null : attraction.LastVerifiedDate;
            input.SourceNote = attraction.SourceNote;
            input.Currency = attraction.Currency;
            input.Capacity = attraction.Capacity;
            input.CreatedAt = attraction.CreatedAt;
            input.UpdatedAt = DateTime.UtcNow;
            db.Entry(attraction).CurrentValues.SetValues(input);
        }

        await db.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Archive(int id)
    {
        var attraction = await db.Attractions.FindAsync(id);
        if (attraction is not null)
        {
            attraction.Status = RecordStatus.Archived;
            attraction.UpdatedAt = DateTime.UtcNow;
            await db.SaveChangesAsync();
        }
        return RedirectToAction(nameof(Index));
    }
}
