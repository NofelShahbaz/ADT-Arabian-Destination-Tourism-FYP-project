using System.Security.Claims;
using ArabianDestinationTourism.Data;
using ArabianDestinationTourism.Models.Entities;
using ArabianDestinationTourism.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ArabianDestinationTourism.Areas.Admin.Controllers;

[Area("Admin"), Authorize(Roles = "Admin")]
public sealed class VerificationController(ApplicationDbContext db) : Controller
{
    [HttpGet]
    public async Task<IActionResult> Index(bool all = false, CancellationToken cancellationToken = default)
    {
        var attractions = await db.Attractions.AsNoTracking().Include(x => x.Destination)
            .Where(x => x.Status == RecordStatus.Published).ToListAsync(cancellationToken);
        var activities = await db.Activities.AsNoTracking().Include(x => x.Destination)
            .Where(x => x.Status == RecordStatus.Published).ToListAsync(cancellationToken);
        var hotels = await db.Hotels.AsNoTracking().Include(x => x.Destination)
            .Where(x => x.Status == RecordStatus.Published).ToListAsync(cancellationToken);

        var today = DateTime.UtcNow.Date;
        var listings = attractions.Select(item => Describe("Attraction", item))
            .Concat(activities.Select(item => Describe("Activity", item)))
            .Concat(hotels.Select(item => Describe("Hotel", item)))
            .OrderBy(listing => listing.ReviewedAt)
            .ThenBy(listing => listing.Item.Name, StringComparer.OrdinalIgnoreCase)
            .ToList();
        var due = listings.Where(listing => listing.IsDue(today)).ToList();
        return View(new CatalogueVerificationQueue(all ? listings : due, due.Count, all, today));
    }

    [HttpGet]
    public async Task<IActionResult> Review(string category, int id, CancellationToken cancellationToken)
    {
        var item = await FindPublishedAsync(category, id, cancellationToken);
        if (item is null) return NotFound();
        return View(new CatalogueReviewPage(Describe(category, item), new CatalogueReviewInput
        {
            SourceNote = item.SourceNote ?? "",
            UpdatedAtTicks = item.UpdatedAt.Ticks
        }));
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Review(string category, int id, [Bind(Prefix = "Review")] CatalogueReviewInput review,
        CancellationToken cancellationToken)
    {
        var item = await FindPublishedAsync(category, id, cancellationToken);
        if (item is null) return NotFound();
        var listing = Describe(category, item);
        if (!review.ConfirmSource)
            ModelState.AddModelError("Review.ConfirmSource", "Confirm that you checked the official source before recording this review.");
        if (review.UpdatedEstimate is decimal estimate && decimal.Round(estimate, 2) != estimate)
            ModelState.AddModelError("Review.UpdatedEstimate", "Enter an estimate with at most two decimal places.");
        if (item.UpdatedAt.Ticks != review.UpdatedAtTicks)
        {
            ModelState.AddModelError(string.Empty, "The listing changed while you were reviewing it. Check the latest details before submitting again.");
            ModelState.Remove("Review.UpdatedAtTicks");
            review.UpdatedAtTicks = item.UpdatedAt.Ticks;
        }
        if (!ModelState.IsValid) return View(new CatalogueReviewPage(listing, review));

        var now = DateTime.UtcNow;
        decimal previousEstimate = item.Price;
        if (review.UpdatedEstimate.HasValue)
            item.Price = review.UpdatedEstimate.Value;
        item.SourceNote = review.SourceNote.Trim();
        item.LastVerifiedDate = now;
        item.UpdatedAt = now;
        db.AuditLogs.Add(new AuditLog
        {
            UserId = User.FindFirstValue(ClaimTypes.NameIdentifier),
            Action = "Catalogue review recorded",
            EntityType = category,
            Details = item.Price == previousEstimate
                ? $"#{item.Id}: {item.Name}"
                : $"#{item.Id}: {item.Name}. Estimate changed from AED {previousEstimate:0.00} to AED {item.Price:0.00}."
        });
        await db.SaveChangesAsync(cancellationToken);
        TempData["CatalogueReviewMessage"] = $"Review recorded for {item.Name}.";
        return RedirectToAction(nameof(Index));
    }

    private async Task<TourismItem?> FindPublishedAsync(string category, int id, CancellationToken cancellationToken)
    {
        return category switch
        {
            "Attraction" => await db.Attractions.Include(x => x.Destination)
                .FirstOrDefaultAsync(x => x.Id == id && x.Status == RecordStatus.Published, cancellationToken),
            "Activity" => await db.Activities.Include(x => x.Destination)
                .FirstOrDefaultAsync(x => x.Id == id && x.Status == RecordStatus.Published, cancellationToken),
            "Hotel" => await db.Hotels.Include(x => x.Destination)
                .FirstOrDefaultAsync(x => x.Id == id && x.Status == RecordStatus.Published, cancellationToken),
            _ => null
        };
    }

    private static CatalogueVerificationListing Describe(string category, TourismItem item)
    {
        var profile = PlaceEditorial.For(category, item.Name);
        var url = Uri.TryCreate(profile.OfficialUrl, UriKind.Absolute, out var officialUrl)
            && officialUrl.Scheme == Uri.UriSchemeHttps ? officialUrl.AbsoluteUri : null;
        var date = string.IsNullOrWhiteSpace(item.SourceNote) ? null : item.LastVerifiedDate;
        return new CatalogueVerificationListing(category, item, url, date);
    }
}
