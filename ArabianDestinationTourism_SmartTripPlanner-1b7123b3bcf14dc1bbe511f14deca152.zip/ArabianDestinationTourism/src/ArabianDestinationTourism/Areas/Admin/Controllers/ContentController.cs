using ArabianDestinationTourism.Data;
using ArabianDestinationTourism.Models.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace ArabianDestinationTourism.Areas.Admin.Controllers;

[Area("Admin"),Authorize(Roles="Admin")]
public class ContentController(ApplicationDbContext db) : Controller
{
    public async Task<IActionResult> Hotels()=>View("Hotels",await db.Hotels.Include(x=>x.Destination).OrderBy(x=>x.Name).ToListAsync());
    public async Task<IActionResult> Activities()=>View("Activities",await db.Activities.Include(x=>x.Destination).OrderBy(x=>x.Name).ToListAsync());
    public async Task<IActionResult> Destinations()=>View("Destinations",await db.Destinations.OrderBy(x=>x.Name).ToListAsync());
    public async Task<IActionResult> Categories()=>View("Categories",await db.Categories.OrderBy(x=>x.Type).ThenBy(x=>x.Name).ToListAsync());
    public async Task<IActionResult> InterestTags()=>View("InterestTags",await db.InterestTags.OrderBy(x=>x.Name).ToListAsync());

    [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> ArchiveHotel(int id){var x=await db.Hotels.FindAsync(id);if(x!=null){x.Status=RecordStatus.Archived;await db.SaveChangesAsync();}return RedirectToAction(nameof(Hotels));}
    [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> ArchiveActivity(int id){var x=await db.Activities.FindAsync(id);if(x!=null){x.Status=RecordStatus.Archived;await db.SaveChangesAsync();}return RedirectToAction(nameof(Activities));}
    [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> AddDestination(string name,string slug,double latitude,double longitude){if(!string.IsNullOrWhiteSpace(name)&&!string.IsNullOrWhiteSpace(slug)){db.Destinations.Add(new Destination{Name=name,Slug=slug,Latitude=latitude,Longitude=longitude});await db.SaveChangesAsync();}return RedirectToAction(nameof(Destinations));}
    [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> AddCategory(string name,string type){if(!string.IsNullOrWhiteSpace(name)){db.Categories.Add(new Category{Name=name,Type=type});await db.SaveChangesAsync();}return RedirectToAction(nameof(Categories));}
    [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> AddTag(string name){if(!string.IsNullOrWhiteSpace(name)){db.InterestTags.Add(new InterestTag{Name=name});await db.SaveChangesAsync();}return RedirectToAction(nameof(InterestTags));}
}
[Area("Admin"),Authorize(Roles="Admin")]
public class UsersController(UserManager<ApplicationUser> users) : Controller
{
    public IActionResult Index()=>View(users.Users.OrderBy(x=>x.Email).ToList());
}
