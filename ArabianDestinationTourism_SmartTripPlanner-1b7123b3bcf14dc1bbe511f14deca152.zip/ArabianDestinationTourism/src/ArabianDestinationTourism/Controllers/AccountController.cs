using ArabianDestinationTourism.Models.Entities;
using ArabianDestinationTourism.Models.ViewModels;
using ArabianDestinationTourism.Services.Accounts;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.AspNetCore.WebUtilities;
using System.Text;
namespace ArabianDestinationTourism.Controllers;
[ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
public class AccountController(UserManager<ApplicationUser> users, SignInManager<ApplicationUser> signIn,
    PasswordRecovery recovery):Controller
{
    [HttpGet] public IActionResult Register(string? returnUrl = null)
    {
        SetReturnUrl(returnUrl);
        return View(new RegisterVm());
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Register(RegisterVm vm, string? returnUrl = null)
    {
        SetReturnUrl(returnUrl);
        if (!ModelState.IsValid) return View(vm);
        var address = vm.Email.Trim();
        var user = new ApplicationUser { UserName = address, Email = address, FullName = vm.FullName.Trim(), EmailConfirmed = true };
        var result = await users.CreateAsync(user, vm.Password);
        if (result.Succeeded)
        {
            await users.AddToRoleAsync(user, "Tourist");
            await signIn.SignInAsync(user, false);
            return ContinueTo(returnUrl);
        }
        foreach (var error in result.Errors) ModelState.AddModelError("", error.Description);
        return View(vm);
    }

    [HttpGet] public IActionResult Login(string? returnUrl = null)
    {
        SetReturnUrl(returnUrl);
        return View(new LoginVm());
    }

    [HttpPost, ValidateAntiForgeryToken, EnableRateLimiting("account-login")]
    public async Task<IActionResult> Login(LoginVm vm, string? returnUrl = null)
    {
        SetReturnUrl(returnUrl);
        if (!ModelState.IsValid) return View(vm);
        var user = await users.FindByEmailAsync(vm.Email.Trim());
        if (user is not null)
        {
            var result = await signIn.PasswordSignInAsync(user, vm.Password, vm.RememberMe, lockoutOnFailure: true);
            if (result.Succeeded) return ContinueTo(returnUrl);
            if (result.IsLockedOut)
            {
                var until = await users.GetLockoutEndDateAsync(user);
                ModelState.AddModelError("", until.HasValue
                    ? $"Too many sign-in attempts. Try again after {until.Value.ToOffset(TimeSpan.FromHours(4)):HH:mm} Dubai time, or reset your password."
                    : "Too many sign-in attempts. Please try again later or reset your password.");
                return View(vm);
            }
        }
        ModelState.AddModelError("", "We couldn’t sign you in. Check your email and password, or use password recovery.");
        return View(vm);
    }

    private void SetReturnUrl(string? returnUrl) =>
        ViewBag.ReturnUrl = Url.IsLocalUrl(returnUrl) ? returnUrl : null;

    private IActionResult ContinueTo(string? returnUrl) =>
        Url.IsLocalUrl(returnUrl) ? LocalRedirect(returnUrl!) : RedirectToAction("Index", "Dashboard");
    [Authorize,HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> Logout(){await signIn.SignOutAsync();return RedirectToAction("Index","Home");}
    [HttpGet]
    public IActionResult ForgotPassword()
    {
        ViewData["RecoveryAvailable"] = recovery.IsConfigured;
        return View(new ForgotPasswordVm());
    }

    [HttpPost, ValidateAntiForgeryToken, EnableRateLimiting("account-recovery")]
    public IActionResult ForgotPassword(ForgotPasswordVm request)
    {
        ViewData["RecoveryAvailable"] = recovery.IsConfigured;
        if (!ModelState.IsValid) return View(request);
        if (!recovery.Queue(request.Email.Trim()))
        {
            ModelState.AddModelError("", "Password recovery is temporarily unavailable. Try again later.");
            return View(request);
        }

        TempData["AccountMessage"] = "If that email belongs to an account, a password reset link will arrive shortly.";
        return RedirectToAction(nameof(ForgotPassword));
    }

    [HttpGet]
    public IActionResult ResetPassword(string? userId, string? code)
    {
        Response.Headers["Referrer-Policy"] = "no-referrer";
        if (string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(code) || code.Length > 2048)
            return RedirectToAction(nameof(ForgotPassword));
        return View(new ResetPasswordVm { UserId = userId, Code = code });
    }

    [HttpPost, ValidateAntiForgeryToken, EnableRateLimiting("account-recovery")]
    public async Task<IActionResult> ResetPassword(ResetPasswordVm request)
    {
        Response.Headers["Referrer-Policy"] = "no-referrer";
        if (!ModelState.IsValid) return View(request);
        var user = await users.FindByIdAsync(request.UserId);
        if (user is not null)
        {
            try
            {
                var token = Encoding.UTF8.GetString(WebEncoders.Base64UrlDecode(request.Code));
                var result = await users.ResetPasswordAsync(user, token, request.Password);
                if (result.Succeeded)
                {
                    await signIn.SignOutAsync();
                    TempData["AccountMessage"] = "Your password was changed. Sign in with your new password.";
                    return RedirectToAction(nameof(Login));
                }
                if (result.Errors.All(error => error.Code != nameof(IdentityErrorDescriber.InvalidToken)))
                {
                    foreach (var error in result.Errors) ModelState.AddModelError("", error.Description);
                    return View(request);
                }
            }
            catch (FormatException) { }
        }

        ModelState.AddModelError("", "This link is invalid or expired. Request a new password reset link.");
        return View(request);
    }
    public IActionResult AccessDenied()=>View();
}
