using ArabianDestinationTourism.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
namespace ArabianDestinationTourism.Controllers;
public class MapController(ICatalogueService c):Controller{
 public async Task<IActionResult> Index(){ViewBag.Attractions=await c.GetAttractionsAsync();ViewBag.Activities=await c.GetActivitiesAsync();ViewBag.Hotels=await c.GetHotelsAsync();return View();}
}
