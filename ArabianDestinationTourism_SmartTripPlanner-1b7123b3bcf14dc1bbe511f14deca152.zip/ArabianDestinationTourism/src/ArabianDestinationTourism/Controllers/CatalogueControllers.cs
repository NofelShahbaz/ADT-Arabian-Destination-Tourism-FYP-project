using ArabianDestinationTourism.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
namespace ArabianDestinationTourism.Controllers;
public class AttractionsController(ICatalogueService c):Controller{
 public async Task<IActionResult> Index(string? q,string? area,string? tag)=>View(await c.GetAttractionsAsync(q,area,tag));
 public async Task<IActionResult> Details(int id){var x=await c.GetAttractionAsync(id);return x==null?NotFound():View(x);}
}
public class ActivitiesController(ICatalogueService c):Controller{
 public async Task<IActionResult> Index(string? q,string? area,string? tag)=>View(await c.GetActivitiesAsync(q,area,tag));
 public async Task<IActionResult> Details(int id){var x=await c.GetActivityAsync(id);return x==null?NotFound():View(x);}
}
public class HotelsController(ICatalogueService c):Controller{
 public async Task<IActionResult> Index(string? q,string? area,int? stars)=>View(await c.GetHotelsAsync(q,area,stars));
 public async Task<IActionResult> Details(int id){var x=await c.GetHotelAsync(id);return x==null?NotFound():View(x);}
}
public class SearchController(ICatalogueService c):Controller{
 public async Task<IActionResult> Index(string? q,string? area,string? tag,int? stars){ViewBag.Q=q;ViewBag.Attractions=await c.GetAttractionsAsync(q,area,tag);ViewBag.Activities=await c.GetActivitiesAsync(q,area,tag);ViewBag.Hotels=await c.GetHotelsAsync(q,area,stars);return View();}
}
