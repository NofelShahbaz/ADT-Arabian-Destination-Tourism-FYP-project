using ArabianDestinationTourism.Services.Weather;
using Microsoft.AspNetCore.Mvc;

namespace ArabianDestinationTourism.Controllers;

public class WeatherController(DubaiWeather weather) : Controller
{
    public async Task<IActionResult> Index(CancellationToken cancellationToken) => View(await weather.ForecastAsync(cancellationToken));
}
