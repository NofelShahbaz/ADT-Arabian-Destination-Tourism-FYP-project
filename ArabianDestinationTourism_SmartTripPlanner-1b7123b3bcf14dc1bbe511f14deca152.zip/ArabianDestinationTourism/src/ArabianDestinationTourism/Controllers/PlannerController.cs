using System.Security.Cryptography;
using System.Text.Json;
using ArabianDestinationTourism.Data;
using ArabianDestinationTourism.Models.Entities;
using ArabianDestinationTourism.Models.ViewModels;
using ArabianDestinationTourism.Services.Interfaces;
using ArabianDestinationTourism.Services.Itinerary;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;

namespace ArabianDestinationTourism.Controllers;

[ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
public class PlannerController(
    IItineraryPlannerService planner,
    UserManager<ApplicationUser> users,
    ApplicationDbContext db,
    IDataProtectionProvider protection,
    IMemoryCache cache,
    IEnumerable<ITripBriefInterpreter> interpreters,
    OpenAiTripDesigner tripDesigner) : Controller
{
    private const int MaximumBriefLength = 800;
    private const int MaximumTokenLength = 128_000;
    private const string BrowserCookie = "adt-trip-browser";
    private static readonly TimeSpan DraftLifetime = TimeSpan.FromHours(3);
    private record Draft(PlannerVm Preferences, ItineraryResultVm Result, string? Owner);
    private record Handoff(string Token, string BrowserKey);

    [HttpGet]
    public IActionResult Index(decimal? totalBudget = null, int? days = null, int? partySize = null,
        string? interests = null, int? preferredHotelStars = null, bool? childFriendly = null, string? brief = null)
    {
        var vm = new PlannerVm
        {
            TotalBudget = totalBudget.HasValue ? Math.Clamp(totalBudget.Value, 500m, 100000m) : 3000m,
            Days = days.HasValue ? Math.Clamp(days.Value, 1, 14) : 3,
            PartySize = partySize.HasValue ? Math.Clamp(partySize.Value, 1, 20) : 2,
            PreferredHotelStars = preferredHotelStars.HasValue ? Math.Clamp(preferredHotelStars.Value, 1, 5) : 4,
            ChildFriendly = childFriendly ?? false
        };
        if (!string.IsNullOrWhiteSpace(interests))
            vm.Interests = interests[..Math.Min(interests.Length, 250)];
        SetBrief(brief);
        return View(vm);
    }

    [HttpPost, ValidateAntiForgeryToken, EnableRateLimiting("trip-assistant")]
    public async Task<IActionResult> Generate(PlannerVm vm, string? brief)
    {
        SetBrief(brief);
        if (!ModelState.IsValid)
            return View("Index", vm);
        string? interpreterNote = null;
        if (!string.IsNullOrWhiteSpace(brief))
        {
            if (brief.Length > MaximumBriefLength)
            {
                ModelState.AddModelError("brief", "Keep your travel brief under 800 characters.");
                return View("Index", vm);
            }
            var placeNames = await LoadPlaceNamesAsync();
            var interpreter = interpreters.FirstOrDefault();
            if (interpreter is not null)
            {
                var interpretation = await interpreter.InterpretAsync(brief, HttpContext.RequestAborted);
                if (interpretation?.IsValid() == true)
                {
                    // The model supplies interpretation only. Literal constraints take precedence.
                    var normalizedPreferences = CopyPreferences(vm);
                    try
                    {
                        interpretation.ApplyTo(normalizedPreferences, placeNames);
                        if (ValidPreferences(normalizedPreferences))
                        {
                            vm = normalizedPreferences;
                            interpreterNote = "AI-assisted preferences were checked against the Dubai catalogue and planner constraints.";
                        }
                    }
                    catch (InvalidOperationException) { /* Invalid model output uses the local parser. */ }
                }
            }
            bool understood = TripBrief.Apply(vm, brief, placeNames, out var issue);
            if (issue is not null || (!understood && interpreterNote is null))
            {
                ModelState.AddModelError("brief", issue ??
                    "Add the number of days, travellers, total AED budget, or one interest so I can build a useful trip.");
                return View("Index", vm);
            }
        }
        if (!TryValidateModel(vm) || !ValidateTrip(vm))
            return View("Index", vm);

        var travellerRequestedPlaces = vm.MustIncludePlaces;
        var modelAddedPlaces = false;
        if (!string.IsNullOrWhiteSpace(brief) && tripDesigner.Available)
        {
            try
            {
                var selected = await tripDesigner.ChoosePlacesAsync(brief, vm, HttpContext.RequestAborted);
                var requested = (vm.MustIncludePlaces ?? "").Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries);
                var excluded = (vm.ExcludedPlaces ?? "").Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries)
                    .ToHashSet(StringComparer.OrdinalIgnoreCase);
                var additions = selected.Where(name => !excluded.Contains(name) && !requested.Contains(name, StringComparer.OrdinalIgnoreCase))
                    .Take(Math.Min(4, vm.Days * 2)).ToArray();
                vm.MustIncludePlaces = string.Join(',', requested.Concat(additions).Take(6));
                modelAddedPlaces = additions.Length > 0;
                if (modelAddedPlaces) interpreterNote = "I chose places that match your request, then checked the schedule and budget.";
            }
            catch (Exception error) when (error is HttpRequestException or TaskCanceledException or System.Text.Json.JsonException)
            {
                interpreterNote = "I used the available Dubai catalogue to build your itinerary.";
            }
        }

        var variants = await planner.GenerateVariantsAsync(vm);
        var initiallySelected = variants.FirstOrDefault(x => x.Objective == PlanObjective.BestExperience && x.Result.IsFeasible)
            ?? variants.FirstOrDefault(x => x.Result.IsFeasible) ?? variants[^1];
        var result = initiallySelected.Result;
        if (!result.IsFeasible && modelAddedPlaces)
        {
            vm.MustIncludePlaces = travellerRequestedPlaces;
            variants = await planner.GenerateVariantsAsync(vm);
            initiallySelected = variants.FirstOrDefault(x => x.Objective == PlanObjective.BestExperience && x.Result.IsFeasible)
                ?? variants.FirstOrDefault(x => x.Result.IsFeasible) ?? variants[^1];
            result = initiallySelected.Result;
            interpreterNote = "I adjusted the place selection to fit your budget and daily schedule.";
        }
        ViewBag.PlanVariants = variants;
        ViewBag.SelectedPlan = initiallySelected.Objective;
        return ShowDraft(new Draft(vm, result, users.GetUserId(User)),
            result.IsFeasible
                ? string.Join(" ", new[] { interpreterNote, TripBrief.Summarize(vm) }.OfType<string>())
                : "I found a conflict with the current trip requirements. Review the suggested adjustments below.");
    }

    [HttpPost, ValidateAntiForgeryToken, EnableRateLimiting("trip-assistant")]
    public async Task<IActionResult> Consult(PlannerVm vm, string? brief)
    {
        SetBrief(brief);
        ViewBag.ShowManual = true;
        if (string.IsNullOrWhiteSpace(brief) || brief.Length > MaximumBriefLength)
        {
            ModelState.AddModelError("brief", "Describe your trip in up to 800 characters.");
            return View("Index", vm);
        }
        var placeNames = await LoadPlaceNamesAsync();
        ModelState.Clear(); // The editable form must display interpreted values, not the submitted defaults.
        var extracted = CopyPreferences(vm);
        extracted.Days = 0;
        extracted.PartySize = 0;
        extracted.TotalBudget = 0;
        TripInterpretation? interpretation = null;
        var interpreter = interpreters.FirstOrDefault();
        if (interpreter is not null)
        {
            interpretation = await interpreter.InterpretAsync(brief, HttpContext.RequestAborted);
            if (interpretation?.IsValid() == true)
            {
                try { interpretation.ApplyTo(extracted, placeNames); }
                catch (InvalidOperationException) { interpretation = null; }
            }
        }
        var understood = TripBrief.Apply(extracted, brief, placeNames, out var issue);
        if (issue is not null)
            ModelState.AddModelError("brief", issue);
        else if (!understood && interpretation is null)
            ModelState.AddModelError("brief", "Add your trip length, group size, AED budget, or travel interests.");

        var questions = new List<string>();
        if (extracted.Days == 0) questions.Add("How many days will you spend in Dubai?");
        if (extracted.PartySize == 0) questions.Add("How many people are travelling?");
        if (extracted.TotalBudget == 0) questions.Add("What is your total AED budget for the whole group?");
        if (interpretation is not null)
            questions.AddRange(interpretation.Ambiguities.Take(3));
        ViewBag.ConsultationQuestions = questions.Distinct().ToArray();
        ViewBag.ConsultationSource = interpretation is null ? "Local preference reading" : "AI-assisted preference reading";
        return View("Index", new PlannerVm
        {
            StartDate = extracted.StartDate,
            Days = extracted.Days is >= 1 and <= 14 ? extracted.Days : vm.Days,
            PartySize = extracted.PartySize is >= 1 and <= 20 ? extracted.PartySize : vm.PartySize,
            TotalBudget = extracted.TotalBudget is >= 500 and <= 100000 ? extracted.TotalBudget : vm.TotalBudget,
            EmergencyReserve = extracted.EmergencyReserve,
            Currency = "AED", PartyType = extracted.PartyType, TravelPace = extracted.TravelPace,
            TransportPreference = extracted.TransportPreference,
            DailyAvailableHours = extracted.DailyAvailableHours,
            ChildFriendly = extracted.ChildFriendly, AccessibilityFriendly = extracted.AccessibilityFriendly,
            LimitedWalking = extracted.LimitedWalking, IndoorAfternoons = extracted.IndoorAfternoons,
            Interests = extracted.Interests, ExcludedPlaces = extracted.ExcludedPlaces,
            MustIncludePlaces = extracted.MustIncludePlaces, PreferredLocation = extracted.PreferredLocation,
            PreferredHotelStars = extracted.PreferredHotelStars
        });
    }

    private async Task<string[]> LoadPlaceNamesAsync()
    {
        var attractions = await db.Attractions.AsNoTracking().Where(x => x.Status == RecordStatus.Published)
            .Select(x => x.Name).ToListAsync(HttpContext.RequestAborted);
        var activities = await db.Activities.AsNoTracking().Where(x => x.Status == RecordStatus.Published)
            .Select(x => x.Name).ToListAsync(HttpContext.RequestAborted);
        return attractions.Concat(activities).ToArray();
    }

    [HttpPost, ValidateAntiForgeryToken, EnableRateLimiting("trip-assistant")]
    public async Task<IActionResult> SelectVariant(string? draftToken, PlanObjective objective)
    {
        var draft = ReadDraft(draftToken);
        if (draft is null) return MissingDraft();
        if (objective is not (PlanObjective.BudgetSaver or PlanObjective.TimeSaver or PlanObjective.BestExperience))
            return BadRequest();
        var variants = await planner.GenerateVariantsAsync(draft.Preferences);
        var selected = variants.First(x => x.Objective == objective);
        ViewBag.PlanVariants = variants;
        ViewBag.SelectedPlan = objective;
        return ShowDraft(draft with { Result = selected.Result },
            selected.Result.IsFeasible ? $"{selected.Name} selected. Review the day schedule and estimates before saving."
                : "This option has a planning conflict. Compare the other options or adjust your preferences.");
    }

    [HttpPost, ValidateAntiForgeryToken, EnableRateLimiting("trip-assistant")]
    public async Task<IActionResult> PreviewSimulation(SimulationRequestVm request)
    {
        var draft = ReadDraft(request.DraftToken);
        if (draft is null) return MissingDraft();
        if (draft.Result.Days.SelectMany(day => day.Items).Any(item => item.IsCompleted))
            return ShowDraft(draft, "This draft contains completed stops. Create a new draft before changing whole-trip assumptions.");
        var revised = ModelState.IsValid ? SimulatedPreferences(draft.Preferences, request) : null;
        if (revised is null)
            return ShowDraft(draft, "Check the scenario values. The group budget, reserve, trip length and traveller count must remain valid.");
        var result = await planner.GenerateAsync(revised);
        ViewBag.Simulation = new TripSimulationVm(draft.Result, result, revised, request);
        return ShowDraft(draft, result.IsFeasible
            ? "The alternative was recalculated. Compare it below, then accept it or keep your original itinerary."
            : "The changed assumptions do not produce a feasible itinerary. Your original plan is unchanged.");
    }

    [HttpPost, ValidateAntiForgeryToken, EnableRateLimiting("trip-assistant")]
    public async Task<IActionResult> ApplySimulation(SimulationRequestVm request)
    {
        var draft = ReadDraft(request.DraftToken);
        if (draft is null) return MissingDraft();
        if (draft.Result.Days.SelectMany(day => day.Items).Any(item => item.IsCompleted))
            return ShowDraft(draft, "Completed stops are protected. The current draft is unchanged.");
        var revised = ModelState.IsValid ? SimulatedPreferences(draft.Preferences, request) : null;
        if (revised is null) return BadRequest();
        var result = await planner.GenerateAsync(revised);
        if (!result.IsFeasible)
            return ShowDraft(draft, "The alternative is no longer feasible. Your original itinerary is unchanged.");
        return ShowDraft(new Draft(revised, result, draft.Owner),
            "Your revised trip is selected. Review the updated schedule and budget before saving.");
    }

    private static PlannerVm? SimulatedPreferences(PlannerVm original, SimulationRequestVm request)
    {
        if (request.BudgetDelta is < -100000m or > 100000m ||
            request.ReserveDelta is < -100000m or > 100000m ||
            request.DaysDelta is < -13 or > 13 || request.TravellersDelta is < -19 or > 19 ||
            request.HotelStars is < 1 or > 5 ||
            request.TransportPreference.HasValue && !Enum.IsDefined(request.TransportPreference.Value) ||
            request.AdditionalInterest?.Length > 30) return null;
        var changed = CopyPreferences(original);
        changed.TotalBudget += request.BudgetDelta;
        changed.EmergencyReserve += request.ReserveDelta;
        changed.Days += request.DaysDelta;
        changed.PartySize += request.TravellersDelta;
        if (request.HotelStars.HasValue) changed.PreferredHotelStars = request.HotelStars.Value;
        if (request.LimitedWalking.HasValue) changed.LimitedWalking = request.LimitedWalking.Value;
        if (request.IndoorAfternoons.HasValue) changed.IndoorAfternoons = request.IndoorAfternoons.Value;
        if (request.TransportPreference.HasValue) changed.TransportPreference = request.TransportPreference.Value;
        if (!string.IsNullOrWhiteSpace(request.AdditionalInterest))
        {
            var interest = request.AdditionalInterest.Trim().ToLowerInvariant();
            if (!System.Text.RegularExpressions.Regex.IsMatch(interest, "^[a-z -]{2,30}$")) return null;
            changed.Interests = string.Join(',', (changed.Interests + "," + interest)
                .Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries)
                .Distinct(StringComparer.OrdinalIgnoreCase));
            if (changed.Interests.Length > 250) return null;
        }
        return ValidPreferences(changed) ? changed : null;
    }

    [HttpPost, ValidateAntiForgeryToken, EnableRateLimiting("trip-assistant")]
    public async Task<IActionResult> Edit(string? draftToken, string? operation, int dayNumber,
        string? itemType, int itemId, string? message, string? command)
    {
        var draft = ReadDraft(draftToken);
        if (draft is null)
            return MissingDraft();
        var previous = draft.Result.TotalEstimatedCost;
        if (!string.IsNullOrWhiteSpace(command) && command.Length <= 64)
        {
            var parts = command.Split(':');
            if (parts.Length == 4 && (parts[0] is "pin" or "swap" or "remove" or "complete") &&
                int.TryParse(parts[1], out int commandDay) && int.TryParse(parts[3], out int commandId))
            {
                operation = parts[0];
                dayNumber = commandDay;
                itemType = parts[2];
                itemId = commandId;
            }
        }
        var ask = operation == "ask";
        if (ask && message is not null && message.Length > MaximumBriefLength)
            return ShowDraft(draft, "Keep follow-up requests under 800 characters.");
        var proposed = JsonSerializer.Deserialize<ItineraryResultVm>(JsonSerializer.Serialize(draft.Result))!;
        var edited = await planner.EditAsync(draft.Preferences, proposed, operation ?? "",
            dayNumber, itemType, itemId, message);
        ViewBag.LastMessage = ask ? message : null;
        if (edited.Changed && operation is not ("pin" or "keep" or "unpin" or "complete"))
        {
            ViewBag.ReplanPreview = new ReplanPreviewVm(draft.Result, proposed,
                operation ?? "", dayNumber, itemType, itemId, message, edited.Message);
            return ShowDraft(draft, "Review the proposed change below. Your current itinerary is still selected.");
        }
        if (edited.Changed)
            draft = draft with { Result = proposed };
        if (edited.Changed && draft.Result.TotalEstimatedCost != previous)
            ViewBag.PreviousEstimatedTotal = previous;
        return ShowDraft(draft, edited.Message);
    }

    [HttpPost, ValidateAntiForgeryToken, EnableRateLimiting("trip-assistant")]
    public async Task<IActionResult> AcceptReplan(string? draftToken, string? operation,
        int dayNumber, string? itemType, int itemId, string? message)
    {
        var draft = ReadDraft(draftToken);
        if (draft is null) return MissingDraft();
        if (operation is not ("ask" or "swap" or "remove") || message?.Length > MaximumBriefLength)
            return BadRequest();
        var revised = JsonSerializer.Deserialize<ItineraryResultVm>(JsonSerializer.Serialize(draft.Result))!;
        var change = await planner.EditAsync(draft.Preferences, revised, operation,
            dayNumber, itemType, itemId, message);
        if (!change.Changed)
            return ShowDraft(draft, "The proposed change no longer fits. Your original itinerary is unchanged. " + change.Message);
        ViewBag.PreviousEstimatedTotal = draft.Result.TotalEstimatedCost;
        return ShowDraft(draft with { Result = revised }, change.Message);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public IActionResult RejectReplan(string? draftToken)
    {
        var draft = ReadDraft(draftToken);
        return draft is null ? MissingDraft() : ShowDraft(draft, "Kept your original itinerary.");
    }

    [HttpPost, ValidateAntiForgeryToken, EnableRateLimiting("trip-assistant")]
    public async Task<IActionResult> Save(PlannerVm vm, string? draftToken)
    {
        var draft = ReadDraft(draftToken);
        if (!string.IsNullOrWhiteSpace(draftToken) && draft is null)
            return MissingDraft();
        string? userId = users.GetUserId(User);
        if (draft is null)
        {
            if (userId is null)
                return Challenge();
            if (!ModelState.IsValid || !ValidateTrip(vm))
                return View("Index", vm);
            draft = new Draft(vm, await planner.GenerateAsync(vm), userId);
        }
        if (!draft.Result.IsFeasible)
            return ShowDraft(draft, "Resolve the planning conflict before saving this trip.");
        if (userId is null)
        {
            var key = RandomNumberGenerator.GetHexString(40);
            cache.Set(HandoffKey(key), new Handoff(draftToken!, BrowserKey()), TimeSpan.FromMinutes(10));
            return RedirectToAction("Login", "Account", new { returnUrl = Url.Action(nameof(Resume), new { key }) });
        }

        var trip = await planner.SaveAsync(userId, draft.Preferences, draft.Result);
        return RedirectToAction(nameof(Trip), new { id = trip.Id });
    }

    [HttpPost, ValidateAntiForgeryToken]
    public IActionResult Adjust(string? draftToken)
    {
        var draft = ReadDraft(draftToken);
        if (draft is null)
            return MissingDraft();
        ViewBag.ShowManual = true;
        return View("Index", draft.Preferences);
    }

    [HttpGet, Authorize]
    public IActionResult Resume(string? key)
    {
        if (key is null || key.Length != 40 || !cache.TryGetValue<Handoff>(HandoffKey(key), out var handoff) ||
            handoff is null || !string.Equals(Request.Cookies[BrowserCookie], handoff.BrowserKey, StringComparison.Ordinal))
            return MissingDraft();
        cache.Remove(HandoffKey(key));
        var draft = ReadDraft(handoff.Token);
        return draft is null ? MissingDraft() : ShowDraft(draft with { Owner = users.GetUserId(User) },
            "Your itinerary is ready to save to My Trips.");
    }

    [HttpGet, Authorize]
    public async Task<IActionResult> Trip(int id)
    {
        var uid = users.GetUserId(User);
        var trip = await db.TripPlans.Include(x => x.Days).ThenInclude(x => x.Items)
            .FirstOrDefaultAsync(x => x.Id == id && x.UserId == uid);
        return trip is null ? NotFound() : View(trip);
    }

    [HttpPost, Authorize, ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(int id)
    {
        var uid = users.GetUserId(User);
        var trip = await db.TripPlans.FirstOrDefaultAsync(t => t.Id == id && t.UserId == uid);
        if (trip is not null)
        {
            db.Remove(trip);
            await db.SaveChangesAsync();
        }
        return RedirectToAction("Index", "Dashboard");
    }

    private IActionResult MissingDraft()
    {
        ModelState.AddModelError("", "This trip draft has expired. Build a new itinerary to continue.");
        return View("Index", new PlannerVm());
    }

    private IActionResult ShowDraft(Draft draft, string assistantMessage)
    {
        var owner = draft.Owner ?? users.GetUserId(User);
        ViewBag.Preferences = draft.Preferences;
        ViewBag.AssistantMessage = assistantMessage;
        ViewBag.DraftToken = Protector(BrowserKey()).Protect(JsonSerializer.Serialize(draft with { Owner = owner }), DraftLifetime);
        return View("Result", draft.Result);
    }

    private Draft? ReadDraft(string? token)
    {
        var key = Request.Cookies[BrowserCookie];
        if (key is null || key.Length != 40 || string.IsNullOrWhiteSpace(token) || token.Length > MaximumTokenLength)
            return null;
        try
        {
            var draft = JsonSerializer.Deserialize<Draft>(Protector(key).Unprotect(token));
            return draft is not null && (draft.Owner is null ||
                string.Equals(draft.Owner, users.GetUserId(User), StringComparison.Ordinal)) ? draft : null;
        }
        catch (Exception error) when (error is CryptographicException or JsonException or FormatException)
        {
            return null;
        }
    }

    private string BrowserKey()
    {
        if (Request.Cookies.TryGetValue(BrowserCookie, out var existing) && existing.Length == 40)
            return existing;
        var key = RandomNumberGenerator.GetHexString(40);
        Response.Cookies.Append(BrowserCookie, key, new CookieOptions
        {
            HttpOnly = true, SameSite = SameSiteMode.Lax, Secure = Request.IsHttps, IsEssential = true
        });
        return key;
    }

    private ITimeLimitedDataProtector Protector(string key) =>
        protection.CreateProtector("ADT.Planner.Draft.v1", key).ToTimeLimitedDataProtector();

    private static string HandoffKey(string key) => $"planner-handoff:{key}";

    private void SetBrief(string? brief) =>
        ViewBag.Brief = brief is null ? "" : brief[..Math.Min(brief.Length, MaximumBriefLength)];

    private static bool ValidPreferences(PlannerVm vm)
    {
        var today = DateTime.UtcNow.AddHours(4).Date;
        return vm.StartDate.Date >= today && vm.StartDate.Date <= today.AddYears(2) &&
            string.Equals(vm.Currency, "AED", StringComparison.OrdinalIgnoreCase) &&
            vm.Days is >= 1 and <= 14 && vm.PartySize is >= 1 and <= 20 &&
            vm.TotalBudget is >= 500m and <= 100000m && vm.EmergencyReserve >= 0m &&
            vm.EmergencyReserve <= vm.TotalBudget;
    }

    private bool ValidateTrip(PlannerVm vm)
    {
        if (ValidPreferences(vm))
            return true;
        var today = DateTime.UtcNow.AddHours(4).Date;
        if (vm.StartDate.Date < today || vm.StartDate.Date > today.AddYears(2))
            ModelState.AddModelError(nameof(vm.StartDate), "Choose a Dubai travel date from today through the next two years.");
        if (vm.TotalBudget is < 500m or > 100000m || !string.Equals(vm.Currency, "AED", StringComparison.OrdinalIgnoreCase))
            ModelState.AddModelError(nameof(vm.TotalBudget), "Use a group budget between AED 500 and AED 100,000.");
        if (vm.EmergencyReserve < 0 || vm.EmergencyReserve > vm.TotalBudget)
            ModelState.AddModelError(nameof(vm.EmergencyReserve), "Keep the emergency reserve between AED 0 and the total group budget.");
        if (vm.Days is < 1 or > 14)
            ModelState.AddModelError(nameof(vm.Days), "Choose a trip of 1 to 14 days.");
        if (vm.PartySize is < 1 or > 20)
            ModelState.AddModelError(nameof(vm.PartySize), "Choose a group of 1 to 20 travellers.");
        return false;
    }

    private static PlannerVm CopyPreferences(PlannerVm vm) => new()
    {
        StartDate = vm.StartDate, Days = vm.Days, TotalBudget = vm.TotalBudget,
        EmergencyReserve = vm.EmergencyReserve, Currency = vm.Currency,
        PartySize = vm.PartySize, PartyType = vm.PartyType, TravelPace = vm.TravelPace,
        TransportPreference = vm.TransportPreference,
        DailyAvailableHours = vm.DailyAvailableHours, ChildFriendly = vm.ChildFriendly,
        AccessibilityFriendly = vm.AccessibilityFriendly, Interests = vm.Interests,
        LimitedWalking = vm.LimitedWalking,
        ExcludedPlaces = vm.ExcludedPlaces, PreferredLocation = vm.PreferredLocation,
        PreferredHotelStars = vm.PreferredHotelStars, IndoorAfternoons = vm.IndoorAfternoons,
        MustIncludePlaces = vm.MustIncludePlaces
    };
}

public class RecommendationsController(IRecommendationService rec):Controller{
 [HttpGet] public IActionResult Index(
        decimal? totalBudget = null, int? days = null, int? partySize = null,
        string? interests = null, int? preferredHotelStars = null, bool? childFriendly = null)
    {
        var vm = new PlannerVm();
        if (totalBudget.HasValue) vm.TotalBudget = Math.Clamp(totalBudget.Value, 500m, 100000m);
        if (days.HasValue) vm.Days = Math.Clamp(days.Value, 1, 14);
        if (partySize.HasValue) vm.PartySize = Math.Clamp(partySize.Value, 1, 20);
        if (!string.IsNullOrWhiteSpace(interests)) vm.Interests = interests[..Math.Min(interests.Length, 250)];
        if (preferredHotelStars.HasValue) vm.PreferredHotelStars = Math.Clamp(preferredHotelStars.Value, 1, 5);
        if (childFriendly.HasValue) vm.ChildFriendly = childFriendly.Value;
        return View(vm);
    }
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> Index(PlannerVm vm){if(!ModelState.IsValid)return View(vm);ViewBag.Input=vm;return View("Results",await rec.RecommendAsync(vm));}
}
