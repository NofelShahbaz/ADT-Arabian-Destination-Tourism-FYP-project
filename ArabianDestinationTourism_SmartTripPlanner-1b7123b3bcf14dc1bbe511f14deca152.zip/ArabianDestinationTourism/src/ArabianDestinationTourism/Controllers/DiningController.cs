using ArabianDestinationTourism.Data;
using Microsoft.AspNetCore.Mvc;

namespace ArabianDestinationTourism.Controllers;

public class DiningController : Controller
{
    public IActionResult Index(string? q, string? area)
    {
        ViewData["Query"] = q;
        ViewData["Area"] = area;
        ViewData["Areas"] = DiningCatalogue.All.Select(venue => venue.Area).Distinct().Order().ToArray();
        return View(DiningCatalogue.All.Where(venue =>
            (string.IsNullOrWhiteSpace(q) || $"{venue.Name} {venue.Cuisine}".Contains(q.Trim(), StringComparison.OrdinalIgnoreCase)) &&
            (string.IsNullOrWhiteSpace(area) || venue.Area.Equals(area, StringComparison.OrdinalIgnoreCase))).ToArray());
    }

    public IActionResult Details(string id)
    {
        var venue = DiningCatalogue.All.FirstOrDefault(venue => venue.Slug.Equals(id, StringComparison.OrdinalIgnoreCase));
        return venue is null ? NotFound() : View(venue);
    }
}
