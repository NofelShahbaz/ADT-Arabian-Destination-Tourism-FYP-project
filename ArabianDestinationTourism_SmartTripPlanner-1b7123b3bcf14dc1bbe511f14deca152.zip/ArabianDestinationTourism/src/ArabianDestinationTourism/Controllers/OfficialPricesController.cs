using ArabianDestinationTourism.Data;
using ArabianDestinationTourism.Models.Entities;
using ArabianDestinationTourism.Services.Pricing;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;

namespace ArabianDestinationTourism.Controllers;

[ApiController]
[Route("api/official-prices")]
[EnableRateLimiting("official-prices")]
public sealed class OfficialPricesController(
    ApplicationDbContext db, OfficialPriceService prices) : ControllerBase
{
    [HttpPost]
    [ValidateAntiForgeryToken]
    [RequestSizeLimit(16_384)]
    [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
    public async Task<IActionResult> Check([FromBody] OfficialPriceRequest request,
        CancellationToken cancellationToken)
    {
        if (request.Items is not { Count: >= 1 and <= 60 } ||
            request.PartySize is < 1 or > 20)
            return BadRequest(new { message = "Select 1–60 catalogue listings and a valid party size." });

        var selections = new HashSet<(string Type, int Id)>();
        foreach (var item in request.Items)
        {
            string? type = item?.Type?.Trim().ToLowerInvariant() switch
            {
                "attraction" => "Attraction",
                "activity" => "Activity",
                "hotel" => "Hotel",
                _ => null
            };
            if (type is null || item is null || item.Id < 1)
                return BadRequest(new { message = "Select a valid attraction, activity or hotel." });
            selections.Add((type, item.Id));
        }

        var items = new Dictionary<(string, int), TourismItem>();
        await AddPublishedAsync("Attraction", db.Attractions);
        await AddPublishedAsync("Activity", db.Activities);
        await AddPublishedAsync("Hotel", db.Hotels);

        var results = await Task.WhenAll(selections.Select(selection => prices.CheckAsync(
            selection.Type, selection.Id, items.GetValueOrDefault(selection), cancellationToken)));
        return Ok(new { results });

        async Task AddPublishedAsync<T>(string type, IQueryable<T> query) where T : TourismItem
        {
            int[] ids = selections.Where(selection => selection.Type == type).Select(selection => selection.Id).ToArray();
            if (ids.Length == 0)
                return;

            var published = await query.AsNoTracking()
                .Where(item => ids.Contains(item.Id) && item.Status == RecordStatus.Published)
                .ToListAsync(cancellationToken);
            foreach (var item in published)
                items.Add((type, item.Id), item);
        }
    }
}
