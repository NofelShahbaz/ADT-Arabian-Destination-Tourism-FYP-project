using ArabianDestinationTourism.Data;
using ArabianDestinationTourism.Models.Entities;
using ArabianDestinationTourism.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace ArabianDestinationTourism.Controllers;
[Authorize]
public class DashboardController(ApplicationDbContext db,UserManager<ApplicationUser> users,IFavoriteService favorites,IBookingService bookings):Controller
{
 public async Task<IActionResult> Index(){var uid=users.GetUserId(User)!;ViewBag.Trips=await db.TripPlans.Where(x=>x.UserId==uid).OrderByDescending(x=>x.CreatedAt).Take(5).ToListAsync();ViewBag.Favorites=await favorites.GetAsync(uid);ViewBag.Bookings=await bookings.HistoryAsync(uid);return View();}
 public async Task<IActionResult> Profile(){var u=await users.GetUserAsync(User);var p=await db.UserProfiles.FirstOrDefaultAsync(x=>x.UserId==u!.Id)??new UserProfile{UserId=u!.Id};ViewBag.User=u;return View(p);}
 [HttpPost,ValidateAntiForgeryToken] public async Task<IActionResult> Profile(UserProfile vm){var uid=users.GetUserId(User)!;var p=await db.UserProfiles.FirstOrDefaultAsync(x=>x.UserId==uid);if(p==null){p=new UserProfile{UserId=uid};db.Add(p);}p.Nationality=vm.Nationality;p.PreferredCurrency=vm.PreferredCurrency;p.PreferredTravelPace=vm.PreferredTravelPace;p.AccessibilityPreferred=vm.AccessibilityPreferred;p.ChildFriendlyPreferred=vm.ChildFriendlyPreferred;p.TravelInterestsCsv=vm.TravelInterestsCsv;await db.SaveChangesAsync();TempData["Message"]="Profile updated.";return RedirectToAction(nameof(Profile));}
 public async Task<IActionResult> Favorites()=>View(await favorites.GetAsync(users.GetUserId(User)!));
 public async Task<IActionResult> Reviews()=>View(await db.Reviews.Where(x=>x.UserId==users.GetUserId(User)).OrderByDescending(x=>x.CreatedAt).ToListAsync());
}
