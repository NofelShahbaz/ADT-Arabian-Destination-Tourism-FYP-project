using Microsoft.AspNetCore.Mvc;

namespace ArabianDestinationTourism.Controllers;

public class HomeController : Controller
{
    public IActionResult Index() => View();
    public IActionResult AboutDubai() => View();
    public IActionResult About() => View();
    public IActionResult Contact() => View();
    public IActionResult Error() => View();
}
