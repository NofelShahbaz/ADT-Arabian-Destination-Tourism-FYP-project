using ArabianDestinationTourism.Models.ViewModels;
using ArabianDestinationTourism.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using ArabianDestinationTourism.Models.Entities;
using Microsoft.AspNetCore.Mvc;
namespace ArabianDestinationTourism.Controllers;
[Route("api")]
public class ApiController(IFavoriteService favorites,IReviewService reviews,UserManager<ApplicationUser> users):Controller
{
    [Authorize,HttpPost("favorites/toggle"), ValidateAntiForgeryToken] public async Task<IActionResult> Favorite(string itemType,int itemId)=>Json(new{saved=await favorites.ToggleAsync(users.GetUserId(User)!,itemType,itemId)});
    [Authorize,HttpPost("reviews"), ValidateAntiForgeryToken] public async Task<IActionResult> Review(string itemType,int itemId,int rating,string comment){await reviews.AddAsync(users.GetUserId(User)!,itemType,itemId,rating,comment);return Json(new{ok=true,message="Review submitted for moderation."});}
}
