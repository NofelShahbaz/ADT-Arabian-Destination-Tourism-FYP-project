using ArabianDestinationTourism.Data;
using ArabianDestinationTourism.Models.Entities;
using ArabianDestinationTourism.Models.ViewModels;
using ArabianDestinationTourism.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace ArabianDestinationTourism.Controllers;

[Authorize]
public class BookingsController(IBookingService history, ICatalogueService catalogue, UserManager<ApplicationUser> users) : Controller
{
    public async Task<IActionResult> Index() => View(await history.HistoryAsync(users.GetUserId(User)!));

    [HttpGet, AllowAnonymous]
    public Task<IActionResult> Official(string? type, int id) => OpenOfficialAsync(type, id);

    [HttpGet, AllowAnonymous]
    public Task<IActionResult> Create(string? type, int id) => OpenOfficialAsync(type, id);

    [HttpPost, AllowAnonymous, ValidateAntiForgeryToken]
    public Task<IActionResult> Create(BookingCreateVm formerRequest) =>
        OpenOfficialAsync(formerRequest.ServiceType, formerRequest.ServiceId);

    [HttpGet]
    public async Task<IActionResult> Payment(int id)
    {
        var booking = await history.FindAsync(users.GetUserId(User)!, id);
        return booking is null ? NotFound() : await OpenOfficialAsync(booking.ServiceType, booking.ServiceId);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public Task<IActionResult> Payment(int id, string? outcome) => Payment(id);

    public async Task<IActionResult> Receipt(int id)
    {
        var bookings = await history.HistoryAsync(users.GetUserId(User)!);
        var payment = bookings.Select(item => item.Payment).FirstOrDefault(item => item?.Id == id);
        return payment is null ? NotFound() : View(payment);
    }

    private async Task<IActionResult> OpenOfficialAsync(string? type, int id)
    {
        TourismItem? item = type switch
        {
            "Attraction" => await catalogue.GetAttractionAsync(id),
            "Activity" => await catalogue.GetActivityAsync(id),
            "Hotel" => await catalogue.GetHotelAsync(id),
            _ => null
        };
        if (item is null) return NotFound();
        var profile = PlaceEditorial.For(type!, item.Name);
        var destination = PlaceEditorial.OfficialUri(profile.BookingUrl) ?? PlaceEditorial.OfficialUri(profile.OfficialUrl);
        if (destination is not null) return Redirect(destination.AbsoluteUri);
        return RedirectToAction("Details", type == "Activity" ? "Activities" : type == "Hotel" ? "Hotels" : "Attractions", new { id });
    }
}
