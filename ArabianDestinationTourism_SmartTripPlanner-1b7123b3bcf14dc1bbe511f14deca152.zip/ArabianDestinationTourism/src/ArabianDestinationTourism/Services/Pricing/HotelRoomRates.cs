using ArabianDestinationTourism.Data;
using ArabianDestinationTourism.Models.Entities;

namespace ArabianDestinationTourism.Services.Pricing;

public sealed record RoomAllocation(string Name, int AdultsPerRoom, int Rooms, decimal NightlyRate, string Basis)
{
    public decimal NightlyTotal => NightlyRate * Rooms;
}

public sealed record HotelRoomQuote(int Nights, IReadOnlyList<RoomAllocation> Allocation)
{
    public int RoomCount => Allocation.Sum(item => item.Rooms);
    public decimal NightlyTotal => Allocation.Sum(item => item.NightlyTotal);
    public decimal Total => NightlyTotal * Nights;
}

public static class HotelRoomRates
{
    public static HotelRoomQuote? Quote(Hotel hotel, int travellers, int nights)
    {
        if (travellers is < 1 or > 20 || nights is < 1 or > 30) return null;
        var profile = PlaceEditorial.For("Hotel", hotel.Name);
        var options = (profile.Rooms?.Options ?? []).Where(room =>
                room.NightlyRate is > 0 && room.MaxAdults is > 0 and <= 20)
            .Select(room => new RoomAllocation(room.Name, room.MaxAdults!.Value, 1, room.NightlyRate!.Value,
                room.RateNote ?? "Published starting rate. Check stay conditions.")).ToList();
        if (!profile.PriceOnRequest && hotel.Price > 0)
        {
            var standardLimit = profile.Rooms?.Options.FirstOrDefault()?.MaxAdults;
            options.Add(new("Standard room allowance", Math.Clamp(standardLimit ?? 2, 1, 2), 1, hotel.Price,
                "Catalogue estimate for a room. Confirm occupancy and rates on the hotel website."));
        }
        if (options.Count == 0) return null;

        var best = new (decimal Cost, int Rooms, RoomAllocation? Choice, int Previous)[travellers + 1];
        for (var guest = 1; guest <= travellers; guest++)
        {
            best[guest].Cost = decimal.MaxValue;
            foreach (var option in options)
            {
                var previous = Math.Max(0, guest - option.AdultsPerRoom);
                var cost = best[previous].Cost + option.NightlyRate;
                var roomCount = best[previous].Rooms + 1;
                if (cost < best[guest].Cost || (cost == best[guest].Cost && roomCount < best[guest].Rooms))
                    best[guest] = (cost, roomCount, option, previous);
            }
        }

        var selected = new List<RoomAllocation>();
        for (var guest = travellers; guest > 0; guest = best[guest].Previous)
            selected.Add(best[guest].Choice!);
        return new HotelRoomQuote(nights,
            selected.GroupBy(option => option).Select(group => group.Key with { Rooms = group.Count() }).ToArray());
    }
}
