using System.Globalization;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace ArabianDestinationTourism.Services.Pricing;

internal sealed record OfficialPriceSource(
    Uri Uri, string Scope, string Unit, Func<string, decimal?> ReadPrice);

internal static class OfficialPriceSources
{
    private const string Aed = @"\bAED\s*(?<price>[0-9]{1,4}(?:\.[0-9]{1,2})?)(?![0-9.,])";
    private static readonly TimeSpan PatternTimeout = TimeSpan.FromMilliseconds(400);
    private const RegexOptions PatternOptions =
        RegexOptions.IgnoreCase | RegexOptions.CultureInvariant | RegexOptions.Singleline;

    // Sources are compiled venue-to-product mappings. A redesigned page yields no price
    // until its adapter can identify the same product again.
    private static readonly IReadOnlyDictionary<string, OfficialPriceSource> Sources =
        new Dictionary<string, OfficialPriceSource>(StringComparer.OrdinalIgnoreCase)
        {
            ["Attraction|AYA Universe"] = Html(
                "https://www.aya-universe.com/payment", "Walk-in general admission", "per guest",
                @"<h2[^>]*>\s*The walk-in price is\s*" + Aed + @"\s*</h2>"),
            ["Attraction|Terra Sustainability Pavilion"] = Html(
                "https://terra.expocitydubai.com/en/visit", "Adult admission for ages 12 and over", "per visitor aged 12+",
                @"<p[^>]*>\s*Adult\s*</p>\s*<div[^>]*>\s*</div>\s*<p[^>]*>\s*(?<price>[0-9]{1,4}(?:\.[0-9]{1,2})?)\s*AED\s*</p>\s*</div>\s*<p[^>]*>\s*\(12\+ Years\)\s*</p>"),
            ["Attraction|Dubai Frame"] = Html(
                "https://www.dubaiframe.ae/en/plan-your-visit",
                "Adult admission", "per adult",
                """<h2[^>]*>\s*Admission Fees\s*</h2>\s*<ul class="list-prices"[^>]*>\s*<li[^>]*>\s*Adults\s*<span[^>]*>\s*"""
                    + Aed + @"\s*</span>\s*</li>"),
            ["Attraction|Dubai Miracle Garden"] = Html(
                "https://www.dubaimiraclegarden.com/",
                "Adult garden admission including VAT. Seasonal opening applies.", "per adult",
                @">\s*Adult\s*</span>\s*<span[^>]*>\s*" + Aed +
                    @"\s*VAT incl\.?\s*</span>\s*</li>\s*<li[^>]*>\s*<span[^>]*>\s*Child\s*3[-–]12\s*</span>"),
            ["Attraction|Dubai Safari Park"] = Html(
                "https://dubaisafari.ae/tickets/",
                "Safari Park Pass base admission", "per person",
                """<h3[^>]*\bid="safari-title"[^>]*>\s*Safari Park Pass\s*</h3>.{0,7500}?<div[^>]*\bid="pass-price"[^>]*>\s*"""
                    + Aed + """\s*</div>\s*<div class="tk-price-unit"[^>]*>\s*Per Person\s*</div>"""),
            ["Attraction|Dubai Aquarium & Underwater Zoo"] = Aquarium(),
            ["Activity|Aquarium Tunnel Visit"] = Aquarium(),
            ["Attraction|Global Village"] = Html(
                "https://www.globalvillage.ae/en/park-rules",
                "Any Day Entry Ticket including VAT. Admission rules and seasonal opening apply.", "per person",
                """<li>\s*The [“"]Any Day[”"] Entry Ticket is\s*""" + Aed +
                    @"\s+via Global Village"),
            ["Attraction|Burj Khalifa"] = Html(
                "https://ticket.atthetop.ae/tickets/book-tickets/",
                "At the Top Silver ticket for levels 124 and 125", "per person",
                """<h6>\s*Level\s*</h6>\s*<h6>\s*124,\s*125\s*</h6>.{0,800}?<div class="ticket-price">\s*<div class="mob">\s*<h5>\s*"""
                    + Aed + """\s*</h5>\s*<p>\s*</p>\s*</div>\s*<a[^>]*href="https://ticket\.atthetop\.ae/make-your-ticket/\?id=1053\x22"""),
            ["Activity|Abra Ride"] = Html(
                "https://www.rta.ae/wps/portal/rta/ae/public-transport/marine/about-marine",
                "Petrol Heritage Abra, Al Fahidi to Deira Old Souq (CR5)", "per passenger, one way",
                @"<li>\s*Al Fahidi\s*-\s*Deira Old Souq\s*\(CR5\)\s*</li>\s*<li>\s*Al Seef\s*-\s*Baniyas\s*\(CR6\)\s*</li>\s*</ul>\s*<p>\s*<b>\s*Fares\s*</b>\s*</p>\s*<ul[^>]*>\s*<li>\s*"
                    + Aed + @"\s*</li>"),
            ["Activity|Marina Zipline"] = new(
                new Uri("https://www.xdubai.com/x-line"),
                "Adult Adventurer, one zipline experience. Eligibility rules apply.", "per adult", XLine)
        };

    private static readonly HashSet<string> Hosts = Sources.Values
        .Select(source => source.Uri.IdnHost).ToHashSet(StringComparer.OrdinalIgnoreCase);

    private static readonly Regex HiddenMarkup = new(
        @"<!--.*?-->|<(script|style)\b[^>]*>.*?</\1\s*>", PatternOptions, PatternTimeout);

    internal static OfficialPriceSource? For(string type, string name) =>
        Sources.GetValueOrDefault($"{type}|{name}");

    internal static bool AllowsHost(string host) => Hosts.Contains(host);

    private static OfficialPriceSource Aquarium() =>
        Html(
            "https://www.thedubaiaquarium.com/tickets/book-tickets/",
            "Silver pass, including the Aquarium Tunnel and Underwater Zoo", "per person",
            """<div class="ticket_text">\s*Silver\s*</div>(?:(?!ticket-main-wrapper).){0,6000}?<div class="aed_rs\s+mt-0\s*">\s*"""
            + Aed + @"\s*</div>");

    private static OfficialPriceSource Html(string url, string scope, string unit, string pricePattern)
    {
        var matcher = new Regex(pricePattern, PatternOptions, PatternTimeout);
        return new(new Uri(url), scope, unit, html =>
        {
            string markup = HiddenMarkup.Replace(html, " ")
                .Replace("&nbsp;", " ", StringComparison.OrdinalIgnoreCase);
            return CommonPrice(matcher.Matches(markup).Select(x => x.Groups["price"].Value));
        });
    }

    private static decimal? XLine(string html)
    {
        var offers = new List<string>();
        var decoder = new Regex(
            """<script\b[^>]*type\s*=\s*["']application/ld\+json["'][^>]*>(?<json>.*?)</script\s*>""",
            PatternOptions, PatternTimeout);
        foreach (Match match in decoder.Matches(html))
        {
            try
            {
                using var json = JsonDocument.Parse(match.Groups["json"].Value);
                if (json.RootElement.ValueKind != JsonValueKind.Object ||
                    !json.RootElement.TryGetProperty("@graph", out var graph) ||
                    graph.ValueKind != JsonValueKind.Array)
                    continue;

                foreach (var product in graph.EnumerateArray())
                {
                    if (!TextEquals(product, "@type", "Product") ||
                        !TextEquals(product, "@id", "https://www.xdubai.com/x-line#product") ||
                        !product.TryGetProperty("offers", out var products) ||
                        products.ValueKind != JsonValueKind.Array)
                        continue;

                    foreach (var offer in products.EnumerateArray())
                    {
                        if (TextEquals(offer, "@type", "Offer") &&
                            TextEquals(offer, "name", "Adult Adventurer") &&
                            TextEquals(offer, "priceCurrency", "AED") &&
                            !offer.TryGetProperty("priceValidUntil", out _) &&
                            offer.TryGetProperty("price", out var price) &&
                            price.ValueKind is JsonValueKind.Number or JsonValueKind.String)
                            offers.Add(price.ToString());
                    }
                }
            }
            catch (JsonException)
            {
                // Unrelated scripts occasionally include incomplete JSON-LD.
            }
        }

        return CommonPrice(offers);
    }

    private static bool TextEquals(JsonElement value, string name, string expected) =>
        value.ValueKind == JsonValueKind.Object &&
        value.TryGetProperty(name, out var item) &&
        item.ValueKind == JsonValueKind.String &&
        string.Equals(item.GetString(), expected, StringComparison.Ordinal);

    private static decimal? CommonPrice(IEnumerable<string> values)
    {
        decimal? amount = null;
        foreach (string value in values)
        {
            if (!decimal.TryParse(value, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out var price) ||
                price is < 0 or > 9999.99m || (amount.HasValue && amount != price))
                return null;
            amount = price;
        }

        return amount;
    }
}
