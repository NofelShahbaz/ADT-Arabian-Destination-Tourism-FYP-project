using System.Collections.Concurrent;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.RegularExpressions;
using ArabianDestinationTourism.Data;
using ArabianDestinationTourism.Models.Entities;
using Microsoft.Extensions.Caching.Memory;

namespace ArabianDestinationTourism.Services.Pricing;

public sealed record OfficialPriceSelection(string? Type, int Id);

public sealed record OfficialPriceRequest(
    List<OfficialPriceSelection?>? Items, DateOnly? StartDate = null, int? PartySize = null);

public sealed record OfficialPriceResult(
    string Type, int Id, string? Name, string Status, decimal? CatalogueEstimate,
    string Currency, string? Unit, decimal? OfficialPrice, string? Scope,
    string? SourceUrl, DateTimeOffset? CheckedAt, string Message);

public static class OfficialPriceRegistration
{
    internal const string Client = "official-venue-prices";

    public static IServiceCollection AddOfficialPriceVerification(this IServiceCollection services)
    {
        services.AddMemoryCache();
        services.AddSingleton<OfficialPriceService>();
        services.AddHttpClient(Client, client =>
        {
            client.Timeout = TimeSpan.FromSeconds(7);
            client.DefaultRequestHeaders.UserAgent.ParseAdd("ArabianDestinationTourism/1.0");
            client.DefaultRequestHeaders.Accept.ParseAdd("text/html");
            client.DefaultRequestHeaders.AcceptLanguage.ParseAdd("en");
        }).ConfigurePrimaryHttpMessageHandler(provider =>
        {
            // A deployment can route the same fixed HTTPS URLs through its
            // trusted egress proxy, which then controls destination DNS.
            bool useProxy = provider.GetRequiredService<IConfiguration>()
                .GetValue<bool>("OfficialPrices:UseSystemProxy");
            return new SocketsHttpHandler
            {
                AllowAutoRedirect = false,
                UseCookies = false,
                UseProxy = useProxy,
                AutomaticDecompression = DecompressionMethods.All,
                MaxResponseHeadersLength = 32,
                ConnectTimeout = TimeSpan.FromSeconds(3),
                ConnectCallback = useProxy ? null : ConnectToPublicVenueAsync
            };
        });
        return services;
    }

    private static async ValueTask<Stream> ConnectToPublicVenueAsync(
        SocketsHttpConnectionContext context, CancellationToken cancellationToken)
    {
        string host = context.DnsEndPoint.Host;
        if (context.DnsEndPoint.Port != 443 || !OfficialPriceSources.AllowsHost(host))
            throw new HttpRequestException("The official venue host is outside the price-verification allowlist.");

        // Connect to the same public DNS address that was validated. The HTTP
        // handler still validates the HTTPS certificate for the official hostname.
        var addresses = await Dns.GetHostAddressesAsync(host, cancellationToken);
        if (addresses.Length == 0 || addresses.Any(address => !IsPublicAddress(address)))
            throw new HttpRequestException("The official venue did not resolve exclusively to public addresses.");

        foreach (var address in addresses.OrderBy(address => address.AddressFamily))
        {
            var socket = new Socket(address.AddressFamily, SocketType.Stream, ProtocolType.Tcp) { NoDelay = true };
            try
            {
                await socket.ConnectAsync(new IPEndPoint(address, 443), cancellationToken);
                return new NetworkStream(socket, ownsSocket: true);
            }
            catch (SocketException)
            {
                socket.Dispose();
            }
            catch
            {
                socket.Dispose();
                throw;
            }
        }

        throw new HttpRequestException("No public venue address accepted the connection.");
    }

    internal static bool IsPublicAddress(IPAddress address)
    {
        if (address.IsIPv4MappedToIPv6)
            address = address.MapToIPv4();

        var bytes = address.GetAddressBytes();
        if (address.AddressFamily == AddressFamily.InterNetworkV6)
        {
            // Only native global unicast. Exclude IETF special space, 6to4 and documentation.
            return (bytes[0] & 0xE0) == 0x20 &&
                !(bytes[0] == 0x20 && bytes[1] == 1 && (bytes[2] < 2 ||
                    (bytes[2] == 0x0d && bytes[3] == 0xb8))) &&
                !(bytes[0] == 0x20 && bytes[1] == 2) &&
                !(bytes[0] == 0x3f && bytes[1] == 0xff);
        }

        if (address.AddressFamily != AddressFamily.InterNetwork)
            return false;

        return bytes[0] is not (0 or 10 or 127 or >= 224) &&
            !(bytes[0] == 100 && bytes[1] is >= 64 and <= 127) &&
            !(bytes[0] == 169 && bytes[1] == 254) &&
            !(bytes[0] == 172 && bytes[1] is >= 16 and <= 31) &&
            !(bytes[0] == 192 && ((bytes[1] == 0 && bytes[2] is 0 or 2) ||
                (bytes[1] == 88 && bytes[2] == 99) || bytes[1] == 168)) &&
            !(bytes[0] == 198 && (bytes[1] is 18 or 19 || (bytes[1] == 51 && bytes[2] == 100))) &&
            !(bytes[0] == 203 && bytes[1] == 0 && bytes[2] == 113);
    }
}

public sealed class OfficialPriceService(
    IHttpClientFactory clients, IMemoryCache cache, ILogger<OfficialPriceService> logger)
    : IDisposable
{
    private const int MaximumDocumentBytes = 1_500_000;
    private readonly SemaphoreSlim _networkSlots = new(4);
    private readonly ConcurrentDictionary<string, SemaphoreSlim> _sourceLocks = new();

    public async Task<OfficialPriceResult> CheckAsync(string type, int id, TourismItem? item,
        CancellationToken cancellationToken)
    {
        if (item is null)
            return new(type, id, null, "unavailable", null, "AED", null, null, null, null, null,
                "This place is no longer available in the catalogue.");

        var source = OfficialPriceSources.For(type, item.Name);
        var profile = PlaceEditorial.For(type, item.Name);
        decimal? estimate = profile.PriceOnRequest ? null : item.Price;
        string? editorialUrl = (PlaceEditorial.OfficialUri(profile.BookingUrl) ?? PlaceEditorial.OfficialUri(profile.OfficialUrl))?.AbsoluteUri;
        string catalogueUnit = profile.PriceUnit ?? (type == "Hotel" ? "per room per night" : "per person");
        if (source is null)
        {
            string message = type == "Hotel"
                ? "Confirm the rate with the hotel for your exact stay, occupancy and room."
                : "Confirm the price for your dates and group with the provider.";
            if (estimate.HasValue) message += " The plan uses a catalogue estimate.";
            return new(type, id, item.Name, "unavailable", estimate, item.Currency, catalogueUnit,
                null, null, editorialUrl, null, message);
        }

        var observation = await ReadSourceAsync(source, cancellationToken);

        if (observation.Price is decimal price)
            return new(type, id, item.Name, "published", estimate, "AED", source.Unit,
                price, source.Scope, source.Uri.AbsoluteUri, observation.CheckedAt,
                "Advertised official price. Confirm date, availability and party eligibility with the venue.");

        return new(type, id, item.Name, observation.CheckedAt.HasValue ? "unconfirmed" : "unavailable",
            estimate, item.Currency, catalogueUnit, null, source.Scope, source.Uri.AbsoluteUri,
            observation.CheckedAt, observation.CheckedAt.HasValue
                ? "The official page did not provide a clearly matching AED price. The catalogue estimate still applies."
                : "The official page could not be checked. The catalogue estimate still applies.");
    }

    private async Task<SourceObservation> ReadSourceAsync(OfficialPriceSource source, CancellationToken cancellationToken)
    {
        string key = source.Uri.AbsoluteUri;
        string cacheKey = "OfficialVenuePrice:" + key;
        if (cache.TryGetValue<SourceObservation>(cacheKey, out var cached) && cached is not null)
            return cached;

        using var deadline = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        deadline.CancelAfter(TimeSpan.FromSeconds(8));
        var sourceLock = _sourceLocks.GetOrAdd(key, _ => new SemaphoreSlim(1));
        try
        {
            await sourceLock.WaitAsync(deadline.Token);
            try
            {
                if (cache.TryGetValue<SourceObservation>(cacheKey, out cached) && cached is not null)
                    return cached;

                await _networkSlots.WaitAsync(deadline.Token);
                try
                {
                    var observed = await FetchAsync(source, deadline.Token);
                    cache.Set(cacheKey, observed, observed.Price.HasValue
                        ? TimeSpan.FromMinutes(30)
                        : TimeSpan.FromMinutes(observed.CheckedAt.HasValue ? 10 : 2));
                    return observed;
                }
                finally
                {
                    _networkSlots.Release();
                }
            }
            finally
            {
                sourceLock.Release();
            }
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            return SourceObservation.Unavailable;
        }
    }

    private async Task<SourceObservation> FetchAsync(OfficialPriceSource source, CancellationToken token)
    {
        try
        {
            using var client = clients.CreateClient(OfficialPriceRegistration.Client);
            using var response = await client.GetAsync(source.Uri, HttpCompletionOption.ResponseHeadersRead, token);
            if (!response.IsSuccessStatusCode ||
                response.Content.Headers.ContentType?.MediaType is not ("text/html" or "application/xhtml+xml") ||
                response.Content.Headers.ContentLength > MaximumDocumentBytes)
                return SourceObservation.Unavailable;

            await using var stream = await response.Content.ReadAsStreamAsync(token);
            using var buffer = new MemoryStream();
            var data = new byte[16_384];
            int count;
            while ((count = await stream.ReadAsync(data.AsMemory(), token)) != 0)
            {
                if (buffer.Length + count > MaximumDocumentBytes)
                    return SourceObservation.Unavailable;
                buffer.Write(data, 0, count);
            }

            string html = Encoding.UTF8.GetString(buffer.GetBuffer(), 0, (int)buffer.Length);
            return new(source.ReadPrice(html), DateTimeOffset.UtcNow);
        }
        catch (Exception exception) when (exception is HttpRequestException or IOException or RegexMatchTimeoutException)
        {
            logger.LogDebug("Official price check failed for {VenueHost} ({FailureType})",
                source.Uri.IdnHost, exception.GetType().Name);
            return SourceObservation.Unavailable;
        }
    }

    public void Dispose()
    {
        _networkSlots.Dispose();
        foreach (var sourceLock in _sourceLocks.Values)
            sourceLock.Dispose();
    }

    private sealed record SourceObservation(decimal? Price, DateTimeOffset? CheckedAt)
    {
        internal static SourceObservation Unavailable { get; } = new(null, null);
    }
}
