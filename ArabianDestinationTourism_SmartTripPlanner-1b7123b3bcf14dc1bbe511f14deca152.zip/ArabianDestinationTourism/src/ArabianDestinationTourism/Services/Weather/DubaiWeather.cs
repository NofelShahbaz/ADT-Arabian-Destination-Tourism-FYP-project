using System.Text.Json;
using Microsoft.Extensions.Caching.Memory;

namespace ArabianDestinationTourism.Services.Weather;

public sealed record DubaiDay(string Date, double Low, double High, double FeelsLikeHigh, int? Rain, double Wind, int Code)
{
    public string Conditions => Describe(Code);

    public static string Describe(int code) => code switch
    {
        0 => "Clear", 1 or 2 => "Partly cloudy", 3 => "Overcast", 45 or 48 => "Fog",
        >= 95 => "Thunderstorms", >= 80 => "Showers", >= 71 => "Snow", >= 61 => "Rain", >= 51 => "Drizzle", _ => "Variable"
    };
}

public sealed record DubaiForecast(double Temperature, double FeelsLike, string Conditions, IReadOnlyList<DubaiDay> Days, DateTimeOffset CheckedAt);

public sealed class DubaiWeather(HttpClient client, IConfiguration config, IWebHostEnvironment environment, IMemoryCache cache)
{
    public const string ClimateSource = "https://www.nodc.noaa.gov/archive/arc0216/0253808/2.2/data/0-data/Region-2-WMO-Normals-9120/UAE/CSV/DubaiIntlAirport_41194.csv";
    public static readonly IReadOnlyList<(string Month, decimal Low, decimal High)> Climate =
    [
        ("January",15.3m,24.4m),("February",16.4m,26.1m),("March",18.6m,28.9m),
        ("April",22.3m,33.7m),("May",26.1m,38.2m),("June",28.6m,40.3m),
        ("July",31.2m,41.5m),("August",31.5m,41.9m),("September",28.9m,39.5m),
        ("October",25.4m,35.9m),("November",21.1m,30.7m),("December",17.3m,26.5m)
    ];

    public async Task<DubaiForecast?> ForecastAsync(CancellationToken token)
    {
        if (cache.TryGetValue<DubaiForecast>("DubaiForecast", out var cached)) return cached;
        var key = config["Weather:CustomerApiKey"];
        var commercial = !string.IsNullOrWhiteSpace(key);
        if (!commercial && !config.GetValue("Weather:AllowNonCommercial", environment.IsDevelopment())) return null;
        var host = commercial ? "customer-api.open-meteo.com" : "api.open-meteo.com";
        var query = "latitude=25.2048&longitude=55.2708&timezone=Asia%2FDubai&forecast_days=7" +
            "&current=temperature_2m,apparent_temperature,weather_code&daily=temperature_2m_min,temperature_2m_max,apparent_temperature_max,precipitation_probability_max,wind_speed_10m_max,weather_code";
        if (commercial) query += "&apikey=" + Uri.EscapeDataString(key!);
        try
        {
            using var response = await client.GetAsync($"https://{host}/v1/forecast?{query}", token);
            response.EnsureSuccessStatusCode();
            using var json = await JsonDocument.ParseAsync(await response.Content.ReadAsStreamAsync(token), cancellationToken: token);
            var current = json.RootElement.GetProperty("current");
            var daily = json.RootElement.GetProperty("daily");
            var days = new List<DubaiDay>();
            var dates = daily.GetProperty("time");
            for (int i = 0; i < dates.GetArrayLength(); i++)
            {
                var date = dates[i].GetString();
                if (!DateOnly.TryParseExact(date, "yyyy-MM-dd", out _)) continue;
                var rain = daily.GetProperty("precipitation_probability_max")[i];
                days.Add(new(date!, daily.GetProperty("temperature_2m_min")[i].GetDouble(),
                    daily.GetProperty("temperature_2m_max")[i].GetDouble(), daily.GetProperty("apparent_temperature_max")[i].GetDouble(),
                    rain.ValueKind == JsonValueKind.Number ? rain.GetInt32() : null,
                    daily.GetProperty("wind_speed_10m_max")[i].GetDouble(), daily.GetProperty("weather_code")[i].GetInt32()));
            }
            var data = new DubaiForecast(current.GetProperty("temperature_2m").GetDouble(),
                current.GetProperty("apparent_temperature").GetDouble(),
                DubaiDay.Describe(current.GetProperty("weather_code").GetInt32()), days, DateTimeOffset.UtcNow);
            cache.Set("DubaiForecast", data, TimeSpan.FromMinutes(20));
            return data;
        }
        catch (Exception error) when (!token.IsCancellationRequested && error is
            HttpRequestException or JsonException or InvalidOperationException or KeyNotFoundException or IndexOutOfRangeException or OperationCanceledException)
        {
            cache.Set<DubaiForecast?>("DubaiForecast", null, TimeSpan.FromMinutes(2));
            return null;
        }
    }
}
