using System.Globalization;
using System.Text.RegularExpressions;
using ArabianDestinationTourism.Models.Entities;
using ArabianDestinationTourism.Models.ViewModels;

namespace ArabianDestinationTourism.Services.Itinerary;

public interface ITripBriefInterpreter
{
    Task<TripInterpretation?> InterpretAsync(string brief, CancellationToken cancellationToken);
}

public static class TripBrief
{
    private const string Quantity = @"\d{1,2}|twenty|nineteen|eighteen|seventeen|sixteen|fifteen|fourteen|thirteen|twelve|eleven|ten|nine|eight|seven|six|five|four|three|two|one";
    private const string Amount = @"(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d{1,2})?(?:\s*[kK](?![a-z]))?";
    private static readonly string[] Numbers = "zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen twenty".Split(' ');
    private static readonly (string Expression, string Tags)[] Interests =
    [
        (@"heritage|histori\w*|history|old dubai|tradition\w*", "culture,history,heritage"),
        (@"cultur\w*|museum\w*", "culture"),
        (@"landmarks?|skyline", "landmarks,architecture"),
        (@"beach\w*|seaside", "beach"),
        (@"adventure|safari|dunes?", "adventure,desert"),
        (@"shopping|malls?|souks?", "shopping"),
        (@"marina|creek|waterfront|boat\w*", "waterfront"),
        (@"food|culinary|dining", "food"),
        (@"nature|gardens?|wildlife", "nature,wildlife"),
        (@"luxury|upscale", "luxury"),
        (@"photograph\w*", "photography"),
        (@"kid\w*|child\w*|family", "family"),
        (@"spa|wellness", "wellness"),
        (@"walking|walks?", "walking")
    ];
    private static readonly (string Match, string Location)[] Areas =
    [
        ("old dubai|al fahidi", "Old Dubai"),
        ("downtown(?: dubai)?", "Downtown Dubai"),
        ("(?:dubai )?marina", "Dubai Marina"),
        ("palm jumeirah|the palm", "Palm Jumeirah"),
        ("jumeirah", "Jumeirah"),
        ("dubai desert", "Dubai Desert")
    ];

    public static bool Apply(PlannerVm preferences, string brief, IEnumerable<string> placeNames, out string? issue)
    {
        issue = null;
        var message = brief.Replace('’', '\'').Trim().ToLowerInvariant();
        if (Regex.IsMatch(message, @"\b(?:usd|eur|gbp|pkr|inr|sar)\b|[\$€£]"))
        {
            issue = "Enter the total budget in AED so I can compare it with Dubai catalogue prices.";
            return false;
        }
        var reserveMatch = Regex.Match(message,
            $@"\b(?:keep|reserve|hold back|set aside)\s*(?:aed\s*)?(?<amount>{Amount})\s*(?:aed\s*)?(?:as|for)\s+(?:emergency|contingency)\b");
        if (reserveMatch.Success && ParseAmount(reserveMatch.Groups["amount"].Value) is decimal reserve)
            preferences.EmergencyReserve = reserve;
        var budgetMessage = reserveMatch.Success ? message.Remove(reserveMatch.Index, reserveMatch.Length) : message;
        var budgetText = Regex.Replace(budgetMessage,
            $@"\b(?<thousands>{Quantity})\s+thousand(?:\s+(?:and\s+)?(?<hundreds>{Quantity})\s+hundred)?\b",
            match => (1000 * ParseQuantity(match.Groups["thousands"].Value) +
                (match.Groups["hundreds"].Success ? 100 * ParseQuantity(match.Groups["hundreds"].Value) : 0))
                .ToString(CultureInfo.InvariantCulture));
        const string currency = @"(?:aed|dhs?|dirhams?)";
        var budgetMatches = Regex.Matches(budgetText,
            $@"(?:\b{currency}\s*|\b(?:budget|total spend|we can spend|have|under|up to|at most)\s*(?:(?:is|of|around|about|approximately)\s*)?[:=]?\s*(?:{currency}\s*)?)(?<amount>{Amount})(?!\d|[,.]\d|\s*(?:days?|nights?|people|travell?ers|adults?|kids?|children|rooms?)\b)|(?<![\d,.])(?<amount>{Amount})\s*{currency}\b");
        var budgets = budgetMatches.Select(match => ParseAmount(match.Groups["amount"].Value)).Distinct().ToArray();
        bool budgetRead = budgets.Length == 1 && budgets[0].HasValue;
        if (budgets.Length > 1 || Regex.IsMatch(budgetMessage, @"\b(?:budget|aed|dhs?|dirhams?)\b[^.;]{0,28}\b(?:each|per person|per traveller|per day)\b"))
        {
            issue = "Enter one total AED budget for all travellers and days.";
            return false;
        }
        var dayValues = Regex.Matches(message,
            $@"\b(?<value>{Quantity})\s*[- ]?\s*days?\b|\bdays?\s+(?:are|is|of)\s+(?<value>{Quantity})\b")
            .Select(match => ParseQuantity(match.Groups["value"].Value)).Distinct().ToArray();
        var nightValues = Regex.Matches(message, $@"\b(?<value>{Quantity})\s*[- ]?\s*nights?\b")
            .Select(match => ParseQuantity(match.Groups["value"].Value) + 1).Distinct().ToArray();
        var duration = dayValues.Concat(nightValues).Distinct().ToArray();
        if (duration.Length > 1 || Regex.IsMatch(message, $@"\b(?:{Quantity})\s+or\s+(?:{Quantity})\s*(?:days?|nights?)\b"))
        {
            issue = "I found more than one trip length. Enter one number of days.";
            return false;
        }
        var explicitParty = Regex.Match(message, $@"\b(?<value>{Quantity})\s+(?:travell?ers|people|persons|guests)\b|\b(?:family|group|party)\s+of\s+(?<value>{Quantity})\b|\b(?:we are|there are|there will be|we're|for)\s+(?<value>{Quantity})(?=\s*(?:of us|people|travell?ers|[.,;]|$|under|with|and\b))");
        var countedParty = Regex.Matches(message, $@"\b(?<value>{Quantity})\s+(?:adult(?:s)?|child(?:ren)?|kid(?:s)?)\b");
        if (explicitParty.Success && countedParty.Count > 1 && countedParty.Sum(m => ParseQuantity(m.Groups["value"].Value)) != ParseQuantity(explicitParty.Groups["value"].Value))
        {
            issue = "The group total and the adult/child counts are different. Check the number of travellers.";
            return false;
        }
        var family = Regex.IsMatch(message, @"\b(?:family|kids?|children|child|child-friendly)\b");
        var hasIndoor = Regex.IsMatch(message, @"\b(?:afternoons?[^.;]{0,36}\bindoors?|indoors?[^.;]{0,24}\bafternoons?|(?:after|from)\s+1\s*(?:pm|p\.m\.)[^.;]{0,28}\bindoors?)\b");
        var hasAccess = Regex.IsMatch(message, @"\b(?:wheelchair|step-free|accessible|accessibility)\b");
        var limitedWalking = Regex.IsMatch(message, @"\b(?:elderly|limited walking|avoid long walks?|can'?t walk far|low mobility|short walks? only)\b");
        var publicTransport = Regex.IsMatch(message, @"\b(?:public transport|metro|bus(?:es)?)\b");
        var taxiTransport = Regex.IsMatch(message, @"\b(?:taxi|cab|private car)\b");
        var date = Regex.Match(message, @"\b(?:\d{4}-\d{2}-\d{2}|(?:\d{1,2}\s+(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)|(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\s+\d{1,2})(?:,?\s+\d{4})?)\b");
        var pace = Regex.Match(message, @"\b(?:relaxed|slow-paced|easy pace|fast-paced|packed|balanced)\b");
        var tags = Interests.Where(x => Regex.IsMatch(message, $@"\b(?:{x.Expression})\b"))
            .SelectMany(x => x.Tags.Split(',')).Distinct().ToArray();
        var area = Areas.FirstOrDefault(x => Regex.IsMatch(message, $@"\b(?:{x.Match})\b")).Location;
        var clauses = Regex.Split(message, @"[.;]|\bbut\b|\band\s+(?=(?:avoid|exclude|skip|include|keep|visit)\b)");
        var excluded = clauses.Where(s => Regex.IsMatch(s, @"\b(?:avoid|exclude|skip|do not visit|don't visit)\b")).ToArray();
        var included = clauses.Except(excluded).Where(s =>
            Regex.IsMatch(s, @"\b(?:include|keep|visit|must[ -]see|must[ -]visit)\b")).ToArray();
        var named = placeNames.Where(name => included.Any(sentence => MentionsPlace(sentence, name)))
            .Distinct(StringComparer.OrdinalIgnoreCase).Take(7).ToArray();
        var avoided = placeNames.Where(name => excluded.Any(sentence => MentionsPlace(sentence, name)))
            .Distinct(StringComparer.OrdinalIgnoreCase).Take(7).ToArray();
        if (named.Length > 6)
        {
            issue = "Choose up to six places you want to keep in the plan.";
            return false;
        }
        if (avoided.Length > 6 || named.Intersect(avoided, StringComparer.OrdinalIgnoreCase).Any())
        {
            issue = "Choose up to six places to avoid and resolve any place marked both required and excluded.";
            return false;
        }
        if (budgetRead)
            preferences.TotalBudget = budgets[0]!.Value;
        if (duration.Length == 1)
            preferences.Days = duration[0];
        else if (Regex.IsMatch(message, @"\b(?:a|one)\s+day\b"))
            preferences.Days = 1;
        if (explicitParty.Success)
            preferences.PartySize = ParseQuantity(explicitParty.Groups["value"].Value);
        else if (countedParty.Count > 0)
            preferences.PartySize = countedParty.Sum(m => ParseQuantity(m.Groups["value"].Value));
        else if (Regex.IsMatch(message, @"\b(?:solo|just me)\b"))
            preferences.PartySize = 1;
        else if (Regex.IsMatch(message, @"\b(?:couple|the two of us)\b"))
            preferences.PartySize = 2;
        if (date.Success)
        {
            var today = DateTime.UtcNow.AddHours(4).Date;
            bool iso = date.Value.Contains('-');
            var pattern = iso ? new[] { "yyyy-MM-dd" } : new[] { "d MMMM yyyy", "d MMM yyyy", "MMMM d yyyy", "MMM d yyyy" };
            var dateText = date.Value.Replace(",", "");
            bool givenYear = iso || Regex.IsMatch(dateText, @"\d{4}$");
            if (!givenYear)
                dateText = $"{dateText} {today.Year}";
            if (!DateTime.TryParseExact(dateText, pattern, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime starts))
            {
                issue = "I could not read that start date. Try a date like 2027-02-15.";
                return false;
            }
            if (!givenYear && starts < today)
                starts = starts.AddYears(1);
            preferences.StartDate = starts;
        }
        var relativeDate = Regex.Match(message, @"\b(?:starting|start|arriving|arrive|from)\s+(today|tomorrow)\b");
        if (!date.Success && relativeDate.Success)
            preferences.StartDate = DateTime.UtcNow.AddHours(4).Date.AddDays(relativeDate.Groups[1].Value == "tomorrow" ? 1 : 0);
        else if (!date.Success && Regex.IsMatch(message, @"\bnext (?:weekend|week|month)\b"))
        {
            issue = "Add a calendar date for your trip start, so I can use the correct dates.";
            return false;
        }
        if (pace.Success)
            preferences.TravelPace = pace.Value is "fast-paced" or "packed" ? TravelPace.Fast :
                pace.Value == "balanced" ? TravelPace.Balanced : TravelPace.Relaxed;
        if (family)
        {
            preferences.ChildFriendly = true;
            preferences.PartyType = PartyType.Family;
        }
        else if (preferences.PartySize == 1)
            preferences.PartyType = PartyType.Solo;
        if (hasIndoor)
            preferences.IndoorAfternoons = true;
        if (hasAccess)
            preferences.AccessibilityFriendly = true;
        if (limitedWalking)
            preferences.LimitedWalking = true;
        if (publicTransport && !taxiTransport)
            preferences.TransportPreference = TransportPreference.PublicTransport;
        else if (taxiTransport && !publicTransport)
            preferences.TransportPreference = TransportPreference.Taxi;
        else if (limitedWalking)
            preferences.TransportPreference = TransportPreference.MinimalWalking;
        if (tags.Length > 0)
            preferences.Interests = string.Join(',', tags);
        if (area is not null)
            preferences.PreferredLocation = area;
        if (named.Length > 0)
            preferences.MustIncludePlaces = string.Join(',', named);
        if (avoided.Length > 0)
        {
            var existing = (preferences.ExcludedPlaces ?? "").Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries);
            preferences.ExcludedPlaces = string.Join(",", existing.Concat(avoided).Distinct(StringComparer.OrdinalIgnoreCase));
        }

        return budgetRead || reserveMatch.Success || duration.Length == 1 || relativeDate.Success || explicitParty.Success || countedParty.Count > 0 ||
            date.Success || family || hasIndoor || hasAccess || limitedWalking || publicTransport || taxiTransport || pace.Success ||
            tags.Length > 0 || area is not null || named.Length > 0 || avoided.Length > 0 ||
            Regex.IsMatch(message, @"\b(?:solo|just me|couple|the two of us|a day)\b");
    }

    private static decimal? ParseAmount(string value)
    {
        var suffix = value.EndsWith('k');
        var amount = suffix ? value[..^1].TrimEnd() : value;
        return decimal.TryParse(amount, NumberStyles.Number, CultureInfo.InvariantCulture, out var parsed)
            ? parsed * (suffix ? 1000m : 1m) : null;
    }

    public static int ParseQuantity(string value) => int.TryParse(value, out var parsed)
        ? parsed : Array.IndexOf(Numbers, value.ToLowerInvariant());

    public static bool MentionsPlace(string message, string name) =>
        Regex.IsMatch(message, $@"(?<![\p{{L}}\d]){Regex.Escape(name)}(?![\p{{L}}\d])", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);

    public static string Summarize(PlannerVm preferences)
    {
        var area = string.IsNullOrEmpty(preferences.PreferredLocation) ? "" : $" Area preference is {preferences.PreferredLocation}.";
        var indoors = preferences.IndoorAfternoons ? " Afternoon stops are limited to catalogue venues marked indoors." : "";
        return $"I planned for {preferences.PartySize} {(preferences.PartySize == 1 ? "traveller" : "travellers")} over {preferences.Days} {(preferences.Days == 1 ? "day" : "days")}, starting {preferences.StartDate:dd MMM}, with an estimated total budget of AED {preferences.TotalBudget:N0}.{area}{indoors}";
    }
}
