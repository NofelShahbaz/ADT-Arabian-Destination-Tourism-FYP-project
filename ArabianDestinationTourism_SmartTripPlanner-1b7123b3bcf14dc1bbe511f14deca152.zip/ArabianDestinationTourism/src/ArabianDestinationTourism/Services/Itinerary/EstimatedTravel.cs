using ArabianDestinationTourism.Models.ViewModels;

namespace ArabianDestinationTourism.Services.Itinerary;

public enum TransportPreference { Balanced, Cheapest, Fastest, MinimalWalking, PublicTransport, Taxi }
public enum EstimatedTransportMode { Walking, PublicTransport, Taxi }
public sealed record EstimatedTravelLeg(int Minutes, double DistanceKm, decimal GroupCost,
    double WalkingKm, EstimatedTransportMode Mode);

public static class EstimatedTravel
{
    public static EstimatedTravelLeg Between(double fromLat, double fromLon, double toLat, double toLon,
        int travellers, TransportPreference preference, PlanObjective objective, bool limitedWalking)
    {
        if (travellers is < 1 or > 20 || !Valid(fromLat, fromLon) || !Valid(toLat, toLon))
            throw new ArgumentOutOfRangeException(nameof(travellers), "A route needs valid coordinates and group size.");
        double straight = Haversine(fromLat, fromLon, toLat, toLon);
        if (straight < .05)
            return new EstimatedTravelLeg(0, 0, 0, 0, EstimatedTransportMode.Walking);
        // Network distance is unavailable. The multiplier is an explicitly approximate planning allowance.
        double distance = Math.Max(.1, straight * 1.3);
        var mode = preference switch
        {
            TransportPreference.PublicTransport => EstimatedTransportMode.PublicTransport,
            TransportPreference.Taxi or TransportPreference.MinimalWalking => EstimatedTransportMode.Taxi,
            TransportPreference.Fastest => !limitedWalking && distance <= .6
                ? EstimatedTransportMode.Walking : EstimatedTransportMode.Taxi,
            TransportPreference.Cheapest => !limitedWalking && distance <= 1.5
                ? EstimatedTransportMode.Walking : EstimatedTransportMode.PublicTransport,
            _ when objective == PlanObjective.TimeSaver => !limitedWalking && distance <= .6
                ? EstimatedTransportMode.Walking : EstimatedTransportMode.Taxi,
            _ when objective == PlanObjective.BudgetSaver => !limitedWalking && distance <= 1.2
                ? EstimatedTransportMode.Walking : EstimatedTransportMode.PublicTransport,
            _ => !limitedWalking && distance <= .7 ? EstimatedTransportMode.Walking :
                distance <= 10 ? EstimatedTransportMode.PublicTransport : EstimatedTransportMode.Taxi
        };
        return mode switch
        {
            EstimatedTransportMode.Walking => new(
                (int)Math.Ceiling(distance / 4.3 * 60), distance, 0m, distance, mode),
            EstimatedTransportMode.PublicTransport => new(
                (int)Math.Ceiling(distance / 22 * 60 + 12), distance, 6m * travellers,
                Math.Min(.45, distance), mode),
            _ => new((int)Math.Ceiling(distance / 32 * 60 + 8), distance,
                (12m + (decimal)distance * 2.5m) * Math.Ceiling(travellers / 4m),
                Math.Min(.15, distance), mode)
        };
    }

    private static bool Valid(double latitude, double longitude) => double.IsFinite(latitude) &&
        double.IsFinite(longitude) && latitude is >= -90 and <= 90 && longitude is >= -180 and <= 180;

    private static double Haversine(double a, double b, double c, double d)
    {
        const double radiusKm = 6371;
        var latitude = (c - a) * Math.PI / 180;
        var longitude = (d - b) * Math.PI / 180;
        var value = Math.Sin(latitude / 2) * Math.Sin(latitude / 2) +
            Math.Cos(a * Math.PI / 180) * Math.Cos(c * Math.PI / 180) *
            Math.Sin(longitude / 2) * Math.Sin(longitude / 2);
        return radiusKm * 2 * Math.Atan2(Math.Sqrt(Math.Clamp(value, 0, 1)),
            Math.Sqrt(1 - Math.Clamp(value, 0, 1)));
    }
}
