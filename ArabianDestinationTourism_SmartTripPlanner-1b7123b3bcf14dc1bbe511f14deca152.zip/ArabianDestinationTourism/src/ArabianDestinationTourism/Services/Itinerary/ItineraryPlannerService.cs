using ArabianDestinationTourism.Data;
using ArabianDestinationTourism.Models.Entities;
using ArabianDestinationTourism.Models.ViewModels;
using ArabianDestinationTourism.Services.Interfaces;
using Microsoft.EntityFrameworkCore;
using ArabianDestinationTourism.Services.Pricing;

namespace ArabianDestinationTourism.Services.Itinerary;

/// <summary>
/// Budget-aware itinerary planner. All prices are AED catalogue estimates.
/// The budget is TOTAL for the whole party, not per person.
/// </summary>
public partial class ItineraryPlannerService(ApplicationDbContext db, IRecommendationService recommender) : IItineraryPlannerService
{
    public const decimal MinimumBudget = 500m;
    public const decimal MealsPerPersonPerDay = 35m;
    public const decimal TransportPerPersonPerDay = 20m;

    public Task<ItineraryResultVm> GenerateAsync(PlannerVm p) => GenerateForObjectiveAsync(p, PlanObjective.BestExperience);
    public Task<ItineraryResultVm> GenerateGreedyBaselineAsync(PlannerVm p) =>
        GenerateForObjectiveAsync(p, PlanObjective.GreedyBaseline);

    public async Task<IReadOnlyList<PlanVariantVm>> GenerateVariantsAsync(PlannerVm p)
    {
        var objectives = new[] { PlanObjective.BudgetSaver, PlanObjective.TimeSaver, PlanObjective.BestExperience };
        var variants = new List<PlanVariantVm>();
        foreach (var objective in objectives)
        {
            var result = await GenerateForObjectiveAsync(p, objective);
            variants.Add(new PlanVariantVm(objective, result, Measure(result)));
        }
        return variants;
    }

    public async Task<ItineraryResultVm> GenerateForObjectiveAsync(PlannerVm p, PlanObjective objective)
    {
        var result = new ItineraryResultVm();
        result.Objective = objective;
        if (p.Days is < 1 or > 14 || p.PartySize is < 1 or > 20 ||
            p.TotalBudget < MinimumBudget || p.TotalBudget > 100000 ||
            p.EmergencyReserve < 0 || p.EmergencyReserve > p.TotalBudget ||
            p.DailyAvailableHours is < 4 or > 16 || p.StartDate.Year is < 2000 or > 9998)
        {
            result.IsFeasible = false;
            result.Conflicts.Add("Choose 1–14 days, 1–20 travellers and a total budget of AED 500–100,000.");
            return result;
        }

        result.AccommodationNights = Math.Max(0, p.Days - 1);
        result.MealCost = MealsPerPersonPerDay * p.PartySize * p.Days;
        result.TransportCost = TransportPerPersonPerDay * p.PartySize * p.Days;
        result.EmergencyReserve = p.EmergencyReserve;
        decimal essentialCost = result.MealCost + result.TransportCost + result.EmergencyReserve;

        if (essentialCost > p.TotalBudget)
        {
            result.IsFeasible = false;
            result.Conflicts.Add($"Meals, transport and your protected reserve need AED {essentialCost:0}. Reduce the party size or duration, lower the reserve, or increase the budget.");
            result.Alternatives.Add("Try a one-day sightseeing trip or a larger total budget.");
            result.TotalEstimatedCost = result.MealCost + result.TransportCost;
            result.BudgetRemaining = p.TotalBudget - essentialCost;
            return result;
        }

        var candidates = await GetCandidatesAsync(p);
        var required = Split(p.MustIncludePlaces);
        var requiredCosts = candidates.Where(x => required.Contains(x.Place.Name.ToLowerInvariant()))
            .GroupBy(x => x.Place.Name, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(group => group.Key, group => group.Min(x => x.Place.Price * p.PartySize), StringComparer.OrdinalIgnoreCase);
        var stayCeiling = p.TotalBudget - essentialCost - requiredCosts.Values.Sum();

        // Accommodation is an optional 0-night expense for day trips, but mandatory for
        // multi-day itineraries. Favor preferred stars if the total remains affordable.
        if (result.AccommodationNights > 0)
        {
            var excludes = Split(p.ExcludedPlaces);
            var hotels = await db.Hotels.AsNoTracking().Include(x => x.Destination)
                .Where(x => x.Status == RecordStatus.Published)
                .ToListAsync();
            var eligible = hotels.Where(x =>
                !excludes.Contains(x.Name.ToLowerInvariant()) &&
                (!p.ChildFriendly || x.FamilyFriendly) &&
                (!p.AccessibilityFriendly || x.AccessibilityFriendly) &&
                string.Equals(x.Currency, "AED", StringComparison.OrdinalIgnoreCase))
                .Select(hotel => new { Hotel = hotel, Quote = HotelRoomRates.Quote(hotel, p.PartySize, result.AccommodationNights) })
                .Where(choice => choice.Quote is not null && choice.Quote.Total <= stayCeiling).ToList();

            if (eligible.Count == 0)
            {
                result.IsFeasible = false;
                result.Conflicts.Add(requiredCosts.Count > 0
                    ? "No hotel fits the budget remaining after estimated meals, transport and required tickets."
                    : "No hotel in the catalogue fits this multi-day budget after estimated meals and transport.");
                result.Alternatives.Add("Try fewer days, fewer travellers or a higher total budget.");
                result.Alternatives.Add("A one-day trip avoids accommodation costs.");
                result.TotalEstimatedCost = result.MealCost + result.TransportCost;
                result.BudgetRemaining = p.TotalBudget - essentialCost;
                return result;
            }

            decimal accommodationTarget = stayCeiling * .6m;
            var withinTarget = eligible.Where(x =>
                x.Quote!.Total <= accommodationTarget).ToList();
            var choices = withinTarget.Count > 0 ? withinTarget : eligible;
            var likelyStops = candidates.Take(8).ToArray();
            double CommuteMinutes(Hotel hotel) => likelyStops.Length == 0 ? 0 :
                likelyStops.Average(stop => EstimatedTravel.Between(hotel.Latitude, hotel.Longitude,
                    stop.Place.Latitude, stop.Place.Longitude, p.PartySize, p.TransportPreference,
                    objective, p.LimitedWalking).Minutes);
            decimal CommuteAllowance(Hotel hotel) => likelyStops.Length == 0 ? 0 :
                likelyStops.Average(stop => EstimatedTravel.Between(hotel.Latitude, hotel.Longitude,
                    stop.Place.Latitude, stop.Place.Longitude, p.PartySize, p.TransportPreference,
                    objective, p.LimitedWalking).GroupCost) * p.Days;
            var selection = objective == PlanObjective.BudgetSaver
                ? choices.OrderBy(x => x.Quote!.Total + CommuteAllowance(x.Hotel))
                    .ThenBy(x => x.Quote!.Total).ThenByDescending(x => x.Hotel.Rating).First()
                : objective == PlanObjective.TimeSaver
                    ? choices.OrderBy(x => CommuteMinutes(x.Hotel))
                        .ThenBy(x => x.Quote!.Total).First()
                    : choices.OrderBy(x => Math.Abs(x.Hotel.StarRating - p.PreferredHotelStars))
                        .ThenByDescending(x => x.Hotel.Rating).ThenBy(x => CommuteMinutes(x.Hotel))
                        .ThenBy(x => x.Quote!.Total).First();
            result.HotelId = selection.Hotel.Id;
            if (selection.Hotel.Latitude is > 24 and < 27 && selection.Hotel.Longitude is > 54 and < 57)
            {
                result.HotelLatitude = selection.Hotel.Latitude;
                result.HotelLongitude = selection.Hotel.Longitude;
            }
            result.HotelName = PlaceEditorial.For("Hotel", selection.Hotel.Name).DisplayName ?? selection.Hotel.Name;
            result.HotelCost = selection.Quote!.Total;
            result.RoomCount = selection.Quote.RoomCount;
            result.Rooms = selection.Quote.Allocation.ToList();

            if (selection.Hotel.StarRating > 0 && selection.Hotel.StarRating != p.PreferredHotelStars)
                result.Alternatives.Add($"Selected a {selection.Hotel.StarRating}-star stay to fit your budget (requested {p.PreferredHotelStars} stars).");
            result.Alternatives.AddRange(eligible.Where(x => x.Hotel.Id != selection.Hotel.Id)
                .OrderBy(x => x.Quote!.Total).Take(3)
                .Select(x => $"{x.Hotel.Name} · {x.Quote!.RoomCount} room(s), estimated AED {x.Quote.Total:0} for the stay"));
        }

        decimal activityBudget = Math.Max(0, p.TotalBudget - essentialCost - result.HotelCost);
        var optimized = objective == PlanObjective.GreedyBaseline
            ? GreedyBaselineSchedule(p, candidates, required, activityBudget,
                result.HotelLatitude, result.HotelLongitude)
            : OptimizeSchedule(p, candidates, required, activityBudget, objective,
                result.HotelLatitude, result.HotelLongitude);
        result.Days.AddRange(optimized.Days);
        if (!optimized.Complete)
            result.Conflicts.Add("No complete day-by-day schedule fits the available time, required stops and remaining group budget.");
        required.Clear();
        foreach (var name in optimized.MissingRequired)
            required.Add(name);
        foreach (var place in required)
            result.Conflicts.Add($"The requested stop “{place}” did not fit the dates, budget or preferences. Remove that requirement or revise the trip.");
        foreach (var day in result.Days)
        {
            var last = day.Items.LastOrDefault();
            if (last is null) continue;
            var restaurant = DiningCatalogue.All.Where(venue => venue.Latitude.HasValue && venue.Longitude.HasValue)
                .OrderBy(venue => Math.Pow((venue.Latitude!.Value - last.Latitude) * 111, 2) +
                    Math.Pow((venue.Longitude!.Value - last.Longitude) * 101, 2)).FirstOrDefault();
            day.DiningName = restaurant?.Name;
            day.DiningSlug = restaurant?.Slug;
        }
        Recalculate(p, result);
        result.IsFeasible = result.IsFeasible && required.Count == 0;
        if (result.Days.All(x => x.Items.Count == 0))
            result.Alternatives.Add("Try a one-day itinerary or choose different interests and constraints.");
        return result;
    }

    public async Task<TripPlan> SaveAsync(string userId, PlannerVm p, ItineraryResultVm result)
    {
        if (!result.IsFeasible || result.TotalEstimatedCost > p.TotalBudget)
            throw new InvalidOperationException("Only feasible itineraries within the selected budget can be saved.");

        var trip = new TripPlan
        {
            UserId = userId,
            Name = $"Dubai Trip {p.StartDate:dd MMM yyyy}",
            StartDate = p.StartDate.Date,
            EndDate = p.StartDate.Date.AddDays(p.Days - 1),
            Budget = p.TotalBudget,
            TotalEstimatedCost = result.TotalEstimatedCost
        };
        foreach (var d in result.Days)
        {
            var day = new TripDay { DayNumber = d.DayNumber, Date = d.Date };
            foreach (var item in d.Items)
                day.Items.Add(new TripItem
                {
                    ItemType = item.ItemType, TourismItemId = item.ItemId,
                    PlaceName = item.Name, StartTime = item.StartTime,
                    DurationMinutes = item.DurationMinutes,
                    TravelBufferMinutes = item.TravelBufferMinutes,
                    EstimatedCost = item.Cost, Latitude = item.Latitude,
                    Longitude = item.Longitude, RecommendationReason = item.Reason
                });
            trip.Days.Add(day);
        }
        db.TripPlans.Add(trip);
        await db.SaveChangesAsync();
        return trip;
    }

    private static HashSet<string> Split(string? raw) => new((raw ?? "")
        .Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries)
        .Select(x => x.ToLowerInvariant()));

    private static double Distance(double a, double b, double c, double d)
    {
        const double r = 6371;
        double dLat = (c - a) * Math.PI / 180, dLon = (d - b) * Math.PI / 180;
        double z = Math.Sin(dLat / 2) * Math.Sin(dLat / 2) +
            Math.Cos(a * Math.PI / 180) * Math.Cos(c * Math.PI / 180) *
            Math.Sin(dLon / 2) * Math.Sin(dLon / 2);
        return r * 2 * Math.Atan2(Math.Sqrt(Math.Clamp(z, 0, 1)), Math.Sqrt(1 - Math.Clamp(z, 0, 1)));
    }
}
