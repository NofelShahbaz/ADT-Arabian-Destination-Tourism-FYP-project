using System.Globalization;
using ArabianDestinationTourism.Models.Entities;
using ArabianDestinationTourism.Models.ViewModels;

namespace ArabianDestinationTourism.Services.Itinerary;

// The LLM interprets the request. Catalogue, date, schedule and budget checks remain in the application.
public sealed class TripInterpretation
{
    public int? Days { get; set; }
    public int? PartySize { get; set; }
    public decimal? TotalBudgetAed { get; set; }
    public decimal? EmergencyReserveAed { get; set; }
    public string? StartDate { get; set; }
    public int? PreferredHotelStars { get; set; }
    public string? PreferredLocation { get; set; }
    public string? TravelPace { get; set; }
    public string? TransportPreference { get; set; }
    public bool? ChildFriendly { get; set; }
    public bool? AccessibilityFriendly { get; set; }
    public bool? LimitedWalking { get; set; }
    public bool? IndoorAfternoons { get; set; }
    public string[] Interests { get; set; } = [];
    public string[] RequiredPlaces { get; set; } = [];
    public string[] ExcludedPlaces { get; set; } = [];
    public string[] MissingRequirements { get; set; } = [];
    public string[] Ambiguities { get; set; } = [];
    public double Confidence { get; set; }

    public bool IsValid()
    {
        if (Days is < 1 or > 14 || PartySize is < 1 or > 20 ||
            TotalBudgetAed is < 500 or > 100000 || EmergencyReserveAed is < 0 or > 100000 ||
            PreferredHotelStars is < 1 or > 5 || !double.IsFinite(Confidence) || Confidence is < 0 or > 1)
            return false;
        if (TotalBudgetAed.HasValue && EmergencyReserveAed > TotalBudgetAed) return false;
        if (StartDate is not null && !DateTime.TryParseExact(StartDate, "yyyy-MM-dd",
                CultureInfo.InvariantCulture, DateTimeStyles.None, out _)) return false;
        if (TravelPace is not null && !Enum.TryParse<global::ArabianDestinationTourism.Models.Entities.TravelPace>(TravelPace, true, out _))
            return false;
        if (TransportPreference is not null && !Enum.TryParse<global::ArabianDestinationTourism.Services.Itinerary.TransportPreference>(TransportPreference, true, out _))
            return false;
        if (Interests is null || RequiredPlaces is null || ExcludedPlaces is null ||
            MissingRequirements is null || Ambiguities is null) return false;
        return new[] { Interests, RequiredPlaces, ExcludedPlaces, MissingRequirements, Ambiguities }
            .All(values => values.Length <= 10 && values.All(value =>
                !string.IsNullOrWhiteSpace(value) && value.Length <= 100));
    }

    public void ApplyTo(PlannerVm preferences, IEnumerable<string> catalogueNames)
    {
        if (!IsValid()) throw new InvalidOperationException("The AI preference output is invalid.");
        var allowed = catalogueNames.ToHashSet(StringComparer.OrdinalIgnoreCase);
        if (Days.HasValue) preferences.Days = Days.Value;
        if (PartySize.HasValue) preferences.PartySize = PartySize.Value;
        if (TotalBudgetAed.HasValue) preferences.TotalBudget = TotalBudgetAed.Value;
        if (EmergencyReserveAed.HasValue) preferences.EmergencyReserve = EmergencyReserveAed.Value;
        if (StartDate is not null) preferences.StartDate = DateTime.ParseExact(StartDate,
            "yyyy-MM-dd", CultureInfo.InvariantCulture);
        if (PreferredHotelStars.HasValue) preferences.PreferredHotelStars = PreferredHotelStars.Value;
        if (TravelPace is not null) preferences.TravelPace = Enum.Parse<global::ArabianDestinationTourism.Models.Entities.TravelPace>(TravelPace, true);
        if (TransportPreference is not null) preferences.TransportPreference = Enum.Parse<global::ArabianDestinationTourism.Services.Itinerary.TransportPreference>(TransportPreference, true);
        if (ChildFriendly.HasValue) preferences.ChildFriendly = ChildFriendly.Value;
        if (AccessibilityFriendly.HasValue) preferences.AccessibilityFriendly = AccessibilityFriendly.Value;
        if (LimitedWalking.HasValue) preferences.LimitedWalking = LimitedWalking.Value;
        if (IndoorAfternoons.HasValue) preferences.IndoorAfternoons = IndoorAfternoons.Value;
        if (!string.IsNullOrWhiteSpace(PreferredLocation) && PreferredLocation.Length <= 120)
            preferences.PreferredLocation = PreferredLocation;
        if (Interests.Length > 0)
        {
            var tags = string.Join(',', Interests.Select(value => value.Trim().ToLowerInvariant()));
            preferences.Interests = tags[..Math.Min(250, tags.Length)];
        }
        var required = RequiredPlaces.Where(allowed.Contains).Distinct(StringComparer.OrdinalIgnoreCase).Take(6).ToArray();
        var excluded = ExcludedPlaces.Where(allowed.Contains).Distinct(StringComparer.OrdinalIgnoreCase).Take(6).ToArray();
        if (required.Intersect(excluded, StringComparer.OrdinalIgnoreCase).Any())
            throw new InvalidOperationException("An AI response marked a place both required and excluded.");
        if (required.Length > 0) preferences.MustIncludePlaces = string.Join(',', required);
        if (excluded.Length > 0) preferences.ExcludedPlaces = string.Join(',', excluded);
    }
}
