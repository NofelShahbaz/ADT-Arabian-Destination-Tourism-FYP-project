using ArabianDestinationTourism.Models.ViewModels;
using ArabianDestinationTourism.Models.Entities;

namespace ArabianDestinationTourism.Services.Itinerary;

public partial class ItineraryPlannerService
{
    // Bounded beam search explores several feasible partial itineraries at each stop.
    // GreedyBaselineSchedule below retains a single-path reference for comparison.
    private sealed record SearchState(List<PlannedDayVm> Days, HashSet<(string Type, int Id)> Used,
        decimal TicketCost, decimal RouteCost, double Match, int TravelMinutes, double TravelKm,
        int RequiredCount)
    {
        public int Stops => Used.Count;
    }
    private sealed record SearchResult(List<PlannedDayVm> Days, bool Complete, IReadOnlyList<string> MissingRequired);

    private static SearchResult GreedyBaselineSchedule(PlannerVm preferences, IReadOnlyList<Candidate> candidates,
        HashSet<string> required, decimal ticketBudget, double? hotelLat, double? hotelLon)
    {
        var days = new List<PlannedDayVm>();
        var used = new HashSet<(string, int)>();
        var missing = new HashSet<string>(required, StringComparer.OrdinalIgnoreCase);
        decimal spent = 0m;
        int maximumStops = preferences.TravelPace switch
        {
            TravelPace.Relaxed => 2, TravelPace.Fast => 4, _ => 3
        };
        for (int number = 1; number <= preferences.Days; number++)
        {
            var day = new PlannedDayVm { DayNumber = number, Date = preferences.StartDate.Date.AddDays(number - 1) };
            var anchor = candidates.FirstOrDefault(x => !used.Contains((x.Place.ItemType, x.Place.ItemId)) &&
                missing.Contains(x.Place.Name)) ?? candidates.FirstOrDefault(x => !used.Contains((x.Place.ItemType, x.Place.ItemId)));
            foreach (var candidate in candidates.OrderByDescending(x => missing.Contains(x.Place.Name))
                .ThenBy(x => anchor is null ? 0 : Distance(anchor.Place.Latitude, anchor.Place.Longitude,
                    x.Place.Latitude, x.Place.Longitude)).ThenByDescending(x => x.Place.Scores.Final))
            {
                var place = candidate.Place;
                if (used.Contains((place.ItemType, place.ItemId))) continue;
                var cost = place.Price * preferences.PartySize;
                var previous = day.Items.LastOrDefault();
                var travel = previous is not null
                    ? EstimateLeg(preferences, PlanObjective.GreedyBaseline, previous.Latitude, previous.Longitude,
                        place.Latitude, place.Longitude)
                    : hotelLat.HasValue && hotelLon.HasValue
                        ? EstimateLeg(preferences, PlanObjective.GreedyBaseline, hotelLat.Value, hotelLon.Value,
                            place.Latitude, place.Longitude) : null;
                if (cost < 0 || spent + cost + (travel?.GroupCost ?? 0) > ticketBudget) continue;
                var earliest = previous is null ? DayStart : previous.StartTime +
                    TimeSpan.FromMinutes(previous.DurationMinutes + (travel?.Minutes ?? 0));
                if (previous is null && travel is not null) earliest += TimeSpan.FromMinutes(travel.Minutes);
                var start = MoveAfterMealBreak(earliest > candidate.Opens ? earliest : candidate.Opens,
                    candidate.Duration);
                if (!Fits(preferences, candidate, day.Date, start)) continue;
                day.Items.Add(ToItem(candidate, start, travel, cost, missing.Contains(place.Name)));
                used.Add((place.ItemType, place.ItemId));
                missing.Remove(place.Name);
                spent += cost + (travel?.GroupCost ?? 0);
                if (day.Items.Count == maximumStops) break;
            }
            days.Add(day);
        }
        return new(days, days.All(day => day.Items.Count > 0), missing.ToArray());
    }

    private static SearchResult OptimizeSchedule(PlannerVm preferences, IReadOnlyList<Candidate> candidates,
        HashSet<string> required, decimal ticketBudget, PlanObjective objective,
        double? hotelLat, double? hotelLon)
    {
        const int beamWidth = 32;
        int maximumStops = preferences.TravelPace switch
        {
            TravelPace.Relaxed => 2,
            TravelPace.Fast => 4,
            _ => 3
        };
        var beam = new List<SearchState>
        {
            new([], new HashSet<(string, int)>(), 0m, 0m, 0d, 0, 0d, 0)
        };
        for (int dayIndex = 0; dayIndex < preferences.Days; dayIndex++)
        {
            var date = preferences.StartDate.Date.AddDays(dayIndex);
            var frontier = beam.Select(state => state with
            {
                Days = [..state.Days, new PlannedDayVm { DayNumber = dayIndex + 1, Date = date }]
            }).ToList();
            var completedDay = new List<SearchState>();
            for (int slot = 0; slot < maximumStops; slot++)
            {
                var next = new List<SearchState>();
                foreach (var state in frontier)
                {
                    var day = state.Days[^1];
                    var lastStop = day.Items.LastOrDefault();
                    var choices = candidates.Where(x => !state.Used.Contains((x.Place.ItemType, x.Place.ItemId)))
                        .OrderByDescending(x => required.Contains(x.Place.Name.ToLowerInvariant()))
                        .ThenBy(x => objective == PlanObjective.BudgetSaver ? (double)x.Place.Price :
                            objective == PlanObjective.TimeSaver && lastStop is not null
                                ? Distance(lastStop.Latitude, lastStop.Longitude, x.Place.Latitude, x.Place.Longitude)
                                : -x.Place.Scores.Final)
                        .Take(24);
                    foreach (var candidate in choices)
                    {
                        var place = candidate.Place;
                        if (state.Used.Contains((place.ItemType, place.ItemId))) continue;
                        decimal cost = place.Price * preferences.PartySize;
                        var previous = day.Items.LastOrDefault();
                        var travel = previous is not null
                            ? EstimateLeg(preferences, objective, previous.Latitude, previous.Longitude,
                                place.Latitude, place.Longitude)
                            : hotelLat.HasValue && hotelLon.HasValue
                                ? EstimateLeg(preferences, objective, hotelLat.Value, hotelLon.Value,
                                    place.Latitude, place.Longitude) : null;
                        var travelCost = travel?.GroupCost ?? 0;
                        if (cost < 0 || state.TicketCost + state.RouteCost + cost + travelCost > ticketBudget)
                            continue;
                        var cursor = previous is null ? DayStart : previous.StartTime +
                            TimeSpan.FromMinutes(previous.DurationMinutes + (travel?.Minutes ?? 0));
                        if (previous is null && travel is not null) cursor += TimeSpan.FromMinutes(travel.Minutes);
                        var start = MoveAfterMealBreak(cursor > candidate.Opens ? cursor : candidate.Opens,
                            candidate.Duration);
                        if (!Fits(preferences, candidate, date, start)) continue;
                        var used = new HashSet<(string, int)>(state.Used) { (place.ItemType, place.ItemId) };
                        var newDays = state.Days.Select(CloneDay).ToList();
                        newDays[^1].Items.Add(ToItem(candidate, start, travel, cost,
                            required.Contains(place.Name.ToLowerInvariant())));
                        var newState = new SearchState(newDays, used, state.TicketCost + cost,
                            state.RouteCost + travelCost, state.Match + place.Scores.Final,
                            state.TravelMinutes + (travel?.Minutes ?? 0),
                            state.TravelKm + (travel?.DistanceKm ?? 0),
                            state.RequiredCount + (required.Contains(place.Name.ToLowerInvariant()) ? 1 : 0));
                        if (candidates.Count - newState.Stops < preferences.Days - dayIndex - 1)
                            continue;
                        // Reserve enough ticket budget for required stops not yet selected.
                        var reserve = candidates.Where(x => required.Contains(x.Place.Name.ToLowerInvariant()) &&
                                !used.Contains((x.Place.ItemType, x.Place.ItemId)))
                            .GroupBy(x => x.Place.Name, StringComparer.OrdinalIgnoreCase)
                            .Sum(group => group.Min(x => x.Place.Price * preferences.PartySize));
                        if (newState.TicketCost + newState.RouteCost + reserve <= ticketBudget)
                            next.Add(newState);
                    }
                }
                if (next.Count == 0) break;
                frontier = Rank(next, objective, beamWidth);
                completedDay.AddRange(frontier);
            }
            if (completedDay.Count == 0)
            {
                var partial = beam[0].Days.Select(CloneDay).ToList();
                for (int missing = dayIndex; missing < preferences.Days; missing++)
                    partial.Add(new PlannedDayVm { DayNumber = missing + 1,
                        Date = preferences.StartDate.Date.AddDays(missing) });
                return new(partial, false, required.ToArray());
            }
            beam = Rank(completedDay, objective, beamWidth);
        }
        var best = beam.Where(state => state.RequiredCount >= required.Count)
            .OrderByDescending(state => Utility(state, objective)).FirstOrDefault()
            ?? beam.OrderByDescending(state => state.RequiredCount)
                .ThenByDescending(state => Utility(state, objective)).First();
        var visited = best.Days.SelectMany(day => day.Items).Select(item => item.Name.ToLowerInvariant()).ToHashSet();
        return new(best.Days, true, required.Where(name => !visited.Contains(name)).ToArray());
    }

    private static List<SearchState> Rank(IEnumerable<SearchState> candidates, PlanObjective objective, int width) =>
        candidates.OrderByDescending(state => state.RequiredCount)
            .ThenByDescending(state => Utility(state, objective))
            .ThenBy(state => string.Join(',', state.Used.OrderBy(x => x.Type).ThenBy(x => x.Id)))
            .Take(width).ToList();

    private static double Utility(SearchState state, PlanObjective objective) => objective switch
    {
        PlanObjective.BudgetSaver => state.Stops * 1.5 + state.Match * .2 - (double)(state.TicketCost + state.RouteCost) / 35d
            - state.TravelMinutes / 60d,
        PlanObjective.TimeSaver => state.Stops * 2 + state.Match * .5 - state.TravelMinutes / 12d
            - (double)(state.TicketCost + state.RouteCost) / 400d,
        _ => state.Match * 6 + state.Stops * 2 - (double)(state.TicketCost + state.RouteCost) / 600d
            - state.TravelMinutes / 100d
    };

    private static PlannedDayVm CloneDay(PlannedDayVm day) => new()
    {
        DayNumber = day.DayNumber, Date = day.Date, DiningName = day.DiningName,
        DiningSlug = day.DiningSlug,
        Items = day.Items.Select(item => new PlannedItemVm
        {
            ItemType = item.ItemType, ItemId = item.ItemId, Name = item.Name,
            StartTime = item.StartTime, DurationMinutes = item.DurationMinutes,
            TravelBufferMinutes = item.TravelBufferMinutes, TravelCost = item.TravelCost,
            TravelDistanceKm = item.TravelDistanceKm, TravelMode = item.TravelMode, Cost = item.Cost,
            Reason = item.Reason, Latitude = item.Latitude, Longitude = item.Longitude,
            IsPinned = item.IsPinned, HoursNote = item.HoursNote, MatchScore = item.MatchScore
        }).ToList()
    };

    private static PlanMetrics Measure(ItineraryResultVm result)
    {
        var items = result.Days.SelectMany(day => day.Items).ToArray();
        var distance = items.Sum(item => item.TravelDistanceKm);
        var match = items.Length == 0 ? 0 : (int)Math.Round(items.Average(item => item.MatchScore) * 100);
        return new(items.Length, items.Sum(item => item.DurationMinutes),
            items.Sum(item => item.TravelBufferMinutes), distance, match);
    }
}
