using System.Text.RegularExpressions;
using ArabianDestinationTourism.Models.ViewModels;
using ArabianDestinationTourism.Data;

namespace ArabianDestinationTourism.Services.Itinerary;

public partial class ItineraryPlannerService
{
    private sealed record Stop(PlannedDayVm Day, PlannedItemVm Item);

    public async Task<ItineraryEditResult> EditAsync(PlannerVm p, ItineraryResultVm result, string operation,
        int dayNumber, string? itemType, int itemId, string? message)
    {
        var stops = result.Days.SelectMany(day => day.Items.Select(item => new Stop(day, item))).ToArray();
        Stop? target = stops.FirstOrDefault(x => x.Day.DayNumber == dayNumber &&
            x.Item.ItemType.Equals(itemType, StringComparison.OrdinalIgnoreCase) && x.Item.ItemId == itemId);
        bool cheaper = false;
        bool indoors = false;
        string? requestedReplacement = null;
        if (operation == "ask")
        {
            if (string.IsNullOrWhiteSpace(message))
                return new("Tell me what to change. Try “make day 2 cheaper” or “keep the Abra Ride”.", false);
            var lower = message.Trim().ToLowerInvariant();
            dayNumber = MatchDay(lower);
            var scoped = dayNumber == 0 ? stops : stops.Where(x => x.Day.DayNumber == dayNumber).ToArray();
            if (dayNumber != 0 && !result.Days.Any(x => x.DayNumber == dayNumber))
                return new($"This trip has no day {dayNumber}. Choose one of its existing days.", false);
            var replaceWith = Regex.Match(lower, @"\b(?:swap|replace)\b(?<target>.*?)\b(?:with|for)\b\s*(?<replacement>.+)$");
            var targetText = replaceWith.Success ? replaceWith.Groups["target"].Value : message;
            var named = scoped.Where(x => TripBrief.MentionsPlace(targetText, x.Item.Name)).ToArray();
            if (named.Length > 1)
                return new("Name one stop at a time, or use a stop's controls to choose it directly.", false);
            var namedOutsideScope = named.Length == 0 && stops.Any(x => TripBrief.MentionsPlace(targetText, x.Item.Name));
            if (namedOutsideScope)
                return new("That stop belongs to another day. Check the day number or use the controls beside the stop.", false);
            target = named.FirstOrDefault();

            if (Regex.IsMatch(lower, @"\b(?:why|reason)\b") && target is not null)
                return new($"{target.Item.Name} · {target.Item.Reason} Estimated group cost AED {target.Item.Cost:N0}.", false);
            if (Regex.IsMatch(lower, @"\b(?:budget|cost|total|spend)\b") &&
                Regex.IsMatch(lower, @"\b(?:how much|what is|what's|show|breakdown|left|remaining)\b"))
                return new($"The trip estimate is AED {result.TotalEstimatedCost:N0}, leaving AED {result.BudgetRemaining:N0} of the group budget.", false);
            if (Regex.IsMatch(lower, @"\b(?:unpin|unlock)\b"))
                operation = "unpin";
            else if (Regex.IsMatch(lower, @"\b(?:pin|keep|lock)\b"))
                operation = "keep";
            else if (Regex.IsMatch(lower, @"\b(?:remove|skip|drop)\b"))
                operation = "remove";
            else
            {
                cheaper = Regex.IsMatch(lower, @"\b(?:cheaper|less expensive|lower (?:the )?cost|save money)\b") &&
                    !Regex.IsMatch(lower, @"^(?:is |would |how much )");
                indoors = Regex.IsMatch(lower, @"\bindoors?\b") && Regex.IsMatch(lower, @"\b(?:make|swap|replace|find)\b");
                if (cheaper || indoors || Regex.IsMatch(lower, @"\b(?:swap|replace)\b"))
                    operation = "swap";
                if (replaceWith.Success && !cheaper && !indoors)
                    requestedReplacement = replaceWith.Groups["replacement"].Value;
            }

            if (operation == "swap" && target is null && dayNumber != 0 && (cheaper || indoors))
            {
                var targets = scoped.Where(x => !x.Item.IsPinned && !x.Item.IsCompleted &&
                    (!indoors || !IsIndoor(x.Item.ItemType, x.Item.Name))).OrderByDescending(x => x.Item.Cost);
                var options = await GetCandidatesAsync(p);
                foreach (var stop in targets)
                {
                    var swap = TrySwap(p, result, stop, options, cheaper, indoors);
                    if (swap.Changed)
                        return swap;
                }
                return new($"I found no fitting {(cheaper ? "cheaper" : "indoor")} replacement on day {dayNumber}. Your itinerary is intact.", false);
            }
        }

        if (operation is not ("pin" or "keep" or "unpin" or "swap" or "remove" or "complete"))
            return new("Try “make day 2 cheaper”, “why Dubai Frame”, or name a stop to keep, swap or remove.", false);
        if (target is null)
            return new("Which stop should I change? Name it exactly as it appears, or choose a control beside the stop.", false);

        if (operation == "complete")
        {
            if (target.Item.IsCompleted)
                return new($"{target.Item.Name} is already marked complete.", false);
            target.Item.IsCompleted = true;
            target.Item.IsPinned = true;
            return new($"Marked {target.Item.Name} complete. It is protected from draft edits.", true);
        }
        if (target.Item.IsCompleted)
            return new($"{target.Item.Name} is complete and cannot be changed in this draft.", false);

        if (operation is "pin" or "keep" or "unpin")
        {
            bool pin = operation == "pin" ? !target.Item.IsPinned : operation == "keep";
            if (pin == target.Item.IsPinned)
                return new($"{target.Item.Name} is already {(pin ? "pinned" : "unlocked")}.", false);
            target.Item.IsPinned = pin;
            return new(pin
                ? $"Pinned {target.Item.Name} on day {target.Day.DayNumber}. Its time is protected during edits."
                : $"Unlocked {target.Item.Name} on day {target.Day.DayNumber}. You can now swap or remove it.", true);
        }

        if (!result.IsFeasible)
            return new("This draft still has a planning conflict. Adjust the trip brief to resolve it before changing individual stops.", false);
        if (target.Item.IsPinned)
            return new($"{target.Item.Name} is pinned. Unlock it first if you want to change it.", false);
        if (operation == "swap")
        {
            var candidates = await GetCandidatesAsync(p);
            if (requestedReplacement is null)
                return TrySwap(p, result, target, candidates, cheaper, indoors);
            var namedOptions = candidates.Where(x => TripBrief.MentionsPlace(requestedReplacement, x.Place.Name)).ToArray();
            if (namedOptions.Length != 1)
                return new("I could not match that replacement to one eligible place in the catalogue. Try its exact name.", false);
            return TrySwap(p, result, target, namedOptions, cheaper, indoors);
        }

        if (target.Day.Items.Count <= 1)
            return new($"Day {target.Day.DayNumber} needs at least one stop. Try swapping {target.Item.Name} instead.", false);
        int index = target.Day.Items.IndexOf(target.Item);
        var earlier = index > 0 ? target.Day.Items[index - 1] : null;
        var later = index < target.Day.Items.Count - 1 ? target.Day.Items[index + 1] : null;
        var nextTravel = later is null ? null : earlier is not null
            ? EstimateLeg(p, result.Objective, earlier.Latitude, earlier.Longitude,
                later.Latitude, later.Longitude)
            : result.HotelLatitude.HasValue && result.HotelLongitude.HasValue
                ? EstimateLeg(p, result.Objective, result.HotelLatitude.Value, result.HotelLongitude.Value,
                    later.Latitude, later.Longitude) : null;
        if (earlier is not null && later is not null &&
            earlier.StartTime + TimeSpan.FromMinutes(earlier.DurationMinutes + (nextTravel?.Minutes ?? 0)) > later.StartTime)
            return new("Removing this stop would leave too little estimated travel time between its neighbours. Try a swap.", false);
        var changeInCost = (nextTravel?.GroupCost ?? 0) - target.Item.Cost - target.Item.TravelCost -
            (later?.TravelCost ?? 0);
        if (changeInCost > result.BudgetRemaining)
            return new("Removing this stop would increase the route cost beyond the group budget.", false);
        target.Day.Items.RemoveAt(index);
        if (later is not null)
            SetTravel(later, nextTravel);
        Recalculate(p, result);
        return new($"Removed {target.Item.Name} from day {target.Day.DayNumber}. Estimated savings are AED {target.Item.Cost:N0}.", true);
    }

    private static ItineraryEditResult TrySwap(PlannerVm p, ItineraryResultVm result, Stop target,
        IEnumerable<Candidate> candidates, bool cheaper, bool indoors)
    {
        if (!result.IsFeasible || target.Item.IsPinned)
            return new("This stop cannot be replaced while the trip has an unresolved conflict or the stop is pinned.", false);
        int index = target.Day.Items.IndexOf(target.Item);
        var before = index > 0 ? target.Day.Items[index - 1] : null;
        var after = index < target.Day.Items.Count - 1 ? target.Day.Items[index + 1] : null;
        var used = result.Days.SelectMany(day => day.Items).Select(item => (item.ItemType, item.ItemId)).ToHashSet();
        var options = candidates.Where(x => !used.Contains((x.Place.ItemType, x.Place.ItemId)) &&
            (!cheaper || x.Place.Price * p.PartySize < target.Item.Cost) &&
            (!indoors || IsIndoor(x.Place.ItemType, x.Place.Name)));
        if (cheaper)
            options = options.OrderBy(x => x.Place.Price).ThenByDescending(x => x.Place.Scores.Final);
        else
            options = options.OrderBy(x => Distance(target.Item.Latitude, target.Item.Longitude, x.Place.Latitude, x.Place.Longitude))
                .ThenByDescending(x => x.Place.Scores.Final);

        foreach (var candidate in options)
        {
            var place = candidate.Place;
            var cost = place.Price * p.PartySize;
            var travel = before is not null
                ? EstimateLeg(p, result.Objective, before.Latitude, before.Longitude,
                    place.Latitude, place.Longitude)
                : result.HotelLatitude.HasValue && result.HotelLongitude.HasValue
                    ? EstimateLeg(p, result.Objective, result.HotelLatitude.Value, result.HotelLongitude.Value,
                        place.Latitude, place.Longitude) : null;
            var earliest = before is null ? DayStart + TimeSpan.FromMinutes(travel?.Minutes ?? 0) :
                before.StartTime + TimeSpan.FromMinutes(before.DurationMinutes + (travel?.Minutes ?? 0));
            var starts = MoveAfterMealBreak(earliest > candidate.Opens ? earliest : candidate.Opens,
                candidate.Duration);
            if (!Fits(p, candidate, target.Day.Date, starts))
                continue;
            var nextTravel = after is null ? null : EstimateLeg(p, result.Objective,
                place.Latitude, place.Longitude, after.Latitude, after.Longitude);
            if (after is not null && starts + TimeSpan.FromMinutes(candidate.Duration + (nextTravel?.Minutes ?? 0)) > after.StartTime)
                continue;
            var changeInCost = cost + (travel?.GroupCost ?? 0) + (nextTravel?.GroupCost ?? 0) -
                target.Item.Cost - target.Item.TravelCost - (after?.TravelCost ?? 0);
            if (changeInCost > result.BudgetRemaining) continue;

            target.Day.Items[index] = ToItem(candidate, starts, travel, cost, false);
            if (after is not null)
                SetTravel(after, nextTravel);
            Recalculate(p, result);
            decimal saved = target.Item.Cost - cost;
            var change = saved > 0 ? $" Estimated savings AED {saved:N0}." :
                saved < 0 ? $" The estimate rises by AED {-saved:N0} and remains within budget." : " The estimated total stays the same.";
            return new($"Replaced {target.Item.Name} with {place.Name} on day {target.Day.DayNumber}.{change}", true);
        }
        return new($"I found no replacement for {target.Item.Name} that fits the schedule, travel buffers and available budget.", false);
    }

    private static void SetTravel(PlannedItemVm item, EstimatedTravelLeg? leg)
    {
        item.TravelBufferMinutes = leg?.Minutes ?? 0;
        item.TravelCost = leg?.GroupCost ?? 0;
        item.TravelDistanceKm = leg?.DistanceKm ?? 0;
        item.TravelMode = leg?.Mode.ToString() ?? "";
    }

    private static int MatchDay(string message)
    {
        var match = Regex.Match(message, @"\bday\s+(?<number>\d{1,3}|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen)\b");
        if (match.Success)
            return TripBrief.ParseQuantity(match.Groups["number"].Value);
        var ordinal = Regex.Match(message, @"\b(?<number>\d{1,3})(?:st|nd|rd|th)\s+day\b");
        return ordinal.Success ? TripBrief.ParseQuantity(ordinal.Groups["number"].Value) : 0;
    }
}
