using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using ArabianDestinationTourism.Data;
using ArabianDestinationTourism.Models.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace ArabianDestinationTourism.Services.Itinerary;

public sealed class OpenAiTripDesigner(HttpClient client, IConfiguration configuration, ApplicationDbContext db)
{
    public bool Available => !string.IsNullOrWhiteSpace(configuration["TripAssistant:ApiKey"]);

    public async Task<string[]> ChoosePlacesAsync(string brief, PlannerVm preferences, CancellationToken cancellationToken)
    {
        if (!Available) return [];
        var attractions = await db.Attractions.AsNoTracking().Where(x => x.Status == Models.Entities.RecordStatus.Published)
            .Select(x => new { x.Name, x.ShortDescription, x.Price }).ToListAsync(cancellationToken);
        var activities = await db.Activities.AsNoTracking().Where(x => x.Status == Models.Entities.RecordStatus.Published)
            .Select(x => new { x.Name, x.ShortDescription, x.Price }).ToListAsync(cancellationToken);
        var choices = attractions.Select(x => $"{x.Name} — {x.ShortDescription} — estimated AED {x.Price} per person")
            .Concat(activities.Select(x => $"{x.Name} — {x.ShortDescription} — estimated AED {x.Price} per person"));
        var known = attractions.Select(x => x.Name).Concat(activities.Select(x => x.Name))
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
        var input = $"Traveller request: {brief}\nParty: {preferences.PartySize}; days: {preferences.Days}; total AED budget: {preferences.TotalBudget}; interests: {preferences.Interests}.\nAvailable places:\n{string.Join("\n", choices)}";
        var payload = new
        {
            model = configuration["TripAssistant:Model"] ?? "gpt-4.1-mini",
            instructions = "Select up to four specific available places that best fit the traveller's words and budget. " +
                "Use exact catalogue names only. Do not add names the traveller excluded. Return only JSON with a places array. " +
                "The application will check hours, travel time, room counts and total budget before scheduling.",
            input, store = false, max_output_tokens = 220,
            text = new { format = new { type = "json_schema", name = "trip_choices", strict = true,
                schema = new { type = "object", properties = new { places = new { type = "array", items = new { type = "string" } } },
                    required = new[] { "places" }, additionalProperties = false } } }
        };
        using var request = new HttpRequestMessage(HttpMethod.Post, "responses") { Content = JsonContent.Create(payload) };
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", configuration["TripAssistant:ApiKey"]);
        using var response = await client.SendAsync(request, cancellationToken);
        if (!response.IsSuccessStatusCode) return [];
        using var document = await response.Content.ReadFromJsonAsync<JsonDocument>(cancellationToken: cancellationToken);
        if (document is null || !document.RootElement.TryGetProperty("output", out var output)) return [];
        foreach (var item in output.EnumerateArray())
            if (item.TryGetProperty("content", out var content))
                foreach (var part in content.EnumerateArray())
                    if (part.TryGetProperty("type", out var type) && type.GetString() == "output_text" &&
                        part.TryGetProperty("text", out var text))
                    {
                        using var selected = JsonDocument.Parse(text.GetString() ?? "{}");
                        return selected.RootElement.GetProperty("places").EnumerateArray()
                            .Select(place => place.GetString()).OfType<string>().Where(known.Contains)
                            .Distinct(StringComparer.OrdinalIgnoreCase).Take(4).ToArray();
                    }
        return [];
    }
}
