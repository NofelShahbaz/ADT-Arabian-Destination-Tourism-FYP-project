using ArabianDestinationTourism.Data;
using ArabianDestinationTourism.Models.Entities;
using ArabianDestinationTourism.Models.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace ArabianDestinationTourism.Services.Itinerary;

public partial class ItineraryPlannerService
{
    private static readonly TimeSpan DayStart = TimeSpan.FromHours(9);
    private static readonly TimeSpan DayEnd = TimeSpan.FromHours(22);
    private static readonly TimeSpan Afternoon = TimeSpan.FromHours(13);
    private static readonly TimeSpan MealBreakStart = new(12, 30, 0);
    private static readonly TimeSpan MealBreakEnd = new(13, 15, 0);

    private sealed record Candidate(RecommendationResult Place, TimeSpan Opens, TimeSpan Closes,
        string HoursNote, bool Indoors, VenueSchedulePolicy Schedule)
    {
        public int Duration => Math.Clamp(Place.VisitMinutes, 30, 420);
    }

    private async Task<List<Candidate>> GetCandidatesAsync(PlannerVm preferences)
    {
        var recommendations = await recommender.RecommendAsync(preferences);
        var hours = await db.Attractions.AsNoTracking().Where(x => x.Status == RecordStatus.Published && x.Currency == "AED")
            .Select(x => new { x.Id, x.OpeningTime, x.ClosingTime }).ToDictionaryAsync(x => x.Id);
        var activities = (await db.Activities.AsNoTracking().Where(x => x.Status == RecordStatus.Published && x.Currency == "AED")
            .Select(x => x.Id).ToListAsync()).ToHashSet();
        var candidates = new List<Candidate>();
        foreach (var place in recommendations.Attractions.Concat(recommendations.Activities))
        {
            var profile = PlaceEditorial.For(place.ItemType, place.Name);
            var policy = VenueScheduleCatalogue.For(place.ItemType, place.Name);
            if (profile.PriceOnRequest || place.Price < 0 || !double.IsFinite(place.Latitude) || !double.IsFinite(place.Longitude) ||
                place.Latitude is < -90 or > 90 || place.Longitude is < -180 or > 180)
                continue;
            if (policy.Status is "UnconfirmedUnavailable" or "OutsidePlanningHours")
                continue;
            var opens = DayStart;
            var closes = DayEnd;
            if (place.ItemType == "Attraction")
            {
                if (!hours.TryGetValue(place.ItemId, out var window))
                    continue;
                opens = opens > window.OpeningTime ? opens : window.OpeningTime;
                closes = closes < window.ClosingTime ? closes : window.ClosingTime;
            }
            else if (!activities.Contains(place.ItemId))
                continue;
            if (policy.EarliestStart is TimeSpan policyOpen && policyOpen > opens) opens = policyOpen;
            if (policy.LatestEnd is TimeSpan policyClose && policyClose < closes) closes = policyClose;
            if (profile.PlanFrom is TimeSpan firstStart && firstStart > opens) opens = firstStart;
            if (profile.PlanUntil is TimeSpan lastFinish && lastFinish < closes) closes = lastFinish;
            if (profile.Area is not null && !profile.CanSchedule) continue;
            if (closes <= opens) continue;
            candidates.Add(new Candidate(place, opens, closes,
                $"Proposed time · official hours are unverified for your date. {policy.Note ?? profile.Hours}",
                policy.Indoors || profile.Tags.Contains("indoor", StringComparer.OrdinalIgnoreCase), policy));
        }

        return candidates.OrderByDescending(x => x.Place.Scores.Final)
            .ThenBy(x => x.Place.Price).ThenBy(x => x.Place.Name, StringComparer.OrdinalIgnoreCase).ToList();
    }

    private static bool Fits(PlannerVm p, Candidate candidate, DateTime date, TimeSpan starts)
    {
        var ends = starts + TimeSpan.FromMinutes(candidate.Duration);
        var limit = DayStart + TimeSpan.FromHours(p.DailyAvailableHours);
        if (candidate.Schedule.IsUnavailableOn(date)) return false;
        var opens = candidate.Opens;
        var closes = candidate.Closes;
        if (candidate.Schedule.WeeklyHours.Count > 0)
        {
            if (!candidate.Schedule.TryHours(date, out var weeklyOpen, out var weeklyClose)) return false;
            if (weeklyOpen > opens) opens = weeklyOpen;
            if (weeklyClose < closes) closes = weeklyClose;
        }
        if (candidate.Schedule.SessionStarts.Count > 0 &&
            !candidate.Schedule.SessionStarts.Contains(starts)) return false;
        return starts >= opens && ends <= closes && ends <= limit &&
            !(starts < MealBreakEnd && ends > MealBreakStart) &&
            (!p.IndoorAfternoons || ends <= Afternoon || candidate.Indoors);
    }

    private static TimeSpan MoveAfterMealBreak(TimeSpan start, int durationMinutes) =>
        start < MealBreakEnd && start + TimeSpan.FromMinutes(durationMinutes) > MealBreakStart
            ? MealBreakEnd : start;

    private static EstimatedTravelLeg EstimateLeg(PlannerVm preferences, PlanObjective objective,
        double fromLat, double fromLng, double toLat, double toLng) =>
        EstimatedTravel.Between(fromLat, fromLng, toLat, toLng, preferences.PartySize,
            preferences.TransportPreference, objective, preferences.LimitedWalking);

    private static int TravelMinutes(double fromLat, double fromLng, double toLat, double toLng) =>
        EstimatedTravel.Between(fromLat, fromLng, toLat, toLng, 1,
            TransportPreference.Balanced, PlanObjective.BestExperience, false).Minutes;

    private static bool IsIndoor(string type, string name) =>
        VenueScheduleCatalogue.For(type, name).Indoors ||
        PlaceEditorial.For(type, name).Tags.Contains("indoor", StringComparer.OrdinalIgnoreCase);

    private static PlannedItemVm ToItem(Candidate candidate, TimeSpan starts, EstimatedTravelLeg? travel,
        decimal cost, bool pinned) => new()
    {
        ItemType = candidate.Place.ItemType,
        ItemId = candidate.Place.ItemId,
        Name = candidate.Place.Name,
        StartTime = starts,
        DurationMinutes = candidate.Duration,
        TravelBufferMinutes = travel?.Minutes ?? 0,
        TravelCost = travel?.GroupCost ?? 0,
        TravelDistanceKm = travel?.DistanceKm ?? 0,
        TravelMode = travel?.Mode.ToString() ?? "",
        Cost = cost,
        Reason = candidate.Place.Reason,
        Latitude = candidate.Place.Latitude,
        Longitude = candidate.Place.Longitude,
        HoursNote = candidate.HoursNote,
        IsPinned = pinned,
        MatchScore = candidate.Place.Scores.Final
    };

    private static void Recalculate(PlannerVm preferences, ItineraryResultVm result)
    {
        var items = result.Days.SelectMany(x => x.Items);
        result.AttractionCost = items.Where(x => x.ItemType == "Attraction").Sum(x => x.Cost);
        result.ActivityCost = items.Where(x => x.ItemType == "Activity").Sum(x => x.Cost);
        result.TransportCost = TransportPerPersonPerDay * preferences.PartySize * preferences.Days +
            items.Sum(x => x.TravelCost);
        result.TotalEstimatedCost = result.HotelCost + result.MealCost + result.TransportCost + result.AttractionCost + result.ActivityCost;
        result.BudgetRemaining = preferences.TotalBudget - result.TotalEstimatedCost - result.EmergencyReserve;
        result.IsFeasible = result.BudgetRemaining >= 0 && result.Days.Count == preferences.Days &&
            result.Days.All(x => x.Items.Count > 0) &&
            (result.AccommodationNights == 0 || result.HotelId.HasValue);
    }
}
