using ArabianDestinationTourism.Data;
using ArabianDestinationTourism.Models.Entities;
using ArabianDestinationTourism.Models.ViewModels;
using ArabianDestinationTourism.Services.Interfaces;
using ArabianDestinationTourism.Services.Itinerary;
using ArabianDestinationTourism.Services.Pricing;
using Microsoft.EntityFrameworkCore;

namespace ArabianDestinationTourism.Services.Recommendation;

/// <summary>
/// Deterministic and explainable content matching. Results are prototype recommendations,
/// not live travel offers. All expenses and limits are in AED.
/// </summary>
public class RecommendationService(ApplicationDbContext db) : IRecommendationService
{
    public async Task<RecommendationPageVm> RecommendAsync(PlannerVm p)
    {
        var attractions = await db.Attractions.AsNoTracking().Include(x => x.Destination)
            .Where(x => x.Status == RecordStatus.Published).ToListAsync();
        var activities = await db.Activities.AsNoTracking().Include(x => x.Destination)
            .Where(x => x.Status == RecordStatus.Published).ToListAsync();
        var hotels = await db.Hotels.AsNoTracking().Include(x => x.Destination)
            .Where(x => x.Status == RecordStatus.Published).ToListAsync();

        var excluded = Split(p.ExcludedPlaces);
        var interests = Split(p.Interests);
        int days = Math.Clamp(p.Days, 1, 14);
        int party = Math.Clamp(p.PartySize, 1, 20);
        int nights = Math.Max(1, days - 1);
        decimal essential = (ItineraryPlannerService.MealsPerPersonPerDay +
            ItineraryPlannerService.TransportPerPersonPerDay) * party * days + p.EmergencyReserve;
        decimal usable = Math.Max(0m, p.TotalBudget - essential);
        // Ticket prices are per traveller; accommodation is per room/night.
        decimal activityDailyPerPerson = Math.Max(1m, usable / days / party);
        decimal hotelNightAllowance = Math.Max(1m, usable * .6m / nights);
        bool Compatible(TourismItem x) =>
            !excluded.Contains(x.Name.ToLowerInvariant()) &&
            (!p.ChildFriendly || x.FamilyFriendly) &&
            (!p.AccessibilityFriendly || x.AccessibilityFriendly) &&
            (!p.LimitedWalking || !Split(x.TagsCsv).Overlaps(["walking", "hiking"]));

        return new RecommendationPageVm
        {
            Attractions = attractions.Where(x => Compatible(x) &&
                !VenueScheduleCatalogue.For("Attraction", x.Name).IsUnavailableOn(p.StartDate.Date))
                .Select(x => Score("Attraction", x, x.AverageVisitMinutes,
                    interests, activityDailyPerPerson, p.PreferredLocation, p.PreferredHotelStars))
                .OrderByDescending(x => x.Scores.Final).ThenBy(x => x.Price).ToList(),
            Activities = activities.Where(x => Compatible(x) &&
                !VenueScheduleCatalogue.For("Activity", x.Name).IsUnavailableOn(p.StartDate.Date))
                .Select(x => Score("Activity", x, x.DurationMinutes,
                    interests, activityDailyPerPerson, p.PreferredLocation, p.PreferredHotelStars))
                .OrderByDescending(x => x.Scores.Final).ThenBy(x => x.Price).ToList(),
            Hotels = hotels.Where(Compatible)
                .Select(x => Score("Hotel", x, 120, interests,
                    hotelNightAllowance, p.PreferredLocation, p.PreferredHotelStars, HotelRoomRates.Quote(x, party, nights)))
                .OrderByDescending(x => x.Scores.Final).ThenBy(x => x.Price).ToList()
        };
    }

    private static RecommendationResult Score(
        string type, TourismItem item, int visitMinutes, HashSet<string> interests,
        decimal budgetAllowance, string? preferredLocation, int preferredStars, HotelRoomQuote? quote = null)
    {
        var tags = Split(item.TagsCsv);
        var matchedTags = interests.Intersect(tags).ToList();
        double interest = interests.Count == 0 ? .65 :
            Math.Clamp(.3 + .7 * matchedTags.Count / (double)interests.Count, 0, 1);
        var profile = PlaceEditorial.For(type, item.Name);
        var onRequest = profile.PriceOnRequest;
        decimal? rate = item is Hotel ? quote?.NightlyTotal : onRequest ? null : item.Price;
        decimal ratio = budgetAllowance > 0 && rate.HasValue ? rate.Value / budgetAllowance : 10;
        double budget = ratio <= 1 ? Math.Clamp(1.0 - (double)ratio * .35, .65, 1) :
            Math.Clamp(1.0 - ((double)ratio - 1) * .65, 0, .65);
        // Hotels have a stay-category preference instead of a sightseeing-duration score.
        double time = type == "Hotel" && item is Hotel hotel
            ? Math.Clamp(1.0 - Math.Abs(hotel.StarRating - preferredStars) * .18, 0, 1)
            : Math.Clamp(1 - Math.Abs(visitMinutes - 150) / 720.0, .25, 1);
        double rating = Math.Clamp(item.Rating / 5, 0, 1);
        double proximity = string.IsNullOrWhiteSpace(preferredLocation) ? .75 :
            item.Destination?.Name.Contains(preferredLocation, StringComparison.OrdinalIgnoreCase) == true ? 1 : .5;
        double popularity = Math.Clamp(item.PopularityScore, 0, 1);
        var breakdown = new ScoreBreakdown(interest, budget, time, rating, proximity, popularity);

        var reasons = new List<string>();
        if (matchedTags.Count > 0)
            reasons.Add($"You’re interested in {string.Join(" and ", matchedTags.Take(2).Select(tag => tag.Replace('-', ' ')))}.");
        if (proximity == 1 && !string.IsNullOrWhiteSpace(preferredLocation))
            reasons.Add($"It’s in your preferred area, {item.Destination?.Name}.");
        if (item is Hotel stay)
        {
            if (stay.StarRating > 0) reasons.Add(stay.StarRating == preferredStars
                ? $"It matches your {preferredStars}-star preference."
                : $"It’s a {stay.StarRating}-star alternative to your preferred {preferredStars} stars.");
        }
        else
            reasons.Add($"Allow about {visitMinutes} minutes for the visit.");

        if (item is Hotel)
            reasons.Add(quote is null
                ? "Check the hotel’s official booking page for rooms and rates for your group."
                : $"Your group is estimated to need {quote.RoomCount} room(s), at AED {quote.NightlyTotal:N0} per night in total. " +
                    (ratio <= 1 ? "That fits the group’s estimated accommodation allowance." : "That is above the group’s estimated accommodation allowance."));
        else
            reasons.Add(onRequest ? "Check the provider’s site for a price for your dates."
                : item.Price == 0 ? "The catalogue lists entry as free."
                : profile.PriceUnit is { } unit ? $"Estimated AED {item.Price:0.##} {unit}. Compare eligible tickets on the provider’s site."
                : ratio <= 1 ? $"At about AED {item.Price:0.##} per traveller, it fits the estimated allowance."
                : $"At about AED {item.Price:0.##} per traveller, it’s above the estimated allowance.");
        string explanation = string.Join(" ", reasons);

        return new RecommendationResult(
            type, item.Id, item.Name, item.Price,
            item.Latitude, item.Longitude, breakdown, explanation,
            item.ImageUrl, item.Destination?.Name ?? "Dubai",
            item.Rating, visitMinutes, item.FamilyFriendly, quote, rate is null);
    }

    private static HashSet<string> Split(string? value) =>
        new((value ?? "").Split(',',
            StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Select(x => x.ToLowerInvariant()));
}
