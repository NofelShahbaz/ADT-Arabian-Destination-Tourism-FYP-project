using ArabianDestinationTourism.Data;
using ArabianDestinationTourism.Models.Entities;
using ArabianDestinationTourism.Services.Interfaces;
using Microsoft.EntityFrameworkCore;
namespace ArabianDestinationTourism.Services;
public class FavoriteService(ApplicationDbContext db):IFavoriteService{
 public async Task<bool> ToggleAsync(string userId,string itemType,int itemId){var x=await db.Favorites.FirstOrDefaultAsync(f=>f.UserId==userId&&f.ItemType==itemType&&f.ItemId==itemId);if(x!=null){db.Remove(x);await db.SaveChangesAsync();return false;}db.Add(new Favorite{UserId=userId,ItemType=itemType,ItemId=itemId});await db.SaveChangesAsync();return true;}
 public Task<List<Favorite>> GetAsync(string userId)=>db.Favorites.Where(x=>x.UserId==userId).ToListAsync();
}
public class ReviewService(ApplicationDbContext db):IReviewService{
 public async Task AddAsync(string userId,string itemType,int itemId,int rating,string comment){db.Reviews.Add(new Review{UserId=userId,ItemType=itemType,ItemId=itemId,Rating=Math.Clamp(rating,1,5),Comment=comment,IsApproved=false});await db.SaveChangesAsync();}
}
public class AuditService(ApplicationDbContext db):IAuditService{
 public async Task LogAsync(string? userId,string action,string entityType,string details){db.AuditLogs.Add(new AuditLog{UserId=userId,Action=action,EntityType=entityType,Details=details});await db.SaveChangesAsync();}
}
