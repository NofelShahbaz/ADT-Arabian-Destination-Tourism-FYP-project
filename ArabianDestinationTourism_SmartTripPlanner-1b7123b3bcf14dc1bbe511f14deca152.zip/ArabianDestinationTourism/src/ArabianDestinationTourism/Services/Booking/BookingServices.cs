using ArabianDestinationTourism.Data;
using ArabianDestinationTourism.Models.Entities;
using ArabianDestinationTourism.Models.ViewModels;
using ArabianDestinationTourism.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace ArabianDestinationTourism.Services.BookingServices;

public class BookingService(ApplicationDbContext db, ICatalogueService catalogue) : IBookingService
{
    public async Task<TourismItem?> FindListingAsync(string? category, int id) => category switch
    {
        "Hotel" => await catalogue.GetHotelAsync(id),
        "Activity" => await catalogue.GetActivityAsync(id),
        _ => null
    };

    public Task<Booking?> FindAsync(string userId, int id) =>
        db.Bookings.Include(booking => booking.Payment)
            .FirstOrDefaultAsync(booking => booking.Id == id && booking.UserId == userId);

    public async Task<Booking> CreateAsync(string userId, BookingCreateVm request)
    {
        var listing = await FindListingAsync(request.ServiceType, request.ServiceId);
        if (listing is null || listing.Price < 0)
            throw new InvalidOperationException("This listing is no longer available.");
        if (request.Guests is < 1 or > 20 || request.BookingDate.Date < DateTime.UtcNow.AddHours(4).Date)
            throw new InvalidOperationException("Choose a current or future Dubai date and between 1 and 20 travellers.");

        // The sandbox hotel booking represents one night and assumes two travellers per room.
        int quantity = listing is Hotel ? (request.Guests + 1) / 2 : request.Guests;
        var booking = new Booking
        {
            UserId = userId,
            ServiceType = request.ServiceType,
            ServiceId = listing.Id,
            BookingDate = request.BookingDate.Date,
            Guests = request.Guests,
            Amount = listing.Price * quantity,
            Status = BookingStatus.Pending
        };
        db.Bookings.Add(booking);
        await db.SaveChangesAsync();
        return booking;
    }

    public async Task CancelAsync(string userId, int id)
    {
        var booking = await FindAsync(userId, id) ?? throw new KeyNotFoundException();
        booking.Status = BookingStatus.Cancelled;
        booking.UpdatedAt = DateTime.UtcNow;
        await db.SaveChangesAsync();
    }

    public Task<List<Booking>> HistoryAsync(string userId) =>
        db.Bookings.Include(booking => booking.Payment).Where(booking => booking.UserId == userId)
            .OrderByDescending(booking => booking.CreatedAt).ToListAsync();
}

public class PaymentSimulationService(ApplicationDbContext db) : IPaymentService
{
    public async Task<Payment> SimulateAsync(string userId, int bookingId, string outcome)
    {
        var booking = await db.Bookings.Include(item => item.Payment)
            .FirstOrDefaultAsync(item => item.Id == bookingId && item.UserId == userId) ?? throw new KeyNotFoundException();
        if (booking.Status == BookingStatus.Cancelled)
            throw new InvalidOperationException("Cancelled bookings cannot be paid.");
        if (booking.Payment is { Status: PaymentStatus.Successful } completed)
            return completed;

        var status = outcome?.ToLowerInvariant() switch
        {
            "success" => PaymentStatus.Successful,
            "failed" => PaymentStatus.Failed,
            "pending" => PaymentStatus.Pending,
            _ => throw new ArgumentOutOfRangeException(nameof(outcome))
        };
        var payment = booking.Payment ?? new Payment
        {
            BookingId = booking.Id,
            TransactionId = "ADT-" + Guid.NewGuid().ToString("N")[..12].ToUpperInvariant(),
            Amount = booking.Amount,
            PaymentMethodLabel = "Sandbox test"
        };
        payment.Status = status;
        payment.UpdatedAt = DateTime.UtcNow;
        booking.Status = status switch
        {
            PaymentStatus.Successful => BookingStatus.Confirmed,
            PaymentStatus.Failed => BookingStatus.Failed,
            _ => BookingStatus.Pending
        };
        booking.UpdatedAt = DateTime.UtcNow;
        if (booking.Payment is null) db.Payments.Add(payment);
        await db.SaveChangesAsync();
        return payment;
    }
}
