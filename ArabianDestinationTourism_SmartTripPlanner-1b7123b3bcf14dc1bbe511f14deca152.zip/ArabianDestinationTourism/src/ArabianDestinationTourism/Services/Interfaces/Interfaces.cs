using ArabianDestinationTourism.Models.Entities;
using ArabianDestinationTourism.Models.ViewModels;

namespace ArabianDestinationTourism.Services.Interfaces;

public interface ICatalogueService
{
    Task<List<Attraction>> GetAttractionsAsync(string? q=null,string? area=null,string? tag=null);
    Task<List<Activity>> GetActivitiesAsync(string? q=null,string? area=null,string? tag=null);
    Task<List<Hotel>> GetHotelsAsync(string? q=null,string? area=null,int? stars=null);
    Task<Attraction?> GetAttractionAsync(int id);
    Task<Activity?> GetActivityAsync(int id);
    Task<Hotel?> GetHotelAsync(int id);
}
public interface IRecommendationService { Task<RecommendationPageVm> RecommendAsync(PlannerVm p); }
public interface IItineraryPlannerService
{
    Task<ItineraryResultVm> GenerateAsync(PlannerVm preferences);
    Task<IReadOnlyList<PlanVariantVm>> GenerateVariantsAsync(PlannerVm preferences);
    Task<ItineraryResultVm> GenerateForObjectiveAsync(PlannerVm preferences, PlanObjective objective);
    Task<TripPlan> SaveAsync(string userId, PlannerVm preferences, ItineraryResultVm result);
    Task<ItineraryEditResult> EditAsync(PlannerVm preferences, ItineraryResultVm result, string operation,
        int dayNumber, string? itemType, int itemId, string? message);
}
public interface IBookingService
{
    Task<TourismItem?> FindListingAsync(string? category, int id);
    Task<Models.Entities.Booking?> FindAsync(string userId, int id);
    Task<Models.Entities.Booking> CreateAsync(string userId, BookingCreateVm request);
    Task CancelAsync(string userId, int id);
    Task<List<Models.Entities.Booking>> HistoryAsync(string userId);
}
public interface IPaymentService { Task<Payment> SimulateAsync(string userId,int bookingId,string outcome); }
public interface IFavoriteService { Task<bool> ToggleAsync(string userId,string itemType,int itemId); Task<List<Favorite>> GetAsync(string userId); }
public interface IReviewService { Task AddAsync(string userId,string itemType,int itemId,int rating,string comment); }
public interface IAuditService { Task LogAsync(string? userId,string action,string entityType,string details); }
