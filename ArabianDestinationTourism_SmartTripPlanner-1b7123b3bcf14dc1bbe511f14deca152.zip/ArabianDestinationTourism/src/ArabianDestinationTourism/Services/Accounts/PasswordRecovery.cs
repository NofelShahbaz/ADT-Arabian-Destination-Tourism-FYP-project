using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Channels;
using ArabianDestinationTourism.Models.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.WebUtilities;

namespace ArabianDestinationTourism.Services.Accounts;

public sealed class PasswordRecovery(
    IServiceScopeFactory scopes, IConfiguration configuration, IWebHostEnvironment environment,
    ILogger<PasswordRecovery> logger) : BackgroundService
{
    private readonly Channel<string> requests = Channel.CreateBounded<string>(new BoundedChannelOptions(64)
    {
        SingleReader = true,
        FullMode = BoundedChannelFullMode.Wait
    });

    public bool IsConfigured => PublicOrigin() is not null &&
        !string.IsNullOrWhiteSpace(configuration["Mail:Host"]) &&
        MailAddress.TryCreate(configuration["Mail:From"], out _) &&
        (!string.IsNullOrWhiteSpace(configuration["Mail:User"]) ==
            !string.IsNullOrWhiteSpace(configuration["Mail:Password"]));

    public bool Queue(string address) => IsConfigured && requests.Writer.TryWrite(address);

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        await foreach (var address in requests.Reader.ReadAllAsync(stoppingToken))
        {
            try { await SendAsync(address, stoppingToken); }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested) { break; }
            catch (Exception error)
            {
                logger.LogWarning("Password recovery delivery failed ({ErrorType}). Check mail settings and connectivity.",
                    error.GetType().Name);
            }
        }
    }

    private async Task SendAsync(string address, CancellationToken cancellationToken)
    {
        using var scope = scopes.CreateScope();
        var users = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
        var user = await users.FindByEmailAsync(address);
        if (user?.Email is not { } recipient || PublicOrigin() is not { } origin) return;

        var code = await users.GeneratePasswordResetTokenAsync(user);
        var link = QueryHelpers.AddQueryString(new Uri(origin, "/Account/ResetPassword").AbsoluteUri,
            new Dictionary<string, string?>
            {
                ["userId"] = user.Id,
                ["code"] = WebEncoders.Base64UrlEncode(Encoding.UTF8.GetBytes(code))
            });

        using var message = new MailMessage(configuration["Mail:From"]!, recipient)
        {
            Subject = "Reset your Arabian Destination Tourism password",
            Body = $"Use this link within one hour to choose a new password:\n\n{link}\n\nIf you did not request this, you can ignore this email."
        };
        using var client = new SmtpClient(configuration["Mail:Host"]!, configuration.GetValue("Mail:Port", 587))
        {
            EnableSsl = !environment.IsDevelopment() || configuration.GetValue("Mail:StartTls", true),
            UseDefaultCredentials = false
        };
        if (configuration["Mail:User"] is { Length: > 0 } username)
            client.Credentials = new NetworkCredential(username, configuration["Mail:Password"]);
        using var deadline = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        deadline.CancelAfter(TimeSpan.FromSeconds(20));
        await client.SendMailAsync(message, deadline.Token);
    }

    private Uri? PublicOrigin()
    {
        var value = configuration["Deployment:PublicBaseUrl"];
        if (string.IsNullOrWhiteSpace(value) && environment.IsDevelopment()) value = "https://localhost:7148";
        return Uri.TryCreate(value, UriKind.Absolute, out var uri) && string.IsNullOrEmpty(uri.UserInfo) &&
            uri.Scheme == Uri.UriSchemeHttps && uri.AbsolutePath == "/" &&
            string.IsNullOrEmpty(uri.Query) && string.IsNullOrEmpty(uri.Fragment) ? uri : null;
    }
}
