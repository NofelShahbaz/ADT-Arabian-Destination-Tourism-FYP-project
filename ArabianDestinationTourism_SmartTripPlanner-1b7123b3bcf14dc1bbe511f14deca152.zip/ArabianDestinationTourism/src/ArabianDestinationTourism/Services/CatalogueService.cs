using ArabianDestinationTourism.Data;
using ArabianDestinationTourism.Models.Entities;
using ArabianDestinationTourism.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace ArabianDestinationTourism.Services;
public class CatalogueService(ApplicationDbContext db) : ICatalogueService
{
    public async Task<List<Attraction>> GetAttractionsAsync(string? q=null,string? area=null,string? tag=null)
    {
        var x=db.Attractions.Include(a=>a.Destination).Where(a=>a.Status==RecordStatus.Published).AsQueryable();
        if(!string.IsNullOrWhiteSpace(q)) x=x.Where(a=>a.Name.Contains(q)||a.Description.Contains(q));
        if(!string.IsNullOrWhiteSpace(area)) x=x.Where(a=>a.Destination!.Name.Contains(area));
        if(!string.IsNullOrWhiteSpace(tag)) x=x.Where(a=>a.TagsCsv.Contains(tag));
        return await x.OrderByDescending(a=>a.PopularityScore).ToListAsync();
    }
    public async Task<List<Activity>> GetActivitiesAsync(string? q=null,string? area=null,string? tag=null)
    {
        var x=db.Activities.Include(a=>a.Destination).Where(a=>a.Status==RecordStatus.Published).AsQueryable();
        if(!string.IsNullOrWhiteSpace(q)) x=x.Where(a=>a.Name.Contains(q)||a.Description.Contains(q));
        if(!string.IsNullOrWhiteSpace(area)) x=x.Where(a=>a.Destination!.Name.Contains(area));
        if(!string.IsNullOrWhiteSpace(tag)) x=x.Where(a=>a.TagsCsv.Contains(tag));
        return await x.OrderByDescending(a=>a.PopularityScore).ToListAsync();
    }
    public async Task<List<Hotel>> GetHotelsAsync(string? q=null,string? area=null,int? stars=null)
    {
        var x=db.Hotels.Include(a=>a.Destination).Where(a=>a.Status==RecordStatus.Published).AsQueryable();
        if(!string.IsNullOrWhiteSpace(q)) x=x.Where(a=>a.Name.Contains(q)||a.Description.Contains(q));
        if(!string.IsNullOrWhiteSpace(area)) x=x.Where(a=>a.Destination!.Name.Contains(area));
        if(stars.HasValue) x=x.Where(a=>a.StarRating==stars.Value);
        return await x.OrderByDescending(a=>a.Rating).ToListAsync();
    }
    public Task<Attraction?> GetAttractionAsync(int id)=>db.Attractions.Include(x=>x.Destination).FirstOrDefaultAsync(x=>x.Id==id && x.Status==RecordStatus.Published);
    public Task<Activity?> GetActivityAsync(int id)=>db.Activities.Include(x=>x.Destination).FirstOrDefaultAsync(x=>x.Id==id && x.Status==RecordStatus.Published);
    public Task<Hotel?> GetHotelAsync(int id)=>db.Hotels.Include(x=>x.Destination).FirstOrDefaultAsync(x=>x.Id==id && x.Status==RecordStatus.Published);
}
