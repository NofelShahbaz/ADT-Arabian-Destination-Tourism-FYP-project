using ArabianDestinationTourism.Models.Entities;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace ArabianDestinationTourism.Data;

public class ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
    : IdentityDbContext<ApplicationUser>(options)
{
    public DbSet<UserProfile> UserProfiles => Set<UserProfile>();
    public DbSet<Destination> Destinations => Set<Destination>();
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<InterestTag> InterestTags => Set<InterestTag>();
    public DbSet<Attraction> Attractions => Set<Attraction>();
    public DbSet<Activity> Activities => Set<Activity>();
    public DbSet<Hotel> Hotels => Set<Hotel>();
    public DbSet<Favorite> Favorites => Set<Favorite>();
    public DbSet<Review> Reviews => Set<Review>();
    public DbSet<PlannerPreference> PlannerPreferences => Set<PlannerPreference>();
    public DbSet<TripPlan> TripPlans => Set<TripPlan>();
    public DbSet<TripDay> TripDays => Set<TripDay>();
    public DbSet<TripItem> TripItems => Set<TripItem>();
    public DbSet<Booking> Bookings => Set<Booking>();
    public DbSet<Payment> Payments => Set<Payment>();
    public DbSet<ChatbotIntent> ChatbotIntents => Set<ChatbotIntent>();
    public DbSet<TrainingPhrase> TrainingPhrases => Set<TrainingPhrase>();
    public DbSet<KnowledgeItem> KnowledgeItems => Set<KnowledgeItem>();
    public DbSet<ChatSession> ChatSessions => Set<ChatSession>();
    public DbSet<ChatMessage> ChatMessages => Set<ChatMessage>();
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();
    public DbSet<ErrorLog> ErrorLogs => Set<ErrorLog>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        base.OnModelCreating(b);
        b.Entity<Destination>().HasIndex(x => x.Slug).IsUnique();
        b.Entity<Attraction>().HasIndex(x => x.Slug).IsUnique();
        b.Entity<Activity>().HasIndex(x => x.Slug).IsUnique();
        b.Entity<Hotel>().HasIndex(x => x.Slug).IsUnique();
        b.Entity<Favorite>().HasIndex(x => new { x.UserId, x.ItemType, x.ItemId }).IsUnique();
        b.Entity<Payment>().HasIndex(x => x.TransactionId).IsUnique();
        b.Entity<Booking>().HasOne(x => x.Payment).WithOne(x => x.Booking).HasForeignKey<Payment>(x => x.BookingId);
        b.Entity<UserProfile>().HasOne(x => x.User).WithOne(x => x.Profile).HasForeignKey<UserProfile>(x => x.UserId);
        b.Entity<TourismItem>().UseTpcMappingStrategy();
        b.Entity<Attraction>().Property(x => x.Price).HasPrecision(18,2);
        b.Entity<Activity>().Property(x => x.Price).HasPrecision(18,2);
        b.Entity<Hotel>().Property(x => x.Price).HasPrecision(18,2);
        b.Entity<Booking>().Property(x => x.Amount).HasPrecision(18,2);
        b.Entity<Payment>().Property(x => x.Amount).HasPrecision(18,2);
        b.Entity<TripPlan>().Property(x => x.TotalEstimatedCost).HasPrecision(18,2);
        b.Entity<TripPlan>().Property(x => x.Budget).HasPrecision(18,2);
        b.Entity<TripItem>().Property(x => x.EstimatedCost).HasPrecision(18,2);
        b.Entity<PlannerPreference>().Property(x => x.TotalBudget).HasPrecision(18,2);
    }
}
