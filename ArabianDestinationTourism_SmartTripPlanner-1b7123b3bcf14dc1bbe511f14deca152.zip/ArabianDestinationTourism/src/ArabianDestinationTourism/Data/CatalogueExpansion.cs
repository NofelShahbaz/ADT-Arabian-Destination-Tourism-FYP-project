using System.Text.RegularExpressions;
using ArabianDestinationTourism.Models.Entities;
using Microsoft.EntityFrameworkCore;

namespace ArabianDestinationTourism.Data;

public static class CatalogueExpansion
{
    public static async Task SeedAsync(ApplicationDbContext db)
    {
        var existing = new HashSet<(string Category, string Name)>();
        foreach (var name in await db.Attractions.Select(item => item.Name).ToListAsync())
            existing.Add(("Attraction", name.ToUpperInvariant()));
        foreach (var name in await db.Activities.Select(item => item.Name).ToListAsync())
            existing.Add(("Activity", name.ToUpperInvariant()));
        foreach (var name in await db.Hotels.Select(item => item.Name).ToListAsync())
            existing.Add(("Hotel", name.ToUpperInvariant()));

        var destinations = (await db.Destinations.ToListAsync())
            .ToDictionary(item => item.Slug, StringComparer.OrdinalIgnoreCase);
        foreach (var profile in PlaceEditorial.Additions)
        {
            if (existing.Contains((profile.Type, profile.Name.ToUpperInvariant())) ||
                profile.Latitude is not double latitude || profile.Longitude is not double longitude)
                continue;

            var area = profile.Area!;
            var slug = Slug(area);
            if (!destinations.TryGetValue(slug, out var destination))
            {
                destination = new Destination
                {
                    Name = area, Slug = slug, Description = $"Explore {area}.",
                    Latitude = latitude, Longitude = longitude
                };
                destinations.Add(slug, destination);
                db.Destinations.Add(destination);
            }

            TourismItem item = profile.Type switch
            {
                "Attraction" => new Attraction { AverageVisitMinutes = profile.DurationMinutes ?? 90 },
                "Activity" => new Activity { DurationMinutes = profile.DurationMinutes ?? 90 },
                "Hotel" => new Hotel { StarRating = profile.StarRating ?? 0 },
                _ => throw new InvalidOperationException($"Unknown catalogue type {profile.Type}.")
            };
            item.Name = profile.Name;
            item.Slug = Slug(profile.Name);
            item.ShortDescription = profile.Intro;
            item.Description = $"{profile.Intro}\n\n{profile.Story}\n\n{profile.WhatToDo}";
            item.Destination = destination;
            item.Latitude = latitude;
            item.Longitude = longitude;
            item.Currency = "AED";
            item.Price = profile.Price ?? 0;
            item.FamilyFriendly = profile.FamilyFriendly;
            item.TagsCsv = string.Join(',', profile.Tags);
            item.Status = RecordStatus.Published;
            db.Add(item);
        }
        if (db.ChangeTracker.HasChanges()) await db.SaveChangesAsync();
    }

    private static string Slug(string value) => Regex.Replace(value.ToLowerInvariant(), "[^a-z0-9]+", "-").Trim('-');
}
