using System.Text.Json;

namespace ArabianDestinationTourism.Data;

public sealed class PlaceProfile
{
    public string Type { get; set; } = "";
    public string Name { get; set; } = "";
    public string Intro { get; set; } = "";
    public string Story { get; set; } = "";
    public string WhatToDo { get; set; } = "";
    public string VisitTips { get; set; } = "";
    public string Hours { get; set; } = "";
    public string Alert { get; set; } = "";
    public string OfficialUrl { get; set; } = "";
    public string? BookingUrl { get; set; }
    public string? Access { get; set; }
    public string? AccessSourceUrl { get; set; }
    public string? DetailsSourceUrl { get; set; }
    public string? PriceUnit { get; set; }
    public string? PriceNote { get; set; }
    public bool PriceOnRequest { get; set; }
    public List<string> VisitDetails { get; set; } = [];
    public string? Area { get; set; }
    public double? Latitude { get; set; }
    public double? Longitude { get; set; }
    public decimal? Price { get; set; }
    public bool CanSchedule { get; set; }
    public TimeSpan? PlanFrom { get; set; }
    public TimeSpan? PlanUntil { get; set; }
    public int? DurationMinutes { get; set; }
    public int? StarRating { get; set; }
    public List<string> Tags { get; set; } = [];
    public bool FamilyFriendly { get; set; }
    public string? DisplayName { get; set; }
    public List<PlacePhoto> Photos { get; set; } = [];
    public HotelRoomGuide? Rooms { get; set; }
}

public sealed record PlacePhoto(string Url, string Caption, string SourceUrl, string Credit, string? LicenseUrl = null);

public sealed record HotelRoomGuide(string SourceUrl, string ReviewedOn, string? Notes,
    IReadOnlyList<HotelRoomProfile> Options);

public sealed record HotelRoomProfile(string Name, string? Beds, string? Occupancy, string? Size,
    string? Features, string? SourceUrl, int? MaxGuests = null, int? MaxAdults = null,
    decimal? NightlyRate = null, string? RateNote = null);

public static class PlaceEditorial
{
    private static readonly Lazy<IReadOnlyDictionary<string, PlaceProfile>> Profiles = new(() =>
    {
        var assembly = typeof(PlaceEditorial).Assembly;
        using var stream = assembly.GetManifestResourceStream("ArabianDestinationTourism.Data.place-content.json")
            ?? throw new InvalidOperationException("The place catalogue resource was not included in the build.");
        var profiles = JsonSerializer.Deserialize<PlaceProfile[]>(stream)
            ?? throw new InvalidOperationException("The place catalogue could not be loaded.");
        return profiles.ToDictionary(
            x => Key(x.Type, x.Name),
            x => x,
            StringComparer.OrdinalIgnoreCase);
    });

    private static string Key(string type, string name) => $"{type.Trim()}|{name.Trim()}";

    public static PlaceProfile For(string type, string name)
    {
        if (Profiles.Value.TryGetValue(Key(type, name), out var profile))
            return profile;

        // New entries created by administrators can still be displayed without special editorial data.
        return new PlaceProfile
        {
            Type = type,
            Name = name,
            Intro = $"Discover {name} and plan a memorable visit.",
            Story = "Find out more about the place, facilities and surrounding area before travelling.",
            WhatToDo = "Explore the available experiences and compare the options that suit your trip.",
            VisitTips = "Confirm current opening information, accessibility, policies and prices directly with the operator.",
            Hours = "Schedules vary; confirm the latest information with the venue or operator."
        };
    }

    public static bool IsKnown(string type, string name) =>
        Profiles.Value.ContainsKey(Key(type, name));

    public static IEnumerable<PlaceProfile> Additions => Profiles.Value.Values.Where(profile => profile.Area is not null);

    public static Uri? OfficialUri(string? url) =>
        Uri.TryCreate(url, UriKind.Absolute, out var uri) && uri.Scheme == Uri.UriSchemeHttps &&
        string.IsNullOrEmpty(uri.UserInfo) && !uri.IsLoopback ? uri : null;

    public static string? CatalogueImage(string? imageUrl)
    {
        if (string.IsNullOrWhiteSpace(imageUrl) ||
            imageUrl.Contains("photo-1512453979798-5ea266f8880c", StringComparison.Ordinal) ||
            imageUrl.Contains("photo-1507525428034-b723cf961d3e", StringComparison.Ordinal) ||
            imageUrl.Contains("photo-1566073771259-6a8506099945", StringComparison.Ordinal) ||
            imageUrl.Contains("/images/venue-placeholder.svg", StringComparison.Ordinal))
            return null;

        return imageUrl;
    }
}
