using ArabianDestinationTourism.Models.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace ArabianDestinationTourism.Data;

public static class DbSeeder
{
    public static async Task SeedAsync(IServiceProvider sp)
    {
        var db=sp.GetRequiredService<ApplicationDbContext>();
        var roles=sp.GetRequiredService<RoleManager<IdentityRole>>();
        var users=sp.GetRequiredService<UserManager<ApplicationUser>>();
        foreach(var r in new[]{"Tourist","Admin"}) if(!await roles.RoleExistsAsync(r)) await roles.CreateAsync(new IdentityRole(r));
        // Never ship a predictable administrator password. For demos or deployment,
        // set AdminSeed__Email and AdminSeed__Password in the environment.
        var configuration = sp.GetRequiredService<IConfiguration>();
        string? adminEmail = configuration["AdminSeed:Email"];
        string? adminPassword = configuration["AdminSeed:Password"];
        if (!string.IsNullOrWhiteSpace(adminEmail) && !string.IsNullOrWhiteSpace(adminPassword))
        {
            var admin = await users.FindByEmailAsync(adminEmail);
            bool newAdministrator = admin is null;
            if (admin == null)
            {
                admin = new ApplicationUser {
                    UserName = adminEmail, Email = adminEmail,
                    FullName = "ADT Administrator", EmailConfirmed = true
                };
                var result = await users.CreateAsync(admin, adminPassword);
                if (!result.Succeeded)
                    throw new InvalidOperationException("Administrator seed credentials did not satisfy Identity password policies.");
            }
            if (!await users.IsInRoleAsync(admin, "Admin"))
            {
                if (!newAdministrator && !await users.CheckPasswordAsync(admin, adminPassword))
                    throw new InvalidOperationException("The configured administrator email belongs to an existing account. Set the seed password to that account's password to authorize promotion.");

                var membership = await users.AddToRoleAsync(admin, "Admin");
                if (!membership.Succeeded)
                    throw new InvalidOperationException("The configured administrator could not be assigned the Admin role.");
            }
        }
        if (await db.Destinations.AnyAsync())
        {
            await RefreshExistingCatalogueAsync(db);
            await CatalogueExpansion.SeedAsync(db);
            return;
        }

        var destinations=new[]{
            new Destination{Name="Downtown Dubai",Slug="downtown-dubai",Description="Iconic skyline, shopping and landmarks.",Latitude=25.1972,Longitude=55.2744},
            new Destination{Name="Dubai Marina",Slug="dubai-marina",Description="Waterfront towers, promenades and yacht experiences.",Latitude=25.0805,Longitude=55.1403},
            new Destination{Name="Palm Jumeirah",Slug="palm-jumeirah",Description="Luxury island destination with beaches and resorts.",Latitude=25.1124,Longitude=55.1390},
            new Destination{Name="Old Dubai / Al Fahidi",Slug="al-fahidi",Description="Heritage district, creek and traditional culture.",Latitude=25.2635,Longitude=55.3001},
            new Destination{Name="Dubai Desert",Slug="dubai-desert",Description="Dunes, desert camps and adventure experiences.",Latitude=24.9857,Longitude=55.6156},
            new Destination{Name="Jumeirah",Slug="jumeirah",Description="Beaches, mosques and upscale coastal attractions.",Latitude=25.2048,Longitude=55.2490}
        };
        db.Destinations.AddRange(destinations);await db.SaveChangesAsync();
        int D(string name)=>destinations.First(x=>x.Name==name).Id;
        var attractions=new List<Attraction>{
            A("Burj Khalifa","World-famous skyscraper and observation decks.","Downtown Dubai",169,4.8,.99,25.1972,55.2744,"landmarks,luxury,architecture",120),
            A("Dubai Mall","Mega mall with shopping, dining and entertainment.","Downtown Dubai",0,4.7,.98,25.1985,55.2796,"shopping,family,luxury",240),
            A("Dubai Fountain","Choreographed fountain spectacle.","Downtown Dubai",0,4.7,.96,25.1952,55.2751,"family,landmarks,night",60),
            A("Museum of the Future","Immersive museum exploring future technologies.","Downtown Dubai",149,4.6,.93,25.2192,55.2822,"culture,technology,family",150),
            A("Dubai Frame","Panoramic landmark framing old and new Dubai.","Downtown Dubai",50,4.6,.88,25.2355,55.3003,"landmarks,architecture,family",90),
            A("Palm Jumeirah Viewpoint","Panoramic view across Palm Jumeirah.","Palm Jumeirah",100,4.7,.86,25.1137,55.1388,"beach,landmarks,luxury",90),
            A("Atlantis Aquaventure","Major waterpark on Palm Jumeirah.","Palm Jumeirah",315,4.6,.93,25.1330,55.1203,"family,adventure,water",360),
            A("Dubai Marina Walk","Waterfront promenade with dining and views.","Dubai Marina",0,4.6,.85,25.0810,55.1416,"walking,food,waterfront",120),
            A("Ain Dubai Area","Bluewaters waterfront and skyline views.","Dubai Marina",0,4.5,.80,25.0796,55.1239,"landmarks,waterfront,family",90),
            A("Al Fahidi Historical Neighbourhood","Traditional lanes, wind towers and museums.","Old Dubai / Al Fahidi",0,4.6,.82,25.2635,55.3001,"culture,history,heritage",150),
            A("Dubai Museum Area","Historic fort district in Old Dubai.","Old Dubai / Al Fahidi",20,4.4,.75,25.2631,55.2972,"culture,history,family",90),
            A("Dubai Creek","Historic waterway connecting Deira and Bur Dubai.","Old Dubai / Al Fahidi",5,4.6,.87,25.2684,55.3072,"culture,waterfront,history",120),
            A("Jumeirah Mosque","Landmark mosque open to cultural visits.","Jumeirah",35,4.6,.79,25.2338,55.2657,"culture,architecture,heritage",90),
            A("Kite Beach","Popular public beach with views and sports.","Jumeirah",0,4.6,.84,25.1621,55.2084,"beach,family,sports",180),
            A("Madinat Jumeirah","Traditional-style resort complex and souk.","Jumeirah",0,4.7,.86,25.1336,55.1857,"shopping,luxury,culture",150),
            A("Global Village","Seasonal multicultural entertainment destination.","Dubai Desert",30,4.7,.94,25.0694,55.3063,"family,culture,food",240),
            A("Dubai Miracle Garden","Seasonal floral attraction.","Dubai Desert",100,4.6,.92,25.0600,55.2445,"nature,family,photography",180),
            A("Dubai Safari Park","Large wildlife park and safari experience.","Dubai Desert",50,4.5,.84,25.1772,55.4497,"family,nature,wildlife",300),
            A("The Green Planet","Indoor tropical biodome.","Downtown Dubai",155,4.5,.78,25.2075,55.2625,"nature,family,wildlife",120),
            A("Dubai Aquarium & Underwater Zoo","Large aquarium in Dubai Mall.","Downtown Dubai",199,4.6,.91,25.1976,55.2790,"family,water,wildlife",150),
            A("Etihad Museum","Museum focused on UAE history and union.","Jumeirah",25,4.6,.72,25.2350,55.2670,"culture,history,education",120),
            A("Dubai Opera","Performing arts venue in Downtown Dubai.","Downtown Dubai",250,4.7,.81,25.1909,55.2743,"culture,luxury,arts",180)
        };
        db.Attractions.AddRange(attractions);

        var activities=new List<Activity>{
            Ac("Desert Safari","Dune drive, camp experience and desert sunset.","Dubai Desert",250,4.8,.98,24.9857,55.6156,"adventure,desert,family",360),
            Ac("Dune Bashing","4x4 off-road dune experience.","Dubai Desert",180,4.7,.91,24.9980,55.6200,"adventure,desert",120),
            Ac("Camel Riding","Traditional camel ride in the desert.","Dubai Desert",80,4.5,.80,24.9900,55.6100,"culture,desert,family",60),
            Ac("Dubai Marina Yacht Tour","Shared yacht cruise around Dubai Marina.","Dubai Marina",220,4.7,.92,25.0840,55.1400,"luxury,waterfront,relaxation",180),
            Ac("Dhow Cruise Dinner","Evening traditional boat cruise with dinner.","Dubai Marina",150,4.6,.90,25.0810,55.1430,"family,food,waterfront",180),
            Ac("Jet Ski Experience","Guided jet ski session off the coast.","Jumeirah",280,4.7,.88,25.1460,55.1940,"adventure,water,sports",60),
            Ac("Tandem Skydiving","High-adrenaline skydive over the Palm area.","Dubai Marina",2400,4.9,.95,25.0880,55.1360,"adventure,luxury",180),
            Ac("Kayaking","Leisure kayaking on calm water.","Jumeirah",100,4.5,.70,25.1550,55.1950,"water,sports,family",90),
            Ac("Abra Ride","Traditional creek boat crossing.","Old Dubai / Al Fahidi",2,4.7,.89,25.2680,55.3080,"culture,budget,waterfront",30),
            Ac("Old Dubai Walking Tour","Guided heritage walk and souk exploration.","Old Dubai / Al Fahidi",120,4.7,.82,25.2640,55.3010,"culture,history,walking",180),
            Ac("Dubai Food Tour","Guided tasting experience across local neighborhoods.","Old Dubai / Al Fahidi",250,4.8,.84,25.2690,55.3050,"food,culture",180),
            Ac("Beach Paddleboarding","Stand-up paddleboarding session.","Jumeirah",120,4.5,.72,25.1600,55.2050,"water,sports,family",90),
            Ac("Luxury Spa Experience","Premium wellness and spa treatment.","Palm Jumeirah",450,4.8,.78,25.1150,55.1400,"luxury,wellness,relaxation",120),
            Ac("Marina Zipline","Urban zipline over Dubai Marina.","Dubai Marina",650,4.8,.86,25.0789,55.1376,"adventure,urban",90),
            Ac("Hot Air Balloon","Sunrise balloon flight over the desert.","Dubai Desert",1100,4.8,.90,24.9500,55.6000,"adventure,desert,luxury",240),
            Ac("Aquarium Tunnel Visit","Immersive aquarium and underwater zoo visit.","Downtown Dubai",199,4.6,.88,25.1976,55.2790,"family,water,wildlife",150)
        };
        db.Activities.AddRange(activities);

        var hotels=new List<Hotel>{
            H("Rove Downtown","Downtown Dubai",4,420,4.6,25.2010,55.2770,"wifi,pool,gym,metro","budget,family,city",2,4),
            H("Palace Downtown","Downtown Dubai",5,1200,4.8,25.1947,55.2750,"pool,spa,dining,concierge","luxury,romantic,city",5,1),
            H("Address Sky View","Downtown Dubai",5,1450,4.8,25.2087,55.2725,"infinity pool,spa,gym,dining","luxury,city,romantic",5,1),
            H("Millennium Central Downtown","Downtown Dubai",4,380,4.3,25.1905,55.2860,"wifi,pool,gym","budget,city,business",2,4),
            H("JW Marriott Marquis","Downtown Dubai",5,850,4.7,25.1854,55.2583,"spa,pool,restaurants,gym","luxury,business,city",5,2),
            H("Marina Byblos Hotel","Dubai Marina",4,390,4.3,25.0718,55.1342,"pool,wifi,marina access","budget,waterfront",2,4),
            H("Address Dubai Marina","Dubai Marina",5,1100,4.7,25.0779,55.1400,"pool,spa,mall access","luxury,waterfront",5,1),
            H("InterContinental Dubai Marina","Dubai Marina",5,950,4.7,25.0788,55.1372,"pool,spa,dining,gym","luxury,waterfront",5,2),
            H("Rove Dubai Marina","Dubai Marina",3,320,4.6,25.0688,55.1300,"wifi,pool,gym","budget,family,waterfront",1,5),
            H("Atlantis The Palm","Palm Jumeirah",5,1800,4.7,25.1304,55.1171,"waterpark,beach,spa,dining","luxury,family,beach",5,1),
            H("Dukes The Palm","Palm Jumeirah",5,900,4.6,25.1125,55.1397,"private beach,pool,spa","luxury,beach,family",4,2),
            H("Premier Inn Dubai Al Jaddaf","Old Dubai / Al Fahidi",3,220,4.4,25.2212,55.3277,"wifi,pool,parking","budget,family",1,5),
            H("Arabian Courtyard Hotel","Old Dubai / Al Fahidi",4,300,4.2,25.2638,55.2972,"wifi,dining,heritage area","culture,budget",2,4),
            H("Jumeirah Beach Hotel","Jumeirah",5,1500,4.7,25.1412,55.1910,"beach,pool,spa,waterpark","luxury,family,beach",5,1),
            H("Beach Walk Hotel","Jumeirah",4,360,4.4,25.1750,55.2140,"wifi,pool,beach access","budget,beach,family",2,4),
            H("Al Maha Desert Resort","Dubai Desert",5,3200,4.9,24.8239,55.6612,"private pool,desert activities,spa","luxury,desert,romantic",5,1)
        };
        db.Hotels.AddRange(hotels);

        string[] tags={"culture","history","family","adventure","luxury","budget","beach","shopping","nature","technology","food","water","desert","landmarks","sports"};
        db.InterestTags.AddRange(tags.Select(x=>new InterestTag{Name=x}));
        db.Categories.AddRange(new[]{new Category{Name="Landmark"},new Category{Name="Museum"},new Category{Name="Beach"},new Category{Name="Adventure",Type="Activity"},new Category{Name="Water Activity",Type="Activity"},new Category{Name="Hotel",Type="Hotel"}});
        await db.SaveChangesAsync();

        var intents = new Dictionary<string,string[]>
{
    ["greeting"] = new[]
    {
        "hello",
        "hi",
        "hey",
        "good morning",
        "good evening",
        "help me",
        "help me plan my Dubai trip"
    },

    ["destination_information"] = new[]
    {
        "tell me about Dubai Frame",
        "what is Burj Khalifa",
        "information about Dubai Mall",
        "tell me about Palm Jumeirah",
        "show attractions",
        "attractions",
        "places to visit",
        "tourist places",
        "destinations in Dubai"
    },

    ["hotel_recommendation"] = new[]
    {
        "hotels",
        "hotel",
        "show hotels",
        "recommend a hotel",
        "best hotel",
        "cheap hotel",
        "luxury hotel",
        "hotel in Downtown Dubai",
        "show me a four star hotel",
        "where should I stay"
    },

    ["budget_trip"] = new[]
    {
        "budget trip",
        "cheap trip",
        "low cost trip",
        "plan Dubai for AED 2000",
        "affordable Dubai trip",
        "travel on a budget"
    },

    ["family_trip"] = new[]
    {
        "family trip",
        "trip with children",
        "activities for kids",
        "family attractions",
        "things to do with children",
        "Dubai with family"
    },

    ["adventure_trip"] = new[]
    {
        "adventure",
        "adventure trip",
        "adventure destination",
        "recommend me a destination for adventure",
        "desert activities",
        "water activities",
        "jet ski",
        "dune bashing",
        "skydiving",
        "adventure activities in Dubai"
    },

    ["itinerary_request"] = new[]
    {
        "create itinerary",
        "make a trip plan",
        "plan my days",
        "day wise schedule",
        "3 day Dubai plan",
        "create my Dubai schedule",
        "trip planner"
    },

    ["booking_help"] = new[]
    {
        "booking",
        "book hotel",
        "book activity",
        "cancel booking",
        "booking help",
        "my booking"
    },

    ["payment_help"] = new[]
    {
        "payment",
        "payment failed",
        "payment help",
        "receipt",
        "transaction",
        "test payment"
    },

    ["fallback"] = new[]
    {
        "something else",
        "other question",
        "not sure"
    }
};
        foreach(var kv in intents){var i=new ChatbotIntent{Name=kv.Key};db.ChatbotIntents.Add(i);foreach(var p in kv.Value)i.Id=i.Id;await db.SaveChangesAsync();db.TrainingPhrases.AddRange(kv.Value.Select(p=>new TrainingPhrase{ChatbotIntentId=i.Id,Text=p}));}
        db.KnowledgeItems.AddRange(
            new KnowledgeItem{Topic="Official bookings",Content="Use the official link on the listing. The venue handles availability, payment and cancellations.",KeywordsCsv="payment,card,transaction,cancel,cancellation,booking"});
        await db.SaveChangesAsync();
        await CatalogueExpansion.SeedAsync(db);

        Attraction A(string n,string desc,string dest,decimal price,double rating,double pop,double lat,double lon,string tags,int mins)=>new(){Name=n,Slug=Slug(n),ShortDescription=PlaceEditorial.For("Attraction", n).Intro,Description=PlaceEditorial.For("Attraction", n).Intro + "\n\n" + PlaceEditorial.For("Attraction", n).Story + "\n\n" + PlaceEditorial.For("Attraction", n).WhatToDo,DestinationId=D(dest),Price=price,Rating=rating,PopularityScore=pop,Latitude=lat,Longitude=lon,ImageUrl="https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=1200&q=80",TagsCsv=tags,AverageVisitMinutes=mins,FamilyFriendly=true,AccessibilityFriendly=true};
        Activity Ac(string n,string desc,string dest,decimal price,double rating,double pop,double lat,double lon,string tags,int mins)=>new(){Name=n,Slug=Slug(n),ShortDescription=PlaceEditorial.For("Activity", n).Intro,Description=PlaceEditorial.For("Activity", n).Intro + "\n\n" + PlaceEditorial.For("Activity", n).Story + "\n\n" + PlaceEditorial.For("Activity", n).WhatToDo,DestinationId=D(dest),Price=price,Rating=rating,PopularityScore=pop,Latitude=lat,Longitude=lon,ImageUrl="https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80",TagsCsv=tags,DurationMinutes=mins,FamilyFriendly=!tags.Contains("skydiv",StringComparison.OrdinalIgnoreCase),AccessibilityFriendly=false};
        Hotel H(string n,string dest,int stars,decimal price,double rating,double lat,double lon,string amenities,string tags,int luxury,int budget)=>new(){Name=n,Slug=Slug(n),ShortDescription=PlaceEditorial.For("Hotel", n).Intro,Description=PlaceEditorial.For("Hotel", n).Intro + "\n\n" + PlaceEditorial.For("Hotel", n).Story + "\n\n" + PlaceEditorial.For("Hotel", n).WhatToDo,DestinationId=D(dest),Price=price,Rating=rating,PopularityScore=rating/5,Latitude=lat,Longitude=lon,ImageUrl="https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=80",TagsCsv=tags,AmenitiesCsv=amenities,StarRating=stars,LuxuryLevel=luxury,BudgetLevel=budget,FamilyFriendly=true,AccessibilityFriendly=true};
        string Slug(string s)=>string.Join("-",s.ToLowerInvariant().Split(' ',StringSplitOptions.RemoveEmptyEntries)).Replace("/","-").Replace("&","and").Replace("'","");
    }

    private static async Task RefreshExistingCatalogueAsync(ApplicationDbContext db)
    {
        static string OriginalCategoryImage(string type) => type switch
        {
            "Attraction" => "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=1200&q=80",
            "Activity" => "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80",
            _ => "https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=80"
        };

        static bool NeedsOriginalImage(string? value) =>
            string.IsNullOrWhiteSpace(value) ||
            value.Contains("/images/venue-placeholder.svg", StringComparison.OrdinalIgnoreCase);

        static void UpdateItem(TourismItem item, string type)
        {
            if (!PlaceEditorial.IsKnown(type, item.Name)) return;
            if (item.LastVerifiedDate.HasValue && string.IsNullOrWhiteSpace(item.SourceNote))
                item.LastVerifiedDate = null;
            var profile = PlaceEditorial.For(type, item.Name);
            bool seededDescription = string.Equals(item.Description?.Trim(), item.ShortDescription?.Trim(), StringComparison.Ordinal) ||
                (type == "Hotel" && item.Description?.StartsWith("Comfortable ", StringComparison.Ordinal) == true);
            if (seededDescription)
            {
                item.ShortDescription = profile.Intro;
                item.Description = profile.Intro + "\n\n" + profile.Story + "\n\n" + profile.WhatToDo;
            }
            if (NeedsOriginalImage(item.ImageUrl))
                item.ImageUrl = OriginalCategoryImage(type);
        }

        foreach (var attraction in await db.Attractions.ToListAsync())
            UpdateItem(attraction, "Attraction");
        foreach (var activity in await db.Activities.ToListAsync())
            UpdateItem(activity, "Activity");
        foreach (var hotel in await db.Hotels.ToListAsync())
            UpdateItem(hotel, "Hotel");

        if (db.ChangeTracker.HasChanges())
            await db.SaveChangesAsync();
    }

}
