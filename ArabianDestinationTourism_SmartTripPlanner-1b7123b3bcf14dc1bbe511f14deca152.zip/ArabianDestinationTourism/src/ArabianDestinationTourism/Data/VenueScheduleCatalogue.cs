using System.Globalization;
using System.Text.Json;

namespace ArabianDestinationTourism.Data;

public sealed class VenueSchedulePolicy
{
    public string Type { get; set; } = "";
    public string Name { get; set; } = "";
    public string Status { get; set; } = "Provisional";
    public string? Note { get; set; }
    public bool Indoors { get; set; }
    public TimeSpan? EarliestStart { get; set; }
    public TimeSpan? LatestEnd { get; set; }
    public Dictionary<string, VenueDailyHours> WeeklyHours { get; set; } = [];
    public List<string> ClosedDates { get; set; } = [];
    public List<VenueClosurePeriod> ClosedPeriods { get; set; } = [];
    public List<TimeSpan> SessionStarts { get; set; } = [];
    public string? SourceUrl { get; set; }
    public string? CheckedOn { get; set; }

    public bool IsUnavailableOn(DateTime date)
    {
        if (Status is "UnconfirmedUnavailable" or "OutsidePlanningHours") return true;
        if (ClosedDates.Contains(date.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture))) return true;
        foreach (var period in ClosedPeriods)
            if (DateOnly.TryParseExact(period.From, "yyyy-MM-dd", CultureInfo.InvariantCulture,
                    DateTimeStyles.None, out var from) &&
                DateOnly.TryParseExact(period.Through, "yyyy-MM-dd", CultureInfo.InvariantCulture,
                    DateTimeStyles.None, out var through) &&
                DateOnly.FromDateTime(date) >= from && DateOnly.FromDateTime(date) <= through)
                return true;
        return false;
    }

    public bool TryHours(DateTime date, out TimeSpan open, out TimeSpan close)
    {
        if (WeeklyHours.TryGetValue(date.DayOfWeek.ToString(), out var hours))
        { open = hours.Open; close = hours.Close; return true; }
        open = default; close = default; return false;
    }
}

public sealed record VenueDailyHours(TimeSpan Open, TimeSpan Close);
public sealed record VenueClosurePeriod(string From, string Through);

public static class VenueScheduleCatalogue
{
    private static readonly Lazy<IReadOnlyDictionary<string, VenueSchedulePolicy>> Policies = new(() =>
    {
        var assembly = typeof(VenueScheduleCatalogue).Assembly;
        using var stream = assembly.GetManifestResourceStream("ArabianDestinationTourism.Data.venue-schedules.json")
            ?? throw new InvalidOperationException("The schedule catalogue was not included in the build.");
        var policies = JsonSerializer.Deserialize<VenueSchedulePolicy[]>(stream) ?? [];
        return policies.ToDictionary(x => $"{x.Type}|{x.Name}", StringComparer.OrdinalIgnoreCase);
    });

    public static VenueSchedulePolicy For(string type, string name) =>
        Policies.Value.TryGetValue($"{type}|{name}", out var policy) ? policy : new VenueSchedulePolicy
        { Type = type, Name = name };
}
