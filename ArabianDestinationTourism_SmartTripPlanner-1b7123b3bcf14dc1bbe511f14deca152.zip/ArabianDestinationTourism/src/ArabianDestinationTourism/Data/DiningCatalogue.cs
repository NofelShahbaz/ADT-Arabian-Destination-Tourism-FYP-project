using System.Text.Json;

namespace ArabianDestinationTourism.Data;

public sealed class DiningListing
{
    public string Name { get; set; } = "";
    public string Slug { get; set; } = "";
    public string Cuisine { get; set; } = "";
    public string Area { get; set; } = "";
    public string Address { get; set; } = "";
    public string? Phone { get; set; }
    public string OfficialUrl { get; set; } = "";
    public string? BookingUrl { get; set; }
    public double? Latitude { get; set; }
    public double? Longitude { get; set; }
    public string? MapUrl { get; set; }
    public string Summary { get; set; } = "";
    public string? Hours { get; set; }
    public string? HoursSourceUrl { get; set; }
    public string? PriceSourceUrl { get; set; }
    public string? PriceNote { get; set; }
    public List<string> Highlights { get; set; } = [];
    public List<PlacePhoto> Photos { get; set; } = [];
}

public static class DiningCatalogue
{
    private static readonly Lazy<DiningListing[]> Listings = new(() =>
    {
        using var stream = typeof(DiningCatalogue).Assembly.GetManifestResourceStream("ArabianDestinationTourism.Data.restaurants.json")
            ?? throw new InvalidOperationException("Restaurant catalogue resource is missing.");
        return JsonSerializer.Deserialize<DiningListing[]>(stream) ?? [];
    });

    public static IReadOnlyList<DiningListing> All => Listings.Value;
}
