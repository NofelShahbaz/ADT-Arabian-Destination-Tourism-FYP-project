using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
namespace ArabianDestinationTourism.Data;
public class DesignTimeDbContextFactory : IDesignTimeDbContextFactory<ApplicationDbContext>
{
    public ApplicationDbContext CreateDbContext(string[] args)
    {
        var basePath=Directory.GetCurrentDirectory();
        if(!File.Exists(Path.Combine(basePath,"appsettings.json")))
            basePath=Path.Combine(basePath,"src","ArabianDestinationTourism");
        var config=new ConfigurationBuilder().SetBasePath(basePath).AddJsonFile("appsettings.json").Build();
        var options=new DbContextOptionsBuilder<ApplicationDbContext>()
            .UseSqlServer(config.GetConnectionString("DefaultConnection")).Options;
        return new ApplicationDbContext(options);
    }
}
