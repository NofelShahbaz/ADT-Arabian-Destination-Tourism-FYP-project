(() => {
  function init() {
    const select = document.querySelector('[data-catalogue-sort]');
    const list = document.querySelector('[data-catalogue-list]');
    if (!select || !list) return;
    const original = Array.from(list.querySelectorAll('[data-catalogue-item]'));
    select.addEventListener('change', () => {
      const items = [...original];
      const num = (item, key) => Number(item.dataset[key] || 0);
      if (select.value === 'rating') items.sort((a,b) => num(b,'rating') - num(a,'rating'));
      if (select.value === 'price') items.sort((a,b) => num(a,'price') - num(b,'price'));
      if (select.value === 'name') items.sort((a,b) => (a.dataset.name || '').localeCompare(b.dataset.name || ''));
      items.forEach(item => list.appendChild(item));
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
