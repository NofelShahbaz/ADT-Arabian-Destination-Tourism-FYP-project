window.adt = {
  csrf: () => document.querySelector('input[name="__RequestVerificationToken"]')?.value || '',
  async toggleFavorite(type,id,btn){
    const r=await fetch(`/api/favorites/toggle?itemType=${encodeURIComponent(type)}&itemId=${id}`,{method:'POST',headers:{'X-CSRF-TOKEN':adt.csrf()}});
    if(r.status===401){location.href='/Account/Login';return}
    const x=await r.json();btn.innerHTML=x.saved?'♥ Saved':'♡ Save';
  },
  printTrip(){window.print();}
};
