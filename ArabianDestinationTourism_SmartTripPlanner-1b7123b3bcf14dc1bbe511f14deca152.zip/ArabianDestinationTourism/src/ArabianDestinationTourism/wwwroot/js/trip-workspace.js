(() => {
    "use strict";

    document.querySelectorAll("[data-tw-prompt]").forEach((button) => {
        button.addEventListener("click", () => {
            const input = document.getElementById(button.dataset.twTarget);
            if (!input) return;
            input.value = button.dataset.twPrompt;
            input.focus();
        });
    });

    document.querySelectorAll("[data-tw-print]").forEach((button) => {
        button.addEventListener("click", () => window.print());
    });

    document.querySelectorAll("form[data-tw-working]").forEach((form) => {
        form.addEventListener("submit", (event) => {
            if (form.dataset.twPending === "true") {
                event.preventDefault();
                return;
            }
            form.dataset.twPending = "true";
            const status = form.querySelector(".tw-working");
            if (status) {
                status.hidden = false;
                status.textContent = form.dataset.twWorking;
            }
        });
    });

    window.addEventListener("pageshow", (event) => {
        if (!event.persisted) return;
        document.querySelectorAll("form[data-tw-pending]").forEach((form) => {
            delete form.dataset.twPending;
            const status = form.querySelector(".tw-working");
            if (status) status.hidden = true;
        });
    });

    const mapContainer = document.getElementById("tw-route-preview");
    if (mapContainer && window.L) {
        const L = window.L;
        const stops = [...document.querySelectorAll("[data-tw-map-stop]")]
            .map((node) => ({
                key: node.dataset.twKey,
                name: node.dataset.twName,
                time: node.dataset.twTime,
                day: node.dataset.twDay,
                point: [Number(node.dataset.twLatitude), Number(node.dataset.twLongitude)]
            }))
            .filter(({ point }) => point.every(Number.isFinite) && Math.abs(point[0]) <= 90 && Math.abs(point[1]) <= 180 && point.some((coordinate) => coordinate !== 0));
        if (stops.length > 0) {
            renderMap(stops, L);
        }
    }

    function renderMap(stops, L) {
        mapContainer.querySelector("[data-tw-map-placeholder]")?.remove();
        const map = L.map(mapContainer, { scrollWheelZoom: false });
        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
            maxZoom: 19,
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);
        const layers = L.featureGroup().addTo(map);
        const colours = ["#125c50", "#1b537f", "#a24f37", "#60438b", "#916419"];
        const filters = [...document.querySelectorAll("[data-tw-map-filter]")];
        const markers = new Map();
        const byDay = new Map();

        for (const stop of stops) {
            if (!byDay.has(stop.day)) byDay.set(stop.day, []);
            byDay.get(stop.day).push(stop);
        }

        function displayDay(day) {
            layers.clearLayers();
            markers.clear();
            filters.forEach((button) => button.setAttribute("aria-pressed", String(button.dataset.twMapFilter === day)));
            let dayIndex = 0;
            for (const [number, visits] of byDay) {
                const colour = colours[dayIndex % colours.length];
                dayIndex += 1;
                if (day !== "all" && number !== day) continue;
                L.polyline(visits.map((visit) => visit.point), {color: colour, weight: 3, dashArray: "7 7"}).addTo(layers);
                visits.forEach((stop, index) => {
                    const markerLabel = document.createElement("span");
                    markerLabel.className = "tw-map-marker";
                    markerLabel.style.backgroundColor = colour;
                    markerLabel.textContent = String(index + 1);
                    const marker = L.marker(stop.point, {
                        title: stop.name,
                        alt: stop.name,
                        icon: L.divIcon({className: "tw-map-icon", html: markerLabel, iconSize: [28, 28], iconAnchor: [14, 14]})
                    }).addTo(layers);
                    const popup = document.createElement("div");
                    const name = document.createElement("strong");
                    name.textContent = stop.name;
                    popup.append(name, document.createElement("br"), document.createTextNode(`Day ${stop.day}, ${stop.time}`));
                    marker.bindPopup(popup);
                    markers.set(stop.key, marker);
                });
            }
            map.fitBounds(layers.getBounds(), {padding: [22, 22], maxZoom: 14});
        }

        filters.forEach((button) => button.addEventListener("click", () => displayDay(button.dataset.twMapFilter)));
        document.querySelectorAll("[data-tw-show-stop]").forEach((button) => {
            button.addEventListener("click", (event) => {
                if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
                const stop = stops.find((visit) => visit.key === button.dataset.twShowStop);
                if (!stop) return;
                event.preventDefault();
                displayDay(stop.day);
                const smooth = !window.matchMedia("(prefers-reduced-motion: reduce)").matches;
                mapContainer.scrollIntoView({behavior: smooth ? "smooth" : "auto", block: "center"});
                mapContainer.focus({preventScroll: true});
                markers.get(stop.key)?.openPopup();
            });
        });

        displayDay("all");
    }

})();
