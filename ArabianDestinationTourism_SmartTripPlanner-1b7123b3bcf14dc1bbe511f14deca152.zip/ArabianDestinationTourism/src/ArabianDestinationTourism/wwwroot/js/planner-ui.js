(() => {
  "use strict";
  const form = document.getElementById("tripPlannerForm");
  if (!form) return;
  const budget = form.querySelector("#TotalBudget");
  const days = form.querySelector("#Days");
  const party = form.querySelector("#PartySize");
  const formatter = new Intl.NumberFormat("en-AE", { maximumFractionDigits: 0 });
  const display = (id, text) => {
    const node = document.getElementById(id);
    if (node) node.textContent = text;
  };
  function refresh() {
    const total = Math.max(0, Number(budget.value) || 0);
    const d = Math.max(1, Number(days.value) || 1);
    const people = Math.max(1, Number(party.value) || 1);
    const essential = (35 + 20) * people * d;
    display("plannerDisplayBudget", `AED ${formatter.format(total)}`);
    display("plannerPerPerson", `AED ${formatter.format(total / d / people)}`);
    display("plannerEssentials", `AED ${formatter.format(essential)}`);
    display("plannerFlexible", `AED ${formatter.format(Math.max(0, total - essential))}`);
    const warn = document.getElementById("plannerBudgetWarning");
    if (warn) warn.hidden = total >= essential && total >= 500;
    document.querySelectorAll("[data-set-budget]").forEach(chip => {
      const active = Number(chip.dataset.setBudget) === total;
      chip.classList.toggle("is-active", active);
      chip.setAttribute("aria-pressed", active ? "true" : "false");
    });
  }
  for (const field of [budget, days, party]) field.addEventListener("input", refresh);
  document.querySelectorAll("[data-set-budget]").forEach(chip => {
    chip.addEventListener("click", () => {
      budget.value = chip.dataset.setBudget;
      budget.dispatchEvent(new Event("input", { bubbles: true }));
    });
  });
  refresh();
})();
