(() => {
    const node = document.getElementById("dining-map");
    if (!node || !window.L) return;
    const point = [Number(node.dataset.lat), Number(node.dataset.lon)];
    if (!point.every(Number.isFinite)) return;
    const map = L.map(node, { scrollWheelZoom: false }).setView(point, 15);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19, attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
    }).addTo(map);
    const name = document.createElement("span");
    name.textContent = node.dataset.title;
    L.marker(point).addTo(map).bindPopup(name);
})();
