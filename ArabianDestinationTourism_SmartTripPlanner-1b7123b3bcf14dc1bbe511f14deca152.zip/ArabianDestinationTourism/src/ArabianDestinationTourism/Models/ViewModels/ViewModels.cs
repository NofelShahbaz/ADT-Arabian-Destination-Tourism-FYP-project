using ArabianDestinationTourism.Models.Entities;
using ArabianDestinationTourism.Services.Pricing;
using System.ComponentModel.DataAnnotations;

namespace ArabianDestinationTourism.Models.ViewModels;

public class RegisterVm
{
    [Required] public string FullName { get; set; } = "";
    [Required, EmailAddress] public string Email { get; set; } = "";
    [Required, DataType(DataType.Password)] public string Password { get; set; } = "";
    [Compare(nameof(Password)), DataType(DataType.Password)] public string ConfirmPassword { get; set; } = "";
}
public class LoginVm
{
    [Required, EmailAddress] public string Email { get; set; } = "";
    [Required, DataType(DataType.Password)] public string Password { get; set; } = "";
    public bool RememberMe { get; set; }
}
public sealed class ForgotPasswordVm
{
    [Required, EmailAddress, StringLength(254)] public string Email { get; set; } = "";
}
public sealed class ResetPasswordVm
{
    [Required, StringLength(128)] public string UserId { get; set; } = "";
    [Required, StringLength(2048)] public string Code { get; set; } = "";
    [Required, StringLength(128, MinimumLength = 8), DataType(DataType.Password)] public string Password { get; set; } = "";
    [Required, Compare(nameof(Password)), DataType(DataType.Password)] public string ConfirmPassword { get; set; } = "";
}
public class PlannerVm
{
    [DataType(DataType.Date)] public DateTime StartDate { get; set; } = DateTime.Today.AddDays(7);
    [Range(1,14)] public int Days { get; set; } = 3;
    [Range(500,100000, ErrorMessage = "Your total trip budget must be at least AED 500.")] public decimal TotalBudget { get; set; } = 3000;
    [Range(0,100000)] public decimal EmergencyReserve { get; set; }
    public string Currency { get; set; } = "AED";
    [Range(1,20)] public int PartySize { get; set; } = 2;
    public PartyType PartyType { get; set; } = PartyType.Couple;
    public TravelPace TravelPace { get; set; } = TravelPace.Balanced;
    public ArabianDestinationTourism.Services.Itinerary.TransportPreference TransportPreference { get; set; } = ArabianDestinationTourism.Services.Itinerary.TransportPreference.Balanced;
    [Range(4,16)] public int DailyAvailableHours { get; set; } = 10;
    public bool ChildFriendly { get; set; }
    public bool AccessibilityFriendly { get; set; }
    public bool LimitedWalking { get; set; }
    [StringLength(250)] public string Interests { get; set; } = "culture,shopping,landmarks";
    [StringLength(500)] public string? ExcludedPlaces { get; set; }
    [StringLength(120)] public string? PreferredLocation { get; set; }
    [Range(1,5)] public int PreferredHotelStars { get; set; } = 4;
    public bool IndoorAfternoons { get; set; }
    [StringLength(500)] public string? MustIncludePlaces { get; set; }
}
public record ScoreBreakdown(double InterestMatch,double BudgetFit,double TimeFit,double Rating,double Proximity,double Popularity)
{
    public double Final => Math.Clamp(.30*InterestMatch + .25*BudgetFit + .15*TimeFit + .15*Rating + .10*Proximity + .05*Popularity, 0, 1);
}
public record RecommendationResult(
    string ItemType, int ItemId, string Name, decimal Price, double Latitude, double Longitude,
    ScoreBreakdown Scores, string Reason, string ImageUrl = "", string Location = "",
    double VisitorRating = 0, int VisitMinutes = 120, bool FamilyFriendly = false,
    HotelRoomQuote? RoomQuote = null, bool PriceOnRequest = false)
{
    public int MatchPercent => (int)Math.Round(Scores.Final * 100);
    public string MatchLabel => Scores.Final >= .82 ? "Excellent match" :
        Scores.Final >= .70 ? "Strong match" :
        Scores.Final >= .55 ? "Good option" : "Worth exploring";
}
public class RecommendationPageVm
{
    public List<RecommendationResult> Attractions { get; set; } = [];
    public List<RecommendationResult> Hotels { get; set; } = [];
    public List<RecommendationResult> Activities { get; set; } = [];
}
public class PlannedItemVm
{
    public string ItemType { get; set; } = "";
    public int ItemId { get; set; }
    public string Name { get; set; } = "";
    public TimeSpan StartTime { get; set; }
    public int DurationMinutes { get; set; }
    public int TravelBufferMinutes { get; set; }
    public decimal TravelCost { get; set; }
    public double TravelDistanceKm { get; set; }
    public string TravelMode { get; set; } = "";
    public decimal Cost { get; set; }
    public string Reason { get; set; } = "";
    public double Latitude { get; set; }
    public double Longitude { get; set; }
    public bool IsPinned { get; set; }
    public bool IsCompleted { get; set; }
    public double MatchScore { get; set; }
    public string? HoursNote { get; set; }
}
public class PlannedDayVm { public int DayNumber { get; set; } public DateTime Date { get; set; } public List<PlannedItemVm> Items { get; set; } = []; public string? DiningName { get; set; } public string? DiningSlug { get; set; } public decimal Cost => Items.Sum(x=>x.Cost); }
public class ItineraryResultVm
{
    public List<PlannedDayVm> Days { get; set; } = [];
    public decimal TotalEstimatedCost { get; set; }
    public decimal HotelCost { get; set; }
    public decimal MealCost { get; set; }
    public decimal TransportCost { get; set; }
    public decimal EmergencyReserve { get; set; }
    public int AccommodationNights { get; set; }
    public int RoomCount { get; set; }
    public List<RoomAllocation> Rooms { get; set; } = [];
    public int? HotelId { get; set; }
    public double? HotelLatitude { get; set; }
    public double? HotelLongitude { get; set; }
    public PlanObjective Objective { get; set; } = PlanObjective.BestExperience;
    public string? HotelName { get; set; }
    public bool IsFeasible { get; set; } = true;
    public decimal AttractionCost { get; set; }
    public decimal ActivityCost { get; set; }
    public decimal BudgetRemaining { get; set; }
    public List<string> Conflicts { get; set; } = [];
    public List<string> Alternatives { get; set; } = [];
}
public enum PlanObjective { BudgetSaver, TimeSaver, BestExperience, GreedyBaseline }
public record PlanMetrics(int Stops, int SightseeingMinutes, int TravelMinutes, double TravelKilometres,
    int PreferenceMatchPercent);
public record PlanVariantVm(PlanObjective Objective, ItineraryResultVm Result, PlanMetrics Metrics)
{
    public string Name => Objective switch
    {
        PlanObjective.BudgetSaver => "Budget saver",
        PlanObjective.TimeSaver => "Time saver",
        _ => "Best experience"
    };
}
public sealed class SimulationRequestVm
{
    public string? DraftToken { get; set; }
    [Range(-100000,100000)] public decimal BudgetDelta { get; set; }
    [Range(-13,13)] public int DaysDelta { get; set; }
    [Range(-19,19)] public int TravellersDelta { get; set; }
    [Range(-100000,100000)] public decimal ReserveDelta { get; set; }
    [Range(1,5)] public int? HotelStars { get; set; }
    public bool? LimitedWalking { get; set; }
    public bool? IndoorAfternoons { get; set; }
    public ArabianDestinationTourism.Services.Itinerary.TransportPreference? TransportPreference { get; set; }
    [StringLength(30)] public string? AdditionalInterest { get; set; }
}
public record TripSimulationVm(ItineraryResultVm Original, ItineraryResultVm Revised,
    PlannerVm RevisedPreferences, SimulationRequestVm Request);
public record ReplanPreviewVm(ItineraryResultVm Original, ItineraryResultVm Revised,
    string Operation, int DayNumber, string? ItemType, int ItemId, string? Message,
    string Explanation);
public record ItineraryEditResult(string Message, bool Changed);
public class BookingCreateVm
{
    public string ServiceType { get; set; } = "Activity";
    public int ServiceId { get; set; }
    [DataType(DataType.Date)] public DateTime BookingDate { get; set; } = DateTime.Today.AddDays(7);
    [Range(1,20)] public int Guests { get; set; } = 1;
}
