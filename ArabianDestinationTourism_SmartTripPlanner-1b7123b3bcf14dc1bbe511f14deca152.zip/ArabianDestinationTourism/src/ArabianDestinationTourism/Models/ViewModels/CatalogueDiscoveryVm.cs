using ArabianDestinationTourism.Models.Entities;

namespace ArabianDestinationTourism.Models.ViewModels;

public sealed record CatalogueDiscoveryVm(string Category, string Intro, IReadOnlyList<TourismItem> Places);
