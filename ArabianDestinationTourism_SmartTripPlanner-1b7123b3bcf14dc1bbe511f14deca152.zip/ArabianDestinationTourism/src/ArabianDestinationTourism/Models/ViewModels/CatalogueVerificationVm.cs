using System.ComponentModel.DataAnnotations;
using ArabianDestinationTourism.Models.Entities;

namespace ArabianDestinationTourism.Models.ViewModels;

public sealed record CatalogueVerificationListing(
    string Category, TourismItem Item, string? OfficialUrl, DateTime? ReviewedAt)
{
    public bool IsDue(DateTime today) => ReviewedAt is not DateTime reviewed || reviewed.Date <= today.Date.AddDays(-90);
}

public sealed record CatalogueVerificationQueue(
    IReadOnlyList<CatalogueVerificationListing> Listings, int DueCount, bool ShowAll, DateTime Today);

public sealed class CatalogueReviewInput
{
    [Required, StringLength(500)]
    public string SourceNote { get; set; } = "";

    [Range(typeof(decimal), "0", "1000000")]
    public decimal? UpdatedEstimate { get; set; }

    public long UpdatedAtTicks { get; set; }

    public bool ConfirmSource { get; set; }
}

public sealed record CatalogueReviewPage(CatalogueVerificationListing Listing, CatalogueReviewInput Review);
