using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace ArabianDestinationTourism.Models.Entities;

public enum RecordStatus { Draft, Published, Archived }
public enum BookingStatus { Pending, Confirmed, Cancelled, Failed }
public enum PaymentStatus { Pending, Successful, Failed }
public enum TravelPace { Relaxed, Balanced, Fast }
public enum PartyType { Solo, Couple, Family, Friends, Business }

public abstract class BaseEntity
{
    public int Id { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
}

public class ApplicationUser : IdentityUser
{
    [MaxLength(120)] public string FullName { get; set; } = "";
    public UserProfile? Profile { get; set; }
}

public class UserProfile : BaseEntity
{
    [Required] public string UserId { get; set; } = "";
    public ApplicationUser? User { get; set; }
    [MaxLength(80)] public string? Nationality { get; set; }
    [MaxLength(255)] public string? ProfileImage { get; set; }
    [MaxLength(8)] public string PreferredCurrency { get; set; } = "AED";
    public TravelPace PreferredTravelPace { get; set; } = TravelPace.Balanced;
    public bool AccessibilityPreferred { get; set; }
    public bool ChildFriendlyPreferred { get; set; }
    [MaxLength(600)] public string TravelInterestsCsv { get; set; } = "";
}

public class Destination : BaseEntity
{
    [Required, MaxLength(120)] public string Name { get; set; } = "";
    [Required, MaxLength(160)] public string Slug { get; set; } = "";
    [MaxLength(1500)] public string Description { get; set; } = "";
    public double Latitude { get; set; }
    public double Longitude { get; set; }
    public RecordStatus Status { get; set; } = RecordStatus.Published;
}

public class Category : BaseEntity
{
    [Required, MaxLength(80)] public string Name { get; set; } = "";
    [MaxLength(40)] public string Type { get; set; } = "Attraction";
}

public class InterestTag : BaseEntity
{
    [Required, MaxLength(80)] public string Name { get; set; } = "";
}

public abstract class TourismItem : BaseEntity
{
    [Required, MaxLength(160)] public string Name { get; set; } = "";
    [Required, MaxLength(180)] public string Slug { get; set; } = "";
    [MaxLength(500)] public string ShortDescription { get; set; } = "";
    [MaxLength(4000)] public string Description { get; set; } = "";
    public int DestinationId { get; set; }
    public Destination? Destination { get; set; }
    public decimal Price { get; set; }
    [MaxLength(8)] public string Currency { get; set; } = "AED";
    [Range(0, 5)] public double Rating { get; set; }
    [Range(0, 1)] public double PopularityScore { get; set; }
    public double Latitude { get; set; }
    public double Longitude { get; set; }
    [MaxLength(255)] public string ImageUrl { get; set; } = "";
    public bool FamilyFriendly { get; set; }
    public bool AccessibilityFriendly { get; set; }
    public RecordStatus Status { get; set; } = RecordStatus.Published;
    public DateTime? LastVerifiedDate { get; set; }
    [MaxLength(500)] public string? SourceNote { get; set; }
    [MaxLength(500)] public string TagsCsv { get; set; } = "";
}

public class Attraction : TourismItem
{
    public TimeSpan OpeningTime { get; set; } = new(9,0,0);
    public TimeSpan ClosingTime { get; set; } = new(22,0,0);
    public int AverageVisitMinutes { get; set; } = 120;
    public int? Capacity { get; set; }
    [MaxLength(80)] public string CategoryName { get; set; } = "Landmark";
}

public class Activity : TourismItem
{
    public int DurationMinutes { get; set; } = 120;
    [MaxLength(80)] public string CategoryName { get; set; } = "Experience";
}

public class Hotel : TourismItem
{
    [Range(1,5)] public int StarRating { get; set; }
    [MaxLength(500)] public string AmenitiesCsv { get; set; } = "";
    public int LuxuryLevel { get; set; }
    public int BudgetLevel { get; set; }
}

public class Favorite : BaseEntity
{
    [Required] public string UserId { get; set; } = "";
    [Required, MaxLength(30)] public string ItemType { get; set; } = "";
    public int ItemId { get; set; }
}

public class Review : BaseEntity
{
    [Required] public string UserId { get; set; } = "";
    [Required, MaxLength(30)] public string ItemType { get; set; } = "";
    public int ItemId { get; set; }
    [Range(1,5)] public int Rating { get; set; }
    [MaxLength(1500)] public string Comment { get; set; } = "";
    public bool IsApproved { get; set; }
}

public class PlannerPreference : BaseEntity
{
    public string UserId { get; set; } = "";
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public decimal TotalBudget { get; set; }
    public string Currency { get; set; } = "AED";
    public int PartySize { get; set; } = 1;
    public PartyType PartyType { get; set; }
    public TravelPace TravelPace { get; set; }
    public int DailyAvailableHours { get; set; } = 10;
    public bool ChildFriendly { get; set; }
    public bool AccessibilityFriendly { get; set; }
    public string InterestsCsv { get; set; } = "";
    public string ExcludedPlacesCsv { get; set; } = "";
    public string? PreferredLocation { get; set; }
    public int PreferredHotelStars { get; set; } = 4;
}

public class TripPlan : BaseEntity
{
    [Required] public string UserId { get; set; } = "";
    [MaxLength(120)] public string Name { get; set; } = "My Dubai Trip";
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public decimal TotalEstimatedCost { get; set; }
    public decimal Budget { get; set; }
    public List<TripDay> Days { get; set; } = [];
}

public class TripDay : BaseEntity
{
    public int TripPlanId { get; set; }
    public TripPlan? TripPlan { get; set; }
    public int DayNumber { get; set; }
    public DateTime Date { get; set; }
    public List<TripItem> Items { get; set; } = [];
}

public class TripItem : BaseEntity
{
    public int TripDayId { get; set; }
    public TripDay? TripDay { get; set; }
    public string ItemType { get; set; } = "";
    public int TourismItemId { get; set; }
    public string PlaceName { get; set; } = "";
    public TimeSpan StartTime { get; set; }
    public int DurationMinutes { get; set; }
    public int TravelBufferMinutes { get; set; }
    public decimal EstimatedCost { get; set; }
    public double Latitude { get; set; }
    public double Longitude { get; set; }
    public string RecommendationReason { get; set; } = "";
}

public class Booking : BaseEntity
{
    [Required] public string UserId { get; set; } = "";
    [MaxLength(30)] public string ServiceType { get; set; } = "";
    public int ServiceId { get; set; }
    public DateTime BookingDate { get; set; }
    public int Guests { get; set; }
    public decimal Amount { get; set; }
    public BookingStatus Status { get; set; } = BookingStatus.Pending;
    public Payment? Payment { get; set; }
}

public class Payment : BaseEntity
{
    public int BookingId { get; set; }
    public Booking? Booking { get; set; }
    [Required, MaxLength(60)] public string TransactionId { get; set; } = "";
    public decimal Amount { get; set; }
    [MaxLength(40)] public string PaymentMethodLabel { get; set; } = "Test Card";
    public PaymentStatus Status { get; set; }
}

public class ChatbotIntent : BaseEntity
{
    [Required, MaxLength(80)] public string Name { get; set; } = "";
    public bool IsActive { get; set; } = true;
}
public class TrainingPhrase : BaseEntity
{
    public int ChatbotIntentId { get; set; }
    public ChatbotIntent? ChatbotIntent { get; set; }
    [Required, MaxLength(500)] public string Text { get; set; } = "";
}
public class KnowledgeItem : BaseEntity
{
    [Required, MaxLength(160)] public string Topic { get; set; } = "";
    [Required, MaxLength(3000)] public string Content { get; set; } = "";
    [MaxLength(300)] public string KeywordsCsv { get; set; } = "";
}
public class ChatSession : BaseEntity
{
    public string UserId { get; set; } = "";
    public List<ChatMessage> Messages { get; set; } = [];
}
public class ChatMessage : BaseEntity
{
    public int ChatSessionId { get; set; }
    public ChatSession? ChatSession { get; set; }
    public string UserMessage { get; set; } = "";
    public string PredictedIntent { get; set; } = "";
    public float ConfidenceScore { get; set; }
    public string ResponseText { get; set; } = "";
    public string ResponseSource { get; set; } = "";
    public bool IsFallback { get; set; }
    public bool? HelpfulFeedback { get; set; }
}

public class AuditLog : BaseEntity
{
    public string? UserId { get; set; }
    [MaxLength(100)] public string Action { get; set; } = "";
    [MaxLength(80)] public string EntityType { get; set; } = "";
    [MaxLength(1000)] public string Details { get; set; } = "";
}
public class ErrorLog : BaseEntity
{
    [MaxLength(200)] public string Message { get; set; } = "";
    public string? StackTrace { get; set; }
    [MaxLength(100)] public string? Path { get; set; }
}
